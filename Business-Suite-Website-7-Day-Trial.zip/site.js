const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#nav');
const header = document.querySelector('.site-header');
const progressBar = document.querySelector('.scroll-progress span');

function updateScrollUI() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  const progress = scrollable > 0 ? Math.min(100, (window.scrollY / scrollable) * 100) : 0;
  if (progressBar) progressBar.style.width = `${progress}%`;
  header?.classList.toggle('is-scrolled', window.scrollY > 12);
}

window.addEventListener('scroll', updateScrollUI, { passive: true });
updateScrollUI();

if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = !nav.classList.contains('open');
    nav.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
  });

  nav.addEventListener('click', event => {
    if (event.target.closest('a')) {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });
}

const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const revealItems = document.querySelectorAll('.reveal');
if (reduced || !('IntersectionObserver' in window)) {
  revealItems.forEach(item => item.classList.add('visible'));
} else {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  }), { threshold: 0.12 });
  revealItems.forEach(item => observer.observe(item));
}

const viewer = document.querySelector('.viewer');
if (viewer) {
  const viewerImage = viewer.querySelector('img');
  const viewerTitle = viewer.querySelector('h2');
  const closeButton = viewer.querySelector('.viewer-close');

  document.querySelectorAll('.screen-card').forEach(card => card.addEventListener('click', () => {
    viewerImage.src = card.dataset.full;
    viewerImage.alt = `${card.dataset.title} screenshot`;
    viewerTitle.textContent = card.dataset.title;
    viewer.showModal();
  }));

  closeButton?.addEventListener('click', () => viewer.close());
  viewer.addEventListener('click', event => {
    if (event.target === viewer) viewer.close();
  });
}

const workspaceModes = {
  basic: {
    kicker: 'A clear place to begin',
    title: 'Focus on daily essentials',
    description: 'Customers, leads, sales, payments, expenses, tasks and simple reports stay easy to find.',
    chips: ['Customers', 'Sales', 'Payments', 'Tasks'],
    label: 'Basic workspace'
  },
  advanced: {
    kicker: 'Deeper control as you grow',
    title: 'Unlock the complete workflow',
    description: 'Manage stock, purchases, staff, projects, marketing, custom reports, connected devices and a clear audit history.',
    chips: ['Stock & Purchase', 'Projects', 'Staff', 'GST Reports', 'Audit History'],
    label: 'Advanced workspace'
  }
};

const modeButtons = document.querySelectorAll('[data-mode]');
const modeKicker = document.querySelector('#modeKicker');
const modeTitle = document.querySelector('#modeTitle');
const modeDescription = document.querySelector('#modeDescription');
const modeChips = document.querySelector('#modeChips');
const demoModeLabel = document.querySelector('#demoModeLabel');

function selectMode(modeName) {
  const mode = workspaceModes[modeName];
  if (!mode) return;

  modeButtons.forEach(button => {
    const selected = button.dataset.mode === modeName;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });

  if (modeKicker) modeKicker.textContent = mode.kicker;
  if (modeTitle) modeTitle.textContent = mode.title;
  if (modeDescription) modeDescription.textContent = mode.description;
  if (demoModeLabel) demoModeLabel.textContent = mode.label;
  if (modeChips) {
    modeChips.replaceChildren(...mode.chips.map(label => {
      const chip = document.createElement('span');
      chip.textContent = label;
      return chip;
    }));
  }
}

modeButtons.forEach(button => button.addEventListener('click', () => selectMode(button.dataset.mode)));

const businessFits = {
  retail: {
    label: 'Shop & retail',
    heading: 'Know what sells, what is due and what needs restocking.',
    text: 'Connect products, suppliers, purchases, sales, expenses, payments and daily cash closing in one clear flow.',
    tags: ['Products', 'Stock', 'Purchases', 'Sales', 'Daily cash'],
    status: 'Retail workspace',
    metricOneLabel: 'Sales today', metricOne: '₹32,450',
    metricTwoLabel: 'Low stock', metricTwo: '4',
    actionTitle: 'Daily control is ready', actionText: 'Review sales, payments and stock before closing the day.'
  },
  service: {
    label: 'Service business',
    heading: 'Keep every enquiry, appointment and payment moving.',
    text: 'Bring leads, quotations, bookings, job orders, reminders and customer payments into one connected service workflow.',
    tags: ['Leads', 'Quotations', 'Appointments', 'Job orders', 'Payments'],
    status: 'Service workspace',
    metricOneLabel: 'Appointments', metricOne: '8',
    metricTwoLabel: 'Open jobs', metricTwo: '12',
    actionTitle: 'Next actions are visible', actionText: 'Follow up, deliver work and collect payments on time.'
  },
  freelance: {
    label: 'Freelancer & agency',
    heading: 'Turn ideas and enquiries into profitable, organised projects.',
    text: 'Plan content, prepare quotations, track projects, record expenses and keep client follow-ups in the same workspace.',
    tags: ['Projects', 'Content', 'Tasks', 'Quotations', 'Expenses'],
    status: 'Agency workspace',
    metricOneLabel: 'Active projects', metricOne: '6',
    metricTwoLabel: 'To receive', metricTwo: '₹48,000',
    actionTitle: 'Client work stays organised', actionText: 'See deadlines, pending approvals and collections together.'
  },
  team: {
    label: 'Growing team',
    heading: 'Give the team a shared view without losing business control.',
    text: 'Coordinate staff, targets, tasks, projects, reports and connected devices while keeping important decisions visible.',
    tags: ['Staff', 'Targets', 'Projects', 'Reports', 'Devices'],
    status: 'Team workspace',
    metricOneLabel: 'Team tasks', metricOne: '24',
    metricTwoLabel: 'Due today', metricTwo: '5',
    actionTitle: 'Everyone sees the priority', actionText: 'Keep responsibilities, progress and reports easy to review.'
  }
};

const fitElements = {
  label: document.querySelector('#fitLabel'), heading: document.querySelector('#fitHeading'),
  text: document.querySelector('#fitText'), tags: document.querySelector('#fitTags'),
  status: document.querySelector('#fitStatus'), metricOneLabel: document.querySelector('#fitMetricOneLabel'),
  metricOne: document.querySelector('#fitMetricOne'), metricTwoLabel: document.querySelector('#fitMetricTwoLabel'),
  metricTwo: document.querySelector('#fitMetricTwo'), actionTitle: document.querySelector('#fitActionTitle'),
  actionText: document.querySelector('#fitActionText')
};

document.querySelectorAll('[data-fit]').forEach(button => button.addEventListener('click', () => {
  const selected = businessFits[button.dataset.fit];
  if (!selected) return;
  document.querySelectorAll('[data-fit]').forEach(item => {
    const active = item === button;
    item.classList.toggle('active', active);
    item.setAttribute('aria-selected', String(active));
  });
  Object.entries(fitElements).forEach(([key, element]) => {
    if (!element || key === 'tags') return;
    element.textContent = selected[key];
  });
  if (fitElements.tags) {
    fitElements.tags.replaceChildren(...selected.tags.map(label => {
      const tag = document.createElement('span');
      tag.textContent = label;
      return tag;
    }));
  }
}));

const moduleSearch = document.querySelector('#moduleSearch');
const moduleCards = [...document.querySelectorAll('#moduleGrid article')];
const categoryButtons = document.querySelectorAll('.module-filters [data-category]');
const moduleEmpty = document.querySelector('#moduleEmpty');
let activeCategory = 'all';

function filterModules() {
  const query = moduleSearch?.value.trim().toLocaleLowerCase() || '';
  let visible = 0;
  moduleCards.forEach(card => {
    const categoryMatch = activeCategory === 'all' || card.dataset.category === activeCategory;
    const searchable = `${card.dataset.search || ''} ${card.textContent}`.toLocaleLowerCase();
    const show = categoryMatch && (!query || searchable.includes(query));
    card.classList.toggle('filtered-out', !show);
    if (show) visible += 1;
  });
  if (moduleEmpty) moduleEmpty.hidden = visible !== 0;
}

categoryButtons.forEach(button => button.addEventListener('click', () => {
  activeCategory = button.dataset.category;
  categoryButtons.forEach(item => item.classList.toggle('active', item === button));
  filterModules();
}));
moduleSearch?.addEventListener('input', filterModules);
document.addEventListener('keydown', event => {
  if (event.key === '/' && moduleSearch && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) {
    event.preventDefault();
    moduleSearch.focus();
  }
});

document.querySelectorAll('.faq-list details').forEach(item => item.addEventListener('toggle', () => {
  if (!item.open) return;
  document.querySelectorAll('.faq-list details[open]').forEach(openItem => {
    if (openItem !== item) openItem.open = false;
  });
}));

const backupFile = document.querySelector('#backupFile');
const sampleRestore = document.querySelector('#sampleRestore');
const restoreResult = document.querySelector('#restoreResult');
const restoreName = document.querySelector('#restoreName');
const restoreIntegrity = document.querySelector('#restoreIntegrity');
const restoreSections = document.querySelector('#restoreSections');
const restoreSize = document.querySelector('#restoreSize');
const restoreMessage = document.querySelector('#restoreMessage');
const maximumBackupBytes = 10 * 1024 * 1024;

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB'];
  const unit = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / (1024 ** unit)).toFixed(unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function showRestorePreview({ name, integrity, sections, size, message, error = false }) {
  if (!restoreResult) return;
  restoreResult.hidden = false;
  restoreResult.classList.toggle('error', error);
  if (restoreName) restoreName.textContent = name;
  if (restoreIntegrity) restoreIntegrity.textContent = integrity;
  if (restoreSections) restoreSections.textContent = sections;
  if (restoreSize) restoreSize.textContent = size;
  if (restoreMessage) restoreMessage.textContent = message;
}

sampleRestore?.addEventListener('click', () => {
  showRestorePreview({
    name: 'business-suite-backup-sample.json',
    integrity: 'Passed',
    sections: '8 data sections',
    size: '307 KB',
    message: 'Preview complete. Your current data stays unchanged until you confirm a restore inside Business Suite.'
  });
});

backupFile?.addEventListener('change', async event => {
  const file = event.target.files?.[0];
  if (!file) return;

  if (file.size > maximumBackupBytes) {
    showRestorePreview({
      name: file.name,
      integrity: 'Not checked',
      sections: '—',
      size: formatBytes(file.size),
      message: 'This website demo accepts backup previews up to 10 MB. No file was uploaded.',
      error: true
    });
    return;
  }

  try {
    const parsed = JSON.parse(await file.text());
    const sectionCount = parsed && typeof parsed === 'object' ? Object.keys(parsed).length : 0;
    showRestorePreview({
      name: file.name,
      integrity: 'Passed',
      sections: `${sectionCount} data section${sectionCount === 1 ? '' : 's'}`,
      size: formatBytes(file.size),
      message: 'Readable JSON preview complete. Open Business Suite to perform the actual restore. This file stayed on your device.'
    });
  } catch {
    showRestorePreview({
      name: file.name,
      integrity: 'Failed',
      sections: '—',
      size: formatBytes(file.size),
      message: 'This does not appear to be a readable Business Suite JSON backup. No file was uploaded.',
      error: true
    });
  } finally {
    event.target.value = '';
  }
});
