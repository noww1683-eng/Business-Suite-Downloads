# Business Suite website

This is the self-contained product website for `keralawebsitedesign.com`. Upload the contents of this directory to the domain's public web root while preserving the folder structure.

For a local preview, run this command from the repository root:

```bash
python3 -m http.server 8080 --directory website
```

Then open `http://localhost:8080`.

The website uses no external JavaScript, CSS, font, analytics or image service. It includes real Business Suite screenshots, responsive desktop/mobile layouts, a Basic/Advanced feature demo, official Windows/Android/Chrome download links, 7-day trial messaging, visual customer-guide links, and a local restore-file preview. The preview reads the selected JSON file inside the browser and does not upload or restore it.

Update the WhatsApp number in `index.html` if the customer-contact number changes. Replace `downloads/Business-Suite-Installation-Guides-English.zip` whenever the installation guide bundle is regenerated. Product download URLs point to the public `Business-Suite-Downloads` repository and should be updated when a new release is published.
