(() => {
  "use strict";
  const currencies = [
    ["INR", "Indian Rupee"],
    ["AED", "UAE Dirham"],
    ["SAR", "Saudi Riyal"],
    ["USD", "US Dollar"],
    ["EUR", "Euro"],
    ["GBP", "British Pound"],
    ["QAR", "Qatari Riyal"],
    ["OMR", "Omani Rial"],
    ["KWD", "Kuwaiti Dinar"],
    ["BHD", "Bahraini Dinar"],
    ["CAD", "Canadian Dollar"],
    ["AUD", "Australian Dollar"],
    ["SGD", "Singapore Dollar"],
    ["MYR", "Malaysian Ringgit"],
    ["JPY", "Japanese Yen"],
    ["CNY", "Chinese Yuan"],
    ["PKR", "Pakistani Rupee"],
    ["BDT", "Bangladeshi Taka"],
    ["LKR", "Sri Lankan Rupee"],
    ["NPR", "Nepalese Rupee"],
    ["ZAR", "South African Rand"],
    ["NGN", "Nigerian Naira"],
    ["KES", "Kenyan Shilling"]
  ];
  const codes = Object.freeze(currencies.map(([code]) => code));
  const normalize = code => codes.includes(String(code || "").toUpperCase())
    ? String(code).toUpperCase()
    : "INR";
  const format = (value, code = "INR") => new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: normalize(code),
    currencyDisplay: "code",
    maximumFractionDigits: 3
  }).format(Number(value) || 0);
  globalThis.BusinessCurrency = Object.freeze({
    codes,
    options: Object.freeze(currencies.map(([code, name]) => Object.freeze([code, `${code} — ${name}`]))),
    normalize,
    format
  });
})();
