const CACHE = "business-suite-web-v1";
const SHELL = [
  "./hub.html", "./hub.css", "./android-mobile.css", "./logo.png",
  "./pwa-icon-192.png", "./pwa-icon-512.png", "./manifest.webmanifest",
  "./desktop-platform.js", "./android-bridge.js", "./google-drive-web-config.js",
  "./drive-sync.js", "./drive-sync-core.js", "./drive-sync-store.js",
  "./drive-security.js", "./web-drive-api.js"
];
self.addEventListener("install", event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener("activate", event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET" || new URL(event.request.url).origin !== location.origin) return;
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
    return response;
  }).catch(() => caches.match(event.request).then(value => {
    if (value) return value;
    return event.request.mode === "navigate" ? caches.match("./hub.html") : Response.error();
  })));
});
