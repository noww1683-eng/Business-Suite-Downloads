if ("serviceWorker" in navigator && !window.__TAURI__ && location.protocol !== "chrome-extension:") {
  const googleSignIn = document.createElement("script");
  googleSignIn.src = "https://accounts.google.com/gsi/client";
  googleSignIn.async = true;
  document.head.append(googleSignIn);
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(console.error));
}
