"use strict";

const APP_URL = chrome.runtime.getURL("hub.html");
globalThis.badge = {p: 0};
globalThis.updateBadge = async () => {
  const text = badge.p > 0 ? String(Math.min(99, badge.p)) : "";
  await chrome.action.setBadgeBackgroundColor({color: "#ef4444"});
  await chrome.action.setBadgeText({text});
};

async function openApp() {
  const tabs = await chrome.tabs.query({url: APP_URL});
  if (tabs[0]?.id) {
    await chrome.tabs.update(tabs[0].id, {active: true});
    if (tabs[0].windowId) await chrome.windows.update(tabs[0].windowId, {focused: true});
    return tabs[0];
  }
  return chrome.tabs.create({url: APP_URL});
}

async function openWhatsApp({phone = "", text = "", mode = "window", file = false, ttl = 90000} = {}) {
  await chrome.storage.local.set({waPending: {t: Date.now(), phone, text, file, ttl}});
  const target = new URL("https://web.whatsapp.com/send");
  if (phone) target.searchParams.set("phone", String(phone).replace(/\D/g, ""));
  if (text) target.searchParams.set("text", text);
  const existing = await chrome.tabs.query({url: "https://web.whatsapp.com/*"});
  if (existing[0]?.id) {
    await chrome.tabs.update(existing[0].id, {url: target.href, active: true});
    if (existing[0].windowId) await chrome.windows.update(existing[0].windowId, {focused: true});
    return existing[0];
  }
  if (mode === "window") {
    return chrome.windows.create({url: target.href, type: "popup", width: 520, height: 760, focused: true});
  }
  return chrome.tabs.create({url: target.href});
}

globalThis.waOpen = openWhatsApp;
globalThis.bsLeaseOkSW = async () => {
  const {licLease} = await chrome.storage.local.get("licLease");
  if (!licLease?.lease) return false;
  try {
    const lease = JSON.parse(licLease.lease);
    return ["licensed", "trial"].includes(lease.status) && Date.now() < Number(lease.validUntil);
  } catch {
    return false;
  }
};

chrome.action.onClicked.addListener(() => openApp().catch(console.error));

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (!message || !["wa-open", "wa-save-file"].includes(message.type)) return;
  (async () => {
    if (message.type === "wa-open") {
      return openWhatsApp({
        phone: message.phone,
        text: message.text,
        mode: message.mode,
        file: !!message.file,
        ttl: message.ttl
      });
    }
    const {waFile} = await chrome.storage.local.get("waFile");
    if (!waFile?.b64) throw Error("PDF attachment is missing.");
    const safeName = String(waFile.name || "Business-Suite.pdf").replace(/[\\/:*?"<>|]+/g, "-");
    const id = await chrome.downloads.download({
      url: `data:${waFile.mime || "application/octet-stream"};base64,${waFile.b64}`,
      filename: `Business Suite/${safeName}`,
      saveAs: false
    });
    return {ok: true, id};
  })().then(value => respond(value || {ok: true}), error => respond({error: error?.message || String(error)}));
  return true;
});

importScripts("planner/bg.js", "daily.js");
