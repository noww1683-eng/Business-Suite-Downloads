// Public Ed25519 verification key. The signing private key stays on the server.
const LICENSE_CONFIG = Object.freeze({
  SERVER: "https://license.keralawebsitedesign.com/",
  PUBLIC_KEY: "+e+v3nIy/+JPIY+E6X0XzndVYHjjiiFqxMGw7aJ3v2k="
});
