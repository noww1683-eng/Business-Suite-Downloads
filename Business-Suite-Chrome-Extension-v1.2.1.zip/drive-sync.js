import {
  emptyState, projectBusiness, storagePatch, recordChanges, joinStates,
  materialize, resolveConflict, stateEqual, combineClocks, touchDevice, revokeDevice
} from "./drive-sync-core.js";
import {commitCloud} from "./drive-sync-store.js";
import {setupLocalBackup} from "./local-backup.js";
import {encryptSyncState, decryptSyncState, checkBusinessData} from "./drive-security.js";
import {appendAudit} from "./audit-history.js";
import {webDrive, googleAccess as webGoogleAccess} from "./web-drive-api.js";

const META_KEY = "driveSyncMetaV1";
const ENCRYPTION_KEY = "driveEncryptionV1";
const BUSINESS_KEYS = ["db", "settings", "trackerSuiteV4", "bsNotes"];
const invoke = window.__TAURI__?.core?.invoke;
const store = window.chrome?.storage?.local;
const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const webApp = !invoke;
const windowsApp = !!invoke && !mobile && /Windows|Win32|Win64/i.test(
  navigator.userAgentData?.platform || navigator.platform || navigator.userAgent
);
const directDrive = mobile || webApp || windowsApp;
const button = document.getElementById("driveBtn");
let status = {configured: false, connected: false}, meta = null, storage = {};
let pendingUpload = false, running = false, busy = false, timer = null;
let epoch = 0, localRevision = 0, failureCount = 0, lastMessage = "Not connected.", unsavedInput = false;
let encryption = {enabled: false}, encryptionPassword = "";
let persistQueue = Promise.resolve();
const ownCommits = new Set();
const GOOGLE_SCOPES = ["openid", "email", "https://www.googleapis.com/auth/drive.file"];
let googleConfig = {configured: false, clientId: ""}, googleTokens = null, googleAuthPromise = null;

const dialog = document.createElement("dialog");
dialog.className = "drive-dialog";
dialog.setAttribute("aria-labelledby", "driveHeading");
const driveIntro = directDrive
  ? 'Select your Google Account. Business Suite creates a visible <b>Business Suite</b> folder in your Google Drive and keeps this device in sync while the app is open.'
  : 'Install the official Google Drive for Desktop, sign in, then choose or create a <b>Business Suite</b> folder in your Google Drive. Choose the same synced folder on your other computers.';
dialog.innerHTML = '<h2 id="driveHeading">Google Drive automatic sync</h2><p>' + driveIntro + '</p><p class="drive-notice">Business Suite requests access only to Google Drive files and folders that you create or use with this app. Business data is saved as JSON sync files in the selected folder. Do not edit or delete those files. Your device license and PIN stay on this device. Each device needs an active app license.</p><div id="driveStatus" class="drive-status" role="status" aria-live="polite"></div><div class="drive-actions"><button id="driveInstall" type="button">Install Google Drive</button><button id="driveConnect" type="button">' + (directDrive ? 'Connect Google Drive' : 'Choose Google Drive folder') + '</button><button id="driveNow" type="button">Sync now</button><button id="driveApply" type="button" hidden>Apply Drive updates</button><button id="driveDisconnect" type="button">Stop Drive sync</button></div><div id="driveConflicts"></div><div class="drive-actions"><button id="driveClose" type="button">Close</button></div>';
document.body.append(dialog);
const $ = id => dialog.querySelector("#" + id);

const securityPanel = document.createElement("section");
securityPanel.className = "backup-panel";
securityPanel.innerHTML = '<h2>Sync security</h2><p>Optionally encrypt Drive sync files with a password. The password stays in memory and must be entered after restarting the app.</p><label class="drive-check"><input id="driveEncryptEnabled" type="checkbox"> Password-encrypt Drive files</label><div class="drive-actions"><input id="driveEncryptPassword" type="password" minlength="8" autocomplete="new-password" placeholder="At least 8 characters"><button id="driveEncryptSave" type="button">Save / unlock</button></div><div id="driveEncryptStatus" class="drive-status"></div><div id="driveIntegrity" class="drive-status"></div><button id="driveIntegrityNow" type="button">Check database integrity now</button>';
const devicesPanel = document.createElement("section");
devicesPanel.className = "backup-panel";
devicesPanel.innerHTML = '<h2>Connected devices</h2><p>Last sync times come from the shared Drive history. Disconnecting an old device blocks its next normal sync.</p><div id="driveDevices"></div>';
$("driveConflicts").after(securityPanel, devicesPanel);

function message(text, error = false) {
  lastMessage = text;
  $("driveStatus").textContent = (status.connected && status.email ? status.email + "\n" : "") + text;
  button.dataset.error = String(error);
  button.title = "Google Drive: " + text;
}

function syncVisual(state) {
  button.dataset.state = state;
}

function deviceName() {
  return String(navigator.userAgentData?.platform || navigator.platform || "Business Suite device").slice(0, 120);
}

function renderDevices() {
  const container = $("driveDevices");
  const devices = Object.entries(meta?.state?.devices || {}).sort((a, b) => b[1].lastSeen - a[1].lastSeen);
  container.replaceChildren();
  if (!devices.length) { container.textContent = "No synced devices recorded yet."; return; }
  for (const [id, device] of devices) {
    const row = document.createElement("div"); row.className = "drive-device";
    const description = document.createElement("span");
    description.textContent = device.name + (id === status.writerId ? " · This device" : "") + "\n" + (device.lastSeen ? "Last sync: " + new Date(device.lastSeen).toLocaleString() : "Not synced yet") + (device.revoked ? " · Disconnected" : "");
    row.append(description);
    if (id !== status.writerId && !device.revoked) {
      const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "Disconnect";
      remove.addEventListener("click", () => {
        if (!confirm("Disconnect " + device.name + "? That device will be stopped on its next sync.")) return;
        meta.state = revokeDevice(meta.state, id); meta.pending = true; pendingUpload = true;
        renderDevices(); saveMeta().then(() => schedule(0)).catch(error => message(String(error), true));
      });
      row.append(remove);
    }
    container.append(row);
  }
}

async function runIntegrity() {
  const current = await store.get(BUSINESS_KEYS);
  const result = checkBusinessData(current);
  await store.set({businessIntegrityV1: result});
  $("driveIntegrity").textContent = result.ok ? "✓ Database integrity check passed · " + new Date(result.checkedAt).toLocaleString() : "Integrity problem found:\n" + result.problems.join("\n");
  $("driveIntegrity").dataset.error = String(!result.ok);
  return result;
}

function showEncryption() {
  $("driveEncryptEnabled").checked = encryption.enabled;
  $("driveEncryptStatus").textContent = encryption.enabled ? (encryptionPassword ? "✓ Encryption is enabled and unlocked for this session." : "Encryption is enabled. Enter the password to unlock sync.") : "Encryption is off. Drive files use readable JSON.";
}

function refreshButtons() {
  $("driveInstall").disabled = busy || !invoke || directDrive;
  $("driveConnect").disabled = busy || status.connected || (directDrive && !status.configured) || (!invoke && !webApp);
  $("driveNow").disabled = busy || !status.connected;
  $("driveDisconnect").disabled = busy || !status.connected;
  $("driveInstall").hidden = directDrive;
  $("driveConnect").hidden = status.connected;
  $("driveNow").hidden = !status.connected;
  $("driveDisconnect").hidden = !status.connected;
}

async function googleAccess(interactive = false) {
  if (webApp) return webGoogleAccess(interactive);
  if (windowsApp) return invoke("google_drive_access", {interactive});
  if (!mobile) return "";
  if (!googleConfig.configured || !googleConfig.clientId) throw Error("Google Drive connection is not configured in this mobile build.");
  const now = Math.floor(Date.now() / 1000);
  if (googleTokens?.accessToken && (!googleTokens.expiresAt || googleTokens.expiresAt > now + 120)) return googleTokens.accessToken;
  if (googleAuthPromise) return googleAuthPromise;
  googleAuthPromise = (async () => {
    const payload = {clientId: googleConfig.clientId, scopes: GOOGLE_SCOPES};
    if (/Android/i.test(navigator.userAgent)) payload.flowType = "native";
    try {
      googleTokens = interactive
        ? await invoke("plugin:google-auth|sign_in", {payload: {...payload, prompt: "select_account"}})
        : await invoke("plugin:google-auth|refresh_token", {payload});
      if (!googleTokens?.accessToken) throw Error("Google sign-in did not return an access token.");
      return googleTokens.accessToken;
    } catch (error) {
      googleTokens = null;
      throw Error(interactive ? String(error) : "Google Drive sign-in expired. Open Drive and connect again.");
    } finally { googleAuthPromise = null; }
  })();
  return googleAuthPromise;
}

async function driveInvoke(command, args = {}, interactive = false) {
  if (webApp) {
    if (["drive_connect", "drive_pull", "drive_put"].includes(command)) await googleAccess(interactive);
    return webDrive[command](args, interactive);
  }
  if ((!mobile && !windowsApp) || !["drive_connect", "drive_pull", "drive_put"].includes(command)) return invoke(command, args);
  return invoke(command, {...args, accessToken: await googleAccess(interactive)});
}

function saveMeta() {
  if (!meta) return persistQueue;
  const value = structuredClone(meta);
  persistQueue = persistQueue.catch(() => {}).then(() => store.set({[META_KEY]: value}));
  return persistQueue;
}

function captureChanges(changes) {
  const marker = changes[META_KEY]?.newValue?.commitId;
  if (marker && ownCommits.delete(marker)) return;
  if (!BUSINESS_KEYS.some(key => key in changes)) return;
  localRevision++;
  const before = projectBusiness(storage);
  for (const key of BUSINESS_KEYS) if (key in changes) {
    if (changes[key].newValue === undefined) delete storage[key];
    else storage[key] = structuredClone(changes[key].newValue);
  }
  const after = projectBusiness(storage);
  if (!meta || !status.connected) return;
  if (stateEqual(before, after)) return;
  unsavedInput = false;
  meta.state = recordChanges(meta.state, before, after, status.writerId, meta.visibleClock);
  meta.visibleClock[status.writerId] = meta.state.clock[status.writerId] || 0;
  meta.observed = structuredClone(after);
  meta.pending = true; pendingUpload = true;
  saveMeta().catch(error => message(String(error), true));
  message("Changes saved on this computer. Syncing soon…");
  syncVisual("pending");
  schedule(2000);
}

function watchFrames() {
  for (const frame of document.querySelectorAll("#stage iframe")) {
    frame.addEventListener("load", () => {
      try { frame.contentDocument.addEventListener("input", () => unsavedInput = true, true); } catch {}
    });
  }
}

function conflictLabel(encoded) {
  const labels = {"k:db": "Planner", "k:profile": "Business profile", "k:tracker": "Work Tracker", "k:notes": "Notes"};
  return JSON.parse(encoded).map(part => labels[part] || (part.startsWith("i:") ? "Record " + part.slice(2, 14) : part.slice(2))).join(" · ");
}

function describe(node) {
  if (node.type === "deleted") return "Keep deletion";
  if (node.type === "object" || node.type === "array") return "Keep edited record";
  const value = typeof node.value === "string" ? node.value : JSON.stringify(node.value);
  return String(value).slice(0, 160) || "(empty)";
}

function showConflicts(conflicts) {
  const container = $("driveConflicts");
  container.replaceChildren();
  for (const conflict of conflicts.slice(0, 20)) {
    const item = document.createElement("div"); item.className = "drive-conflict";
    const title = document.createElement("strong"); title.textContent = conflictLabel(conflict.path);
    const help = document.createElement("p"); help.textContent = "Two devices changed this record. Choose the version to keep.";
    const actions = document.createElement("div"); actions.className = "drive-actions";
    conflict.choices.forEach((node, index) => {
      const choose = document.createElement("button"); choose.type = "button";
      choose.textContent = describe(node);
      choose.addEventListener("click", () => {
        try {
          meta.state = resolveConflict(meta.state, conflict, index, status.writerId);
          meta.pending = true; pendingUpload = true;
          saveMeta().then(() => schedule(0)).catch(error => message(String(error), true));
        } catch (error) { message(String(error), true); schedule(0); }
      });
      if (node.type === "value") {
        const details = document.createElement("details");
        const summary = document.createElement("summary"); summary.textContent = "View full version";
        const content = document.createElement("pre");
        content.textContent = typeof node.value === "string" ? node.value : JSON.stringify(node.value, null, 2);
        details.append(summary, content); actions.append(details);
      }
      actions.append(choose);
    });
    item.append(title, help, actions); container.append(item);
  }
}

function hasLocalRecords(data) {
  if (data.notes.length || Object.values(data.db).some(v => Array.isArray(v) && v.length)) return true;
  if (data.tracker.businesses.some(b => Object.values(b.data || {}).some(v => Array.isArray(v) && v.length))) return true;
  return ["phone", "email", "gstin", "address"].some(k => data.profile[k]) ||
    (data.profile.name && !["your business", "my business", "business planner", "business suite"].includes(data.profile.name.toLowerCase()));
}

async function initialize(connected) {
  status = connected;
  meta = null;
  let saved, revision;
  do {
    revision = localRevision;
    saved = await store.get([...BUSINESS_KEYS, META_KEY]);
  } while (revision !== localRevision);
  storage = Object.fromEntries(BUSINESS_KEYS.filter(k => k in saved).map(k => [k, saved[k]]));
  const previous = saved[META_KEY];
  if (previous?.accountId && previous.accountId !== status.accountId &&
      !confirm("You selected a different sync folder. Merge this computer's business data into " + (status.email || "that folder") + "?")) {
    await driveInvoke("drive_disconnect");
    status.connected = false; refreshButtons();
    message("Folder change cancelled. Local records were kept.");
    return;
  }
  if (previous?.accountId === status.accountId) {
    meta = previous;
    meta.writerId = status.writerId;
    meta.pending = true;
    const current = projectBusiness(storage);
    if (meta.observed && !stateEqual(meta.observed, current)) {
      meta.state = recordChanges(meta.state, meta.observed, current, status.writerId, meta.visibleClock);
      meta.pending = true;
    }
  } else {
    // A lost local clock must never reuse an old device's revision numbers.
    status = await driveInvoke("drive_rotate_writer");
    const data = projectBusiness(storage);
    meta = {
      accountId: status.accountId, writerId: status.writerId, state: emptyState(),
      visibleClock: {}, observed: data, pending: false
    };
    if (hasLocalRecords(data)) {
      meta.state = recordChanges(meta.state, {}, data, status.writerId);
      meta.visibleClock = structuredClone(meta.state.clock);
      meta.pending = true;
    }
  }
  meta.observed = projectBusiness(storage);
  meta.state = touchDevice(meta.state, status.writerId, deviceName());
  meta.pending = true;
  pendingUpload = !!meta.pending;
  await saveMeta();
  renderDevices();
  refreshButtons();
  schedule(0);
}

async function applyCloud(data, state, currentEpoch) {
  if (currentEpoch !== epoch || unsavedInput) {
    $("driveApply").hidden = false;
    return false;
  }
  const revision = localRevision;
  const current = await store.get(BUSINESS_KEYS);
  if (revision !== localRevision || currentEpoch !== epoch) return false;
  if (!stateEqual(projectBusiness(current), projectBusiness(storage))) {
    const changes = {};
    for (const key of BUSINESS_KEYS) changes[key] = {newValue: current[key]};
    captureChanges(changes);
    return false;
  }
  const changesData = !stateEqual(data, projectBusiness(current));
  await persistQueue;
  if (revision !== localRevision || currentEpoch !== epoch) return false;
  const writtenMeta = {...structuredClone(meta), visibleClock: combineClocks(state.clock), observed: structuredClone(data)};
  const commitId = crypto.randomUUID();
  writtenMeta.commitId = commitId;
  const patch = changesData ? storagePatch(data, current) : {};
  ownCommits.add(commitId);
  const stage = document.getElementById("stage"), rail = document.getElementById("rail");
  stage.inert = true; rail.inert = true;
  try {
    const committed = await commitCloud(current, patch, writtenMeta, () => currentEpoch === epoch && status.connected);
    if (!committed) {
      ownCommits.delete(commitId);
      return false;
    }
    meta.visibleClock = writtenMeta.visibleClock;
    meta.observed = writtenMeta.observed;
    for (const key of BUSINESS_KEYS) if (key in patch) storage[key] = structuredClone(patch[key]);
    $("driveApply").hidden = true;
    const reloaded = [];
    if (changesData) {
      for (const frame of document.querySelectorAll("#stage iframe")) {
        if (!["f-planner", "f-tracker"].includes(frame.id)) continue;
        try { frame.contentWindow.__bsRefreshState?.capture(); } catch {}
        if (!frame.hidden && frame.getAttribute("src") && frame.getAttribute("src") !== "about:blank") {
          reloaded.push(new Promise(resolve => {
            frame.addEventListener("load", resolve, {once: true});
            setTimeout(resolve, 5000);
          }));
          frame.contentWindow.location.reload();
        } else if (frame.dataset.loaded === "1") {
          frame.src = "about:blank"; frame.dataset.loaded = "0";
        }
      }
    }
    await Promise.all(reloaded);
    if (changesData) await appendAudit(store, {action: "Drive merge", detail: "Applied synced changes from another device."});
    return true;
  } catch (error) {
    ownCommits.delete(commitId);
    throw error;
  } finally {
    stage.inert = false; rail.inert = false;
  }
}

async function sync() {
  if (!status.connected || !meta || running) return;
  if (busy) { schedule(20000); return; }
  if (typeof LIC !== "undefined" && !LIC.ok) { schedule(20000); return; }
  if (encryption.enabled && !encryptionPassword) { message("Encrypted sync is locked. Open Drive and enter the encryption password.", true); syncVisual("error"); return; }
  running = true;
  syncVisual("syncing");
  message("Syncing with the selected Google Drive folder…");
  const currentEpoch = epoch;
  try {
    await saveMeta();
    const pulled = await driveInvoke("drive_pull");
    const remote = await Promise.all(pulled.map(value => decryptSyncState(value, encryptionPassword)));
    if (epoch !== currentEpoch || !status.connected) return;
    meta.state = joinStates(meta.state, ...remote);
    if (meta.state.devices?.[status.writerId]?.revoked) {
      await driveInvoke("drive_disconnect"); status.connected = false; meta = null; refreshButtons(); renderDevices();
      message("This device was disconnected by another synced device. Local data was kept.", true); syncVisual("off"); return;
    }
    const ownDevice = meta.state.devices?.[status.writerId];
    if (!ownDevice || Date.now() - ownDevice.lastSeen >= 10 * 60 * 1000) {
      meta.state = touchDevice(meta.state, status.writerId, deviceName()); meta.pending = true; pendingUpload = true;
    }
    renderDevices();
    if (!remote.length && Object.keys(meta.state.nodes).length) {
      pendingUpload = true; meta.pending = true;
    }
    const {data, conflicts} = materialize(meta.state);
    showConflicts(conflicts);
    if (conflicts.length) {
      await saveMeta();
      message(conflicts.length + " sync conflict(s). Choose the versions to keep below.", true);
      failureCount = 0; return;
    }
    const applied = !data || await applyCloud(data, meta.state, currentEpoch);
    if (pendingUpload && epoch === currentEpoch) {
      await saveMeta(); // Persist revision numbers before publishing them.
      const uploading = structuredClone(meta.state);
      const body = encryption.enabled ? JSON.stringify(await encryptSyncState(uploading, encryptionPassword)) : JSON.stringify(uploading);
      await driveInvoke("drive_put", {body});
      if (epoch !== currentEpoch) return;
      if (stateEqual(meta.state, uploading)) {
        pendingUpload = false; meta.pending = false; await saveMeta();
      }
    }
    failureCount = 0;
    message(applied ? "Automatic sync is on. Last checked " + new Date().toLocaleTimeString() + "." : "Changes are uploaded. Save your form edits before applying Drive updates.");
    syncVisual(applied ? "synced" : "pending");
  } catch (error) {
    failureCount++;
    message(String(error) + "\nYour changes remain saved on this computer.", true);
    syncVisual("error");
  } finally {
    running = false;
    if (status.connected) schedule(Math.min(300000, failureCount ? 20000 * 2 ** Math.min(failureCount, 4) : 20000));
  }
}

function schedule(delay) {
  clearTimeout(timer);
  if (status.connected) timer = setTimeout(sync, delay);
}

button.addEventListener("click", () => {
  if (!document.getElementById("lockedNote").hidden) return;
  refreshButtons(); message(lastMessage, button.dataset.error === "true"); dialog.showModal();
});
$("driveClose").addEventListener("click", () => dialog.close());
$("driveInstall").addEventListener("click", () => invoke("open_external", {url: "https://www.google.com/drive/download/"}).catch(error => message(String(error), true)));
$("driveNow").addEventListener("click", () => schedule(0));
$("driveApply").addEventListener("click", () => {
  if (unsavedInput && !confirm("Apply Drive updates now? Unsaved form entries will be discarded.")) return;
  unsavedInput = false; schedule(0);
});
$("driveConnect").addEventListener("click", async () => {
  busy = true; refreshButtons(); message(directDrive ? "Opening secure Google sign-in…" : "Choose or create the Business Suite folder inside Google Drive…");
  const myEpoch = ++epoch;
  try {
    const connected = await driveInvoke("drive_connect", {}, true);
    if (epoch === myEpoch) { syncVisual("syncing"); await initialize(connected); }
  } catch (error) { message(String(error), true); }
  finally { busy = false; refreshButtons(); }
});
$("driveDisconnect").addEventListener("click", async () => {
  busy = true; epoch++; clearTimeout(timer); refreshButtons();
  try {
    await driveInvoke("drive_disconnect");
    let signOutWarning = "";
    if (mobile && !webApp) {
      const accessToken = googleTokens?.accessToken;
      googleTokens = null;
      await invoke("plugin:google-auth|sign_out", {payload: accessToken ? {accessToken} : {}}).catch(() => {});
    }
    if (windowsApp) {
      await invoke("google_drive_sign_out").catch(error => { signOutWarning = String(error); });
    }
    status.connected = false; meta = null; showConflicts([]);
    syncVisual("off");
    message(signOutWarning
      ? "Drive sync stopped, but the saved Google sign-in could not be removed: " + signOutWarning
      : "Drive sync stopped. Your local data and existing Drive files were kept.", !!signOutWarning);
  } catch (error) { message(String(error), true); }
  finally { busy = false; refreshButtons(); }
});

$("driveEncryptSave").addEventListener("click", async () => {
  const enabled = $("driveEncryptEnabled").checked;
  const password = $("driveEncryptPassword").value;
  if (encryption.enabled && !enabled) { $("driveEncryptEnabled").checked = true; return message("To stop encryption, disconnect and choose a new empty sync folder. Existing encrypted history cannot safely be mixed with an unlocked folder.", true); }
  if (enabled && password.length < 8) return message("Encryption password must be at least 8 characters.", true);
  encryption = {enabled}; encryptionPassword = enabled ? password : "";
  $("driveEncryptPassword").value = "";
  await store.set({[ENCRYPTION_KEY]: encryption}); showEncryption();
  if (meta) { meta.pending = true; pendingUpload = true; await saveMeta(); schedule(0); }
  message(enabled ? "Drive encryption enabled. Use the same password on every device." : "Drive encryption disabled. The next sync file will use readable JSON.");
});
$("driveIntegrityNow").addEventListener("click", () => runIntegrity().catch(error => message(String(error), true)));

watchFrames();
new MutationObserver(() => {
  if (!document.getElementById("lockedNote").hidden && dialog.open) dialog.close();
}).observe(document.getElementById("lockedNote"), {attributes: true, attributeFilter: ["hidden"]});
if (store && (invoke || webApp)) {
  const securityReady = store.get([ENCRYPTION_KEY, "businessIntegrityV1"]).then(saved => {
    encryption = {enabled: !!saved[ENCRYPTION_KEY]?.enabled}; showEncryption();
    const check = saved.businessIntegrityV1;
    if (check) { $("driveIntegrity").textContent = check.ok ? "✓ Last integrity check passed · " + new Date(check.checkedAt).toLocaleString() : "Last integrity check found a problem:\n" + check.problems.join("\n"); $("driveIntegrity").dataset.error = String(!check.ok); }
    return runIntegrity();
  }).catch(error => message("Integrity check: " + String(error), true));
  setupLocalBackup({
    dialog, store, invoke,
    beforeRestore: () => !unsavedInput || confirm("There are unsaved form entries. Discard them and continue restoring?"),
    onRestore: async () => {
      unsavedInput = false;
      for (const frame of document.querySelectorAll("#stage iframe")) {
        if (!["f-planner", "f-tracker"].includes(frame.id) || frame.dataset.loaded !== "1") continue;
        try { frame.contentWindow.__bsRefreshState?.capture(); } catch {}
        if (frame.hidden) { frame.src = "about:blank"; frame.dataset.loaded = "0"; }
        else frame.contentWindow.location.reload();
      }
      if (status.connected) { syncVisual("pending"); schedule(1000); }
    }
  }).catch(error => message("Local backup: " + String(error), true));
  window.chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") {
      try { captureChanges(changes); } catch (error) { message(String(error), true); }
    }
  });
  securityReady.then(async () => {
    if (webApp) googleConfig = webDrive.config();
    else if (mobile || windowsApp) googleConfig = await invoke("google_drive_config");
    return driveInvoke("drive_status");
  }).then(async connected => {
    status = connected;
    if (connected.connected) { syncVisual("syncing"); await initialize(connected); }
    else {
      syncVisual("off");
      message(directDrive
        ? (connected.configured ? "Connect your Google account to start automatic sync." : "Google Drive OAuth Client ID must be added to this app build.")
        : "Choose a folder inside Google Drive for Desktop to start automatic sync.");
    }
    refreshButtons();
  }).catch(error => { message(String(error), true); refreshButtons(); });
} else {
  syncVisual("off");
  message("Google Drive sync is unavailable because the native app bridge did not start.");
  refreshButtons();
}
