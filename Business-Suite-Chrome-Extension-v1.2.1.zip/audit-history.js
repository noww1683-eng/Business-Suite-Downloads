export const AUDIT_KEY = "restoreAuditV1";

export async function appendAudit(store, entry) {
  const current = await store.get(AUDIT_KEY);
  const history = Array.isArray(current[AUDIT_KEY]) ? current[AUDIT_KEY] : [];
  const item = {id: crypto.randomUUID(), at: Date.now(), action: String(entry.action || "Data change").slice(0, 80), detail: String(entry.detail || "").slice(0, 500)};
  await store.set({[AUDIT_KEY]: [item, ...history].slice(0, 100)});
  return item;
}

export function normalizeAudit(value) {
  if (!Array.isArray(value)) return [];
  return value.filter(item => item && typeof item.id === "string" && Number.isSafeInteger(item.at) && typeof item.action === "string" && typeof item.detail === "string").slice(0, 100);
}
