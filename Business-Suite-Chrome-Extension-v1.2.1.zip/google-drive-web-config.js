// Public OAuth identifier. Never put a Google Client Secret here.
globalThis.BUSINESS_SUITE_GOOGLE_WEB_CLIENT_ID = "303163879482-njcbc5ajaska2ijnlptup5b6c64muu2b.apps.googleusercontent.com";
