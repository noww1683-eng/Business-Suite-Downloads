export const ENCRYPTED_FORMAT = "business-suite-drive-encrypted";
const ITERATIONS = 310000;
const encoder = new TextEncoder();
const decoder = new TextDecoder();
const b64 = bytes => {
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  return btoa(binary);
};
const unb64 = value => Uint8Array.from(atob(value), char => char.charCodeAt(0));

async function keyFor(password, salt, usage) {
  if (typeof password !== "string" || password.length < 8) throw Error("The Drive encryption password must be at least 8 characters.");
  const material = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({name: "PBKDF2", hash: "SHA-256", iterations: ITERATIONS, salt}, material, {name: "AES-GCM", length: 256}, false, usage);
}

export async function encryptSyncState(state, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keyFor(password, salt, ["encrypt"]);
  const encrypted = await crypto.subtle.encrypt({name: "AES-GCM", iv}, key, encoder.encode(JSON.stringify(state)));
  return {format: ENCRYPTED_FORMAT, schema: 1, kdf: {name: "PBKDF2", hash: "SHA-256", iterations: ITERATIONS, salt: b64(salt)}, cipher: {name: "AES-GCM", iv: b64(iv)}, data: b64(new Uint8Array(encrypted))};
}

export async function decryptSyncState(value, password) {
  if (value?.format !== ENCRYPTED_FORMAT) return value;
  if (value.schema !== 1 || value.kdf?.name !== "PBKDF2" || value.kdf?.hash !== "SHA-256" || value.kdf?.iterations !== ITERATIONS || value.cipher?.name !== "AES-GCM" || typeof value.data !== "string") throw Error("Unsupported encrypted Drive sync file.");
  try {
    const salt = unb64(value.kdf.salt), iv = unb64(value.cipher.iv);
    if (salt.length !== 16 || iv.length !== 12 || value.data.length > 60 * 1024 * 1024) throw Error();
    const key = await keyFor(password, salt, ["decrypt"]);
    return JSON.parse(decoder.decode(await crypto.subtle.decrypt({name: "AES-GCM", iv}, key, unb64(value.data))));
  } catch {
    throw Error("Drive sync is encrypted. Enter the same password used on the other device.");
  }
}

export function checkBusinessData(storage) {
  const problems = [];
  const inspect = (label, value) => {
    if (value === undefined) return;
    if (!value || typeof value !== "object" || Array.isArray(value)) { problems.push(label + " is not a database object."); return; }
    for (const [name, records] of Object.entries(value)) {
      if (!Array.isArray(records)) continue;
      const ids = new Set();
      for (const record of records) {
        if (!record || typeof record !== "object" || Array.isArray(record)) { problems.push(label + "." + name + " contains an invalid record."); continue; }
        if (typeof record.id !== "string" || !record.id) problems.push(label + "." + name + " contains a record without an ID.");
        else if (ids.has(record.id)) problems.push(label + "." + name + " contains duplicate ID " + record.id + ".");
        else ids.add(record.id);
      }
    }
  };
  inspect("Planner", storage.db);
  for (const business of storage.trackerSuiteV4?.businesses || []) inspect("Tracker " + (business.name || business.id || "business"), business.data);
  if (storage.bsNotes !== undefined && !Array.isArray(storage.bsNotes)) problems.push("Notes is not a record list.");
  return {checkedAt: Date.now(), ok: !problems.length, problems: problems.slice(0, 50)};
}
