(() => {
  "use strict";

  // Planner pages can be refreshed without replacing the WebView. Tear down
  // the previous delegated listener so a completed export cannot leave a
  // stale `saving` closure that blocks every later download.
  window.__businessSuiteExportOptions?.destroy?.();
  document.getElementById("exportFormatDialog")?.remove();

  const dialog = document.createElement("dialog");
  dialog.id = "exportFormatDialog";
  dialog.innerHTML = `
    <form method="dialog" class="export-format-card">
      <button class="export-close" value="cancel" aria-label="Close">×</button>
      <div class="export-mark">↓</div>
      <h2>Download file</h2>
      <p id="exportFormatTarget">Choose the file format.</p>
      <div class="export-format-grid">
        <button type="button" data-export-format="pdf"><b>PDF</b><span>Easy to read and print</span></button>
        <button type="button" data-export-format="csv"><b>CSV</b><span>Open in Excel or Sheets</span></button>
      </div>
      <p class="export-progress" role="status" hidden></p>
    </form>`;
  document.body.append(dialog);

  let selectedModule = null;
  const target = dialog.querySelector("#exportFormatTarget");
  const progress = dialog.querySelector(".export-progress");
  const closeButton = dialog.querySelector(".export-close");
  const formatButtons = [...dialog.querySelectorAll("[data-export-format]")];
  let saving = false;
  let saveGeneration = 0;
  const pad = value => String(value).padStart(2, "0");
  const stamp = () => {
    const now = new Date();
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  };
  const modules = () => {
    const list = selectedModule ? [selectedModule] : exportable();
    return list.filter(module => rows(module.id).length);
  };
  const clean = value => {
    if (value == null) return "";
    if (typeof value === "object") return JSON.stringify(value);
    return String(value).replace(/\s+/g, " ").trim();
  };
  const csvQuote = value => {
    let text = clean(value);
    if (/^[\s]*[=+@-]/.test(text)) text = "'" + text;
    return `"${text.replace(/"/g, '""')}"`;
  };
  const fileBase = () => selectedModule
    ? `Business-Suite-${selectedModule.id}-${stamp()}`
    : `Business-Suite-All-Data-${stamp()}`;
  async function saveFile(name, contents, mime) {
    const blob = contents instanceof Blob ? contents : new Blob([contents], {type: mime});
    if (location.protocol === "chrome-extension:") {
      const url = URL.createObjectURL(blob);
      const safeName = String(name).replace(/[\\/:*?"<>|]+/g, "-");
      try {
        const id = await chrome.downloads.download({
          url,
          filename: `Business Suite/${safeName}`,
          saveAs: false
        });
        await new Promise((resolve, reject) => {
          const timer = setTimeout(() => finish(Error("Download timed out")), 120000);
          const finish = error => {
            clearTimeout(timer);
            chrome.downloads.onChanged.removeListener(changed);
            error ? reject(error) : resolve();
          };
          const changed = delta => {
            if (delta.id !== id) return;
            if (delta.error?.current) finish(Error(delta.error.current));
            else if (delta.state?.current === "complete") finish();
          };
          chrome.downloads.onChanged.addListener(changed);
          chrome.downloads.search({id}).then(items => {
            if (items[0]?.state === "complete") finish();
            else if (items[0]?.error) finish(Error(items[0].error));
          }).catch(() => {});
        });
        return {saved: true, name: safeName, path: "Downloads/Business Suite"};
      } finally {
        URL.revokeObjectURL(url);
      }
    }
    const b64 = await PdfShare.blobToBase64(blob);
    const result = await BSAndroid.call("save", {b64, name, mime});
    if (result === false || (result && typeof result === "object" && result.saved === false)) {
      throw Error("The file was not saved");
    }
    return result && typeof result === "object"
      ? result
      : {saved: true, name, path: ""};
  }

  function setBusy(value) {
    saving = value;
    formatButtons.forEach(button => button.disabled = value);
    // Saving is native and can finish after this dialog closes. Never trap
    // the user inside the modal while Android writes the file.
    closeButton.disabled = false;
  }

  function resetStatus() {
    progress.hidden = true;
    progress.textContent = "";
    progress.classList.remove("error", "success");
  }

  function combinedCsv(list) {
    const output = ["\ufeffBusiness Suite export", `Created,${new Date().toLocaleString()}`, ""];
    for (const module of list) {
      const records = rows(module.id);
      const keys = [...new Set(records.flatMap(record => Object.keys(record)))];
      output.push(csvQuote(module.n), csvQuote(`${records.length} records`));
      output.push(keys.map(csvQuote).join(","));
      for (const record of records) output.push(keys.map(key => csvQuote(record[key])).join(","));
      output.push("");
    }
    return output.join("\r\n");
  }

  function reportLines(list) {
    const lines = [
      {text: biz().name || "Business Suite", kind: "title"},
      {text: `Data report · ${new Date().toLocaleString()}`, kind: "sub"},
      {text: `${list.reduce((total, module) => total + rows(module.id).length, 0)} records`, kind: "sub"}
    ];
    for (const module of list) {
      const records = rows(module.id);
      lines.push({text: `${module.i || ""} ${module.n} (${records.length})`, kind: "heading"});
      records.forEach((record, index) => {
        const values = Object.entries(record)
          .filter(([, value]) => value !== "" && value != null)
          .map(([key, value]) => `${key}: ${clean(value)}`)
          .join("  ·  ");
        lines.push({text: `${index + 1}. ${values || "Empty record"}`, kind: "row"});
      });
    }
    return lines;
  }

  function wrap(ctx, text, width) {
    const words = String(text).split(/\s+/);
    const lines = [];
    let line = "";
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(next).width > width) {
        lines.push(line);
        line = word;
      } else line = next;
    }
    if (line) lines.push(line);
    return lines.length ? lines : [""];
  }

  const canvasJpeg = canvas => new Promise((resolve, reject) => canvas.toBlob(
    async blob => blob ? resolve(new Uint8Array(await blob.arrayBuffer())) : reject(Error("Could not create PDF page")),
    "image/jpeg",
    0.78
  ));

  async function createPdf(list) {
    const width = 1240, height = 1754, left = 82, right = 82, top = 92, bottom = 92;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    const pages = [];
    let y = top, page = 1;
    const reset = () => {
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = "#0b2450";
      ctx.fillRect(0, 0, width, 24);
      ctx.fillStyle = "#64748b";
      ctx.font = "18px sans-serif";
      ctx.fillText(`Business Suite · Page ${page}`, left, height - 38);
      y = top;
    };
    const finish = async () => {
      pages.push({jpeg: await canvasJpeg(canvas), w: width, h: height});
      page += 1;
      reset();
    };
    reset();
    for (const item of reportLines(list)) {
      const style = item.kind === "title"
        ? {font: "bold 42px sans-serif", size: 42, color: "#0b2450", before: 0, after: 22}
        : item.kind === "heading"
          ? {font: "bold 27px sans-serif", size: 27, color: "#2364e8", before: 30, after: 14}
          : item.kind === "sub"
            ? {font: "21px sans-serif", size: 21, color: "#64748b", before: 0, after: 10}
            : {font: "20px sans-serif", size: 20, color: "#172033", before: 4, after: 12};
      ctx.font = style.font;
      const wrapped = wrap(ctx, item.text, width - left - right);
      const required = style.before + wrapped.length * (style.size + 10) + style.after;
      if (y + required > height - bottom) await finish();
      y += style.before;
      ctx.font = style.font;
      ctx.fillStyle = style.color;
      for (const line of wrapped) {
        ctx.fillText(line, left, y);
        y += style.size + 10;
        if (y > height - bottom) await finish();
      }
      y += style.after;
    }
    if (y > top || !pages.length) await finish();
    return new Blob([PdfShare.buildPdf(pages)], {type: "application/pdf"});
  }

  async function save(format) {
    if (saving) return;
    const generation = ++saveGeneration;
    const list = modules();
    if (!list.length) {
      toast("Nothing to export yet", true);
      dialog.close();
      return;
    }
    setBusy(true);
    progress.hidden = false;
    progress.classList.remove("error", "success");
    progress.textContent = format === "pdf" ? "Preparing PDF…" : "Preparing CSV…";
    try {
      const name = `${fileBase()}.${format}`;
      let result;
      if (format === "pdf") {
        const pdf = await createPdf(list);
        progress.textContent = "Saving PDF to Downloads…";
        result = await saveFile(name, pdf, "application/pdf");
      } else {
        progress.textContent = "Saving CSV to Downloads…";
        result = await saveFile(name, combinedCsv(list), "text/csv");
      }
      if (generation !== saveGeneration) return;
      const savedName = result.name || name;
      progress.textContent = result.path
        ? `✓ ${format.toUpperCase()} download complete\nSaved in ${result.path}`
        : `✓ ${format.toUpperCase()} download complete\n${savedName} saved successfully`;
      progress.classList.add("success");
      toast(`${format.toUpperCase()} download complete ✓`);
      setTimeout(() => {
        if (dialog.open) dialog.close();
      }, 900);
    } catch (error) {
      if (generation !== saveGeneration) return;
      progress.textContent = `Download failed: ${error?.message || error}`;
      progress.classList.add("error");
    } finally {
      if (generation === saveGeneration) setBusy(false);
    }
  }

  formatButtons.forEach(button => button.addEventListener("click", () => save(button.dataset.exportFormat)));
  dialog.addEventListener("close", () => {
    saveGeneration += 1;
    setBusy(false);
    resetStatus();
    selectedModule = null;
  });
  const openExportDialog = event => {
    const button = event.target.closest?.('[data-act="exportAll"], [data-act="exportOne"]');
    if (!button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (saving) {
      toast("The current download is still finishing", true);
      return;
    }
    selectedModule = button.dataset.act === "exportOne" ? modById[button.dataset.m] : null;
    target.textContent = selectedModule
      ? `${selectedModule.n}: choose PDF or CSV.`
      : "All Planner data: choose PDF or CSV.";
    resetStatus();
    setBusy(false);
    dialog.showModal();
  };
  document.addEventListener("click", openExportDialog, true);
  window.__businessSuiteExportOptions = {
    destroy() {
      document.removeEventListener("click", openExportDialog, true);
      saveGeneration += 1;
      setBusy(false);
      if (dialog.open) dialog.close();
      dialog.remove();
    }
  };
})();
