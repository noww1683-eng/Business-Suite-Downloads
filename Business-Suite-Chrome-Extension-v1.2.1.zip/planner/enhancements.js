"use strict";
(() => {
  const core = globalThis.PlannerEnhanceCore;
  if (!core || typeof state === "undefined") return;
  const FILTER_MODULES = new Set(["customers", "leads", "sales", "payments"]);
  const filters = {};
  let deleted = null, undoTimer = null, saveTimer = null;
  const originalApplySearch = applySearch;
  const originalRenderModule = renderModule;
  const originalTableFor = tableFor;
  const originalRenderReports = renderReports;
  const originalRender = render;
  const originalPersist = persist;
  const originalApplyRestore = typeof applyRestore === "function" ? applyRestore : null;
  const originalDoImport = typeof doImport === "function" ? doImport : null;
  const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));

  function statusOptions(module) {
    const field = {leads: "stage", sales: "pay", payments: "status"}[module];
    return field ? [...new Set(rows(module).map(row => row[field]).filter(Boolean))].sort() : [];
  }
  function filterBar(module) {
    const value = filters[module] || {};
    const statuses = statusOptions(module);
    return '<div class="suite-filters" data-filter-module="' + module + '"><label>From<input type="date" data-suite-filter="from" value="' + escape(value.from) + '"></label><label>To<input type="date" data-suite-filter="to" value="' + escape(value.to) + '"></label>' + (statuses.length ? '<label>Status<select data-suite-filter="status"><option value="">All statuses</option>' + statuses.map(item => '<option ' + (value.status === item ? "selected" : "") + '>' + escape(item) + '</option>').join("") + '</select></label>' : '') + '<button type="button" data-suite-clear-filter>Clear</button></div>';
  }
  function duplicateNotice() {
    const groups = core.duplicateCustomers(rows("customers"));
    if (!groups.length) return "";
    return '<div class="suite-warning"><b>Possible duplicate customers: ' + groups.reduce((sum, group) => sum + group.length, 0) + '</b><span>' + groups.slice(0, 5).map(group => group.map(row => escape(row.name || row.phone)).join(" / ")).join(" · ") + '</span></div>';
  }
  applySearch = function (module, records) {
    const result = originalApplySearch(module, records);
    return FILTER_MODULES.has(module.id) ? core.filterRecords(module.id, result, filters[module.id]) : result;
  };
  renderModule = function (module) {
    let html = originalRenderModule(module);
    if (FILTER_MODULES.has(module.id)) html = html.replace("</div>", "</div>" + filterBar(module.id) + (module.id === "customers" ? duplicateNotice() : ""));
    return html;
  };
  tableFor = function (module, records) {
    if (!records.length) return '<div class="suite-empty"><div>' + (module.i || "📄") + '</div><h3>No ' + escape(module.n).toLowerCase() + ' yet</h3><p>Create the first record to get started.</p><button class="primary" data-act="add">+ Add ' + escape(module.n.replace(/\s*&.*$/, "").replace(/s$/, "")) + '</button></div>';
    return originalTableFor(module, records);
  };

  function searchResults() {
    const modules = MODS.filter(module => module.f && !module.custom).map(module => ({id: module.id, name: module.n}));
    const found = core.globalSearch(state.db, state.gq, modules);
    return '<div class="bar"><h2>Search results</h2><span class="sub">' + found.length + ' result(s) for “' + escape(state.gq) + '”</span></div><section class="suite-search-results">' + (found.length ? found.map(item => '<button type="button" data-suite-open="' + escape(item.module) + '" data-suite-id="' + escape(item.id) + '"><b>' + escape(item.label) + '</b><span>' + escape(item.moduleName) + ' · ' + escape(Object.values(item.record).filter(value => typeof value !== "object").slice(0, 5).join(" · ")) + '</span></button>').join("") : '<div class="suite-empty"><div>🔎</div><h3>No matching records</h3><p>Try a name, phone, invoice number, place or status.</p></div>') + '</section>';
  }
  render = function () {
    if (state.gq && !isLocked()) {
      renderSide();
      document.querySelectorAll("#mode button").forEach(button => button.classList.toggle("on", button.dataset.mode === state.settings.mode));
      document.querySelector("#view").innerHTML = searchResults();
      return afterRender();
    }
    return originalRender();
  };

  function reportCsv(value) {
    const lines = [["Business Suite custom report"], ["From", value.from || "All", "To", value.to || "All"], [], ["Metric", "Amount"], ["Sales", value.salesTotal], ["Money received", value.received], ["Expenses", value.expenses], ["Profit / loss", value.profit], ["GST collected", value.gstCollected], ["GST input credit", value.gstCredit], ["GST payable", value.gstPayable], [], ["Outstanding type", "Date", "Party", "Reference", "Balance"], ...value.outstanding.map(row => [row.kind, row.date, row.party, row.reference, row.balance]), [], ["Stock item", "Balance", "Minimum", "Supplier", "Status"], ...value.stock.map(row => [row.item, row.balance, row.minimum, row.supplier, row.low ? "Low" : "OK"])];
    return "\ufeff" + lines.map(line => line.map(value => '"' + String(value ?? "").replace(/"/g, '""') + '"').join(",")).join("\r\n");
  }
  function customReportPanel() {
    const value = core.report(state.db, state.reportFrom || "", state.reportTo || "");
    const outstanding = value.outstanding.reduce((sum, row) => sum + row.balance, 0);
    const low = value.stock.filter(row => row.low);
    return '<section class="suite-report"><div class="bar"><h3>Custom date report</h3><span class="grow"></span><label>From<input id="suiteReportFrom" type="date" value="' + escape(value.from) + '"></label><label>To<input id="suiteReportTo" type="date" value="' + escape(value.to) + '"></label></div><div class="cards"><div class="card"><div class="k">Profit / loss</div><div class="v">' + money(value.profit) + '</div></div><div class="card warn"><div class="k">Outstanding</div><div class="v">' + money(outstanding) + '</div></div><div class="card"><div class="k">GST payable</div><div class="v">' + money(value.gstPayable) + '</div></div><div class="card"><div class="k">Low stock</div><div class="v">' + low.length + '</div></div></div><div class="inl"><button data-suite-report="csv">Export Excel (CSV)</button><button data-suite-report="pdf">Print / Save PDF</button></div><div class="two"><div><h3>Outstanding payments</h3>' + (value.outstanding.length ? '<div class="tablewrap"><table><thead><tr><th>Date</th><th>Party</th><th>Reference</th><th class="num">Balance</th></tr></thead><tbody>' + value.outstanding.map(row => '<tr><td>' + escape(row.date) + '</td><td>' + escape(row.party) + '</td><td>' + escape(row.reference) + '</td><td class="num">' + money(row.balance) + '</td></tr>').join("") + '</tbody></table></div>' : '<p class="empty">No outstanding payments in this range.</p>') + '</div><div><h3>Stock report</h3>' + (value.stock.length ? '<div class="tablewrap"><table><thead><tr><th>Item</th><th class="num">Balance</th><th>Status</th></tr></thead><tbody>' + value.stock.map(row => '<tr><td>' + escape(row.item) + '</td><td class="num">' + escape(row.balance) + '</td><td>' + (row.low ? '<span class="dueTag">LOW</span>' : 'OK') + '</td></tr>').join("") + '</tbody></table></div>' : '<p class="empty">No stock records.</p>') + '</div></div></section>';
  }
  renderReports = function () { return originalRenderReports() + customReportPanel(); };

  function showSaved() {
    let badge = document.querySelector("#suiteSaveStatus");
    if (!badge) { badge = document.createElement("div"); badge.id = "suiteSaveStatus"; badge.setAttribute("role", "status"); document.body.append(badge); }
    badge.textContent = "✓ Saved"; badge.classList.add("show"); clearTimeout(saveTimer); saveTimer = setTimeout(() => badge.classList.remove("show"), 1800);
  }
  persist = async function () { const result = await originalPersist(); showSaved(); return result; };

  async function audit(action, detail) {
    const saved = await chrome.storage.local.get("restoreAuditV1");
    const history = Array.isArray(saved.restoreAuditV1) ? saved.restoreAuditV1 : [];
    history.unshift({id: crypto.randomUUID(), at: Date.now(), action, detail});
    await chrome.storage.local.set({restoreAuditV1: history.slice(0, 100)});
  }
  if (originalApplyRestore) applyRestore = async function () {
    const mode = state.rst?.mode || "merge", files = state.rst?.files?.length || 0;
    const result = await originalApplyRestore();
    await audit(mode === "replace" ? "Planner backup restored" : "Planner backups merged", files + " backup file(s) processed.");
    return result;
  };
  if (originalDoImport) doImport = function () {
    const files = state.imp?.files || 0, result = originalDoImport();
    audit("Work Tracker data merged", files + " import file(s) processed.").catch(() => {});
    return result;
  };

  function offerUndo(module, record, index) {
    deleted = {module, record: structuredClone(record), index, expires: Date.now() + 8000};
    let bar = document.querySelector("#suiteUndo");
    if (!bar) { bar = document.createElement("div"); bar.id = "suiteUndo"; document.body.append(bar); }
    bar.innerHTML = '<span>Record deleted.</span><button type="button" data-suite-undo>Undo</button><small>8 seconds</small>';
    bar.hidden = false; clearTimeout(undoTimer); undoTimer = setTimeout(() => { deleted = null; bar.hidden = true; }, 8000);
  }
  document.addEventListener("click", event => {
    const del = event.target.closest('[data-act="del"]');
    if (del) {
      const row = del.closest("[data-id]");
      const module = row?.dataset.mod || state.mod, list = rows(module), index = list.findIndex(item => item.id === row?.dataset.id);
      if (index >= 0) { const record = structuredClone(list[index]); setTimeout(() => { if (!rows(module).some(item => item.id === record.id)) offerUndo(module, record, index); }, 0); }
    }
    const open = event.target.closest("[data-suite-open]");
    if (open) { state.gq = ""; document.querySelector("#gsearch").value = ""; state.mod = open.dataset.suiteOpen; originalRender(); openForm(modById[state.mod], open.dataset.suiteId); }
    if (event.target.closest("[data-suite-clear-filter]")) { filters[state.mod] = {}; originalRender(); }
    if (event.target.closest("[data-suite-undo]") && deleted && deleted.expires > Date.now()) {
      const item = deleted; deleted = null; clearTimeout(undoTimer); rows(item.module).splice(Math.min(item.index, rows(item.module).length), 0, item.record); document.querySelector("#suiteUndo").hidden = true; persist(); toast("Delete undone ✓");
    }
    const reportButton = event.target.closest("[data-suite-report]");
    if (reportButton) {
      const value = core.report(state.db, state.reportFrom || "", state.reportTo || "");
      if (reportButton.dataset.suiteReport === "csv") download("Business-Suite-report-" + (value.from || "all") + "-to-" + (value.to || "all") + ".csv", reportCsv(value), "text/csv");
      else {
        const popup = window.open("", "_blank");
        popup.document.write('<!doctype html><title>Business Suite report</title><style>body{font:14px Arial;padding:30px}table{border-collapse:collapse;width:100%;margin:16px 0}td,th{border:1px solid #bbb;padding:7px;text-align:left}.num{text-align:right}</style><h1>Business Suite report</h1><p>' + escape(value.from || "All dates") + ' to ' + escape(value.to || "All dates") + '</p><h2>Profit / loss: ' + escape(money(value.profit)) + '</h2><p>Sales: ' + escape(money(value.salesTotal)) + ' · Received: ' + escape(money(value.received)) + ' · Expenses: ' + escape(money(value.expenses)) + ' · GST payable: ' + escape(money(value.gstPayable)) + '</p><h2>Outstanding payments</h2><table><tr><th>Date</th><th>Party</th><th>Reference</th><th>Balance</th></tr>' + value.outstanding.map(row => '<tr><td>' + escape(row.date) + '</td><td>' + escape(row.party) + '</td><td>' + escape(row.reference) + '</td><td>' + escape(money(row.balance)) + '</td></tr>').join("") + '</table><h2>Stock</h2><table><tr><th>Item</th><th>Balance</th><th>Status</th></tr>' + value.stock.map(row => '<tr><td>' + escape(row.item) + '</td><td>' + escape(row.balance) + '</td><td>' + (row.low ? 'LOW' : 'OK') + '</td></tr>').join("") + '</table>');
        popup.document.close(); popup.print();
      }
    }
  }, true);
  document.addEventListener("change", event => {
    const input = event.target.closest("[data-suite-filter]");
    if (input) { (filters[state.mod] ||= {})[input.dataset.suiteFilter] = input.value; originalRender(); }
    if (event.target.id === "suiteReportFrom") { state.reportFrom = event.target.value; originalRender(); }
    if (event.target.id === "suiteReportTo") { state.reportTo = event.target.value; originalRender(); }
  });

  const check = () => {
    const result = core.integrity(state.db);
    chrome.storage.local.set({plannerIntegrityV1: {checkedAt: Date.now(), ok: result.ok, problems: result.problems}}).catch(() => {});
    if (!result.ok) toast("Database integrity check found a problem. Open Drive → Backup for details.", true);
  };
  window.addEventListener("DOMContentLoaded", () => setTimeout(check, 500));
  setInterval(check, 6 * 60 * 60 * 1000);
})();
