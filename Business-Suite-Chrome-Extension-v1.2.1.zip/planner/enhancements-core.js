(function (root) {
  "use strict";
  const DATE_FIELDS = {
    customers: ["created"], leads: ["follow", "created"], sales: ["date", "created"],
    payments: ["due", "remind", "created"]
  };
  const STATUS_FIELDS = {leads: "stage", sales: "pay", payments: "status"};
  const text = value => String(value ?? "").trim().toLowerCase();
  const number = value => Number(value) || 0;
  const dateOf = (module, record) => (DATE_FIELDS[module] || []).map(key => record[key]).find(Boolean) || "";

  function filterRecords(module, records, filters = {}) {
    return records.filter(record => {
      const date = dateOf(module, record);
      if (filters.from && (!date || date < filters.from)) return false;
      if (filters.to && (!date || date > filters.to)) return false;
      const statusKey = STATUS_FIELDS[module];
      if (filters.status && (!statusKey || record[statusKey] !== filters.status)) return false;
      return true;
    });
  }

  function duplicateCustomers(customers) {
    const groups = new Map();
    for (const customer of customers) {
      const phone = text(customer.phone).replace(/\D/g, "").replace(/^0+/, "");
      const name = text(customer.name).replace(/\s+/g, " ");
      const key = phone.length >= 7 ? "phone:" + phone : name ? "name:" + name : "";
      if (!key) continue;
      const group = groups.get(key) || [];
      group.push(customer); groups.set(key, group);
    }
    return [...groups.values()].filter(group => group.length > 1);
  }

  function globalSearch(db, query, modules) {
    const needle = text(query);
    if (!needle) return [];
    const results = [];
    for (const module of modules) for (const record of db[module.id] || []) {
      if (!Object.values(record).some(value => text(typeof value === "object" ? JSON.stringify(value) : value).includes(needle))) continue;
      results.push({module: module.id, moduleName: module.name, id: record.id, label: record.name || record.no || record.party || record.item || record.title || "Record", record});
      if (results.length >= 100) return results;
    }
    return results;
  }

  function report(db, from = "", to = "") {
    const inRange = value => value && (!from || value >= from) && (!to || value <= to);
    const sales = (db.sales || []).filter(row => inRange(row.date));
    const ledger = (db.ledger || []).filter(row => inRange(row.date));
    const purchases = (db.purchases || []).filter(row => inRange(row.date));
    const payments = (db.payments || []).filter(row => inRange(row.due || row.created));
    const saleSign = row => row.kind === "Return" ? -1 : 1;
    const salesTotal = sales.reduce((sum, row) => sum + saleSign(row) * number(row.total), 0);
    const expenses = ledger.filter(row => row.type === "Expense").reduce((sum, row) => sum + number(row.amount), 0);
    const received = sales.reduce((sum, row) => sum + saleSign(row) * number(row.rcv), 0) +
      ledger.filter(row => row.type === "Income").reduce((sum, row) => sum + number(row.amount), 0);
    const outstandingSales = sales.filter(row => row.kind !== "Return").map(row => ({kind: "Invoice", date: row.due || row.date, party: row.customer || row.no, reference: row.no || "", balance: Math.max(0, number(row.total) - number(row.rcv))})).filter(row => row.balance);
    const outstandingPayments = payments.map(row => ({kind: row.dir || "Payment", date: row.due || row.created, party: row.party || "", reference: row.inst || "", balance: Math.max(0, number(row.amount) - number(row.rcv))})).filter(row => row.balance);
    const gstCollected = sales.reduce((sum, row) => sum + saleSign(row) * number(row.gstAmt), 0);
    const gstCredit = purchases.reduce((sum, row) => sum + number(row.gstAmt), 0);
    const stock = (db.stock || []).map(row => ({item: row.item || "", balance: number(row.bal), minimum: number(row.min), supplier: row.supplier || "", low: number(row.bal) <= number(row.min)}));
    return {from, to, salesTotal, expenses, received, profit: received - expenses, gstCollected, gstCredit, gstPayable: gstCollected - gstCredit, outstanding: [...outstandingSales, ...outstandingPayments], stock};
  }

  function integrity(db) {
    const problems = [];
    if (!db || typeof db !== "object" || Array.isArray(db)) return {ok: false, problems: ["Planner database is not an object."]};
    for (const [name, records] of Object.entries(db)) {
      if (!Array.isArray(records)) { problems.push(name + " is not a record list."); continue; }
      const ids = new Set();
      for (const record of records) {
        if (!record || typeof record !== "object" || Array.isArray(record)) { problems.push(name + " contains an invalid record."); continue; }
        if (typeof record.id !== "string" || !record.id) problems.push(name + " contains a record without an ID.");
        else if (ids.has(record.id)) problems.push(name + " contains duplicate record ID " + record.id + ".");
        else ids.add(record.id);
      }
    }
    return {ok: !problems.length, problems: problems.slice(0, 50)};
  }

  root.PlannerEnhanceCore = {filterRecords, duplicateCustomers, globalSearch, report, integrity, dateOf};
})(globalThis);
