const MAX_ACTION_AGE = 7 * 24 * 60 * 60 * 1000;

export function validatePinReset(action, lease, fingerprint, now = Date.now()) {
  if (!action || typeof action !== "object" || action.type !== "reset-pin") return false;
  if (typeof action.id !== "string" || !/^[A-Za-z0-9._:-]{8,128}$/.test(action.id)) return false;
  if (!Number.isSafeInteger(action.issuedAt) || !Number.isSafeInteger(action.expiresAt)) return false;
  if (action.issuedAt > now + 5 * 60 * 1000 || action.expiresAt <= now || action.expiresAt - action.issuedAt > MAX_ACTION_AGE) return false;
  return typeof fingerprint === "string" && fingerprint.length > 0 && lease?.fp === fingerprint;
}

export function clearPinSettings(settings) {
  const next = structuredClone(settings && typeof settings === "object" ? settings : {});
  if (!next.sec || typeof next.sec !== "object" || Array.isArray(next.sec)) return {settings: next, changed: false};
  const hadPin = ["hash", "salt", "pinHash", "pinSalt"].some(key => Object.hasOwn(next.sec, key));
  for (const key of ["hash", "salt", "pinHash", "pinSalt"]) delete next.sec[key];
  return {settings: next, changed: hadPin};
}

export function rememberProcessed(current, id) {
  const ids = Array.isArray(current?.ids) ? current.ids.filter(value => typeof value === "string" && value !== id) : [];
  ids.unshift(id);
  return {ids: ids.slice(0, 50)};
}
