// Multi-value registers with vector clocks. Each device writes its own Drive file.
// Concurrent edits stay visible as conflicts instead of overwriting one another.
export const FORMAT = "business-suite-drive-sync";
export const SCHEMA = 1;
const ROOTS = new Set(["k:db", "k:profile", "k:tracker", "k:notes"]);
const BAD_KEYS = new Set(["__proto__", "prototype", "constructor"]);
const copy = value => structuredClone(value);
const key = path => JSON.stringify(path);
const equal = (a, b) => stable(a) === stable(b);

function stable(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(stable).join(",") + "]";
  return "{" + Object.keys(value).sort().map(k => JSON.stringify(k) + ":" + stable(value[k])).join(",") + "}";
}

export function combineClocks(...clocks) {
  const result = {};
  for (const clock of clocks) for (const [id, n] of Object.entries(clock || {})) {
    if (BAD_KEYS.has(id) || !Number.isSafeInteger(n) || n < 0) throw Error("Invalid sync clock.");
    result[id] = Math.max(result[id] || 0, n);
  }
  if (Object.keys(result).length > 256) throw Error("Too many devices in this sync history.");
  return result;
}

export function dominates(a, b) {
  return Object.entries(b).every(([id, n]) => (a[id] || 0) >= n);
}

function checkedPath(encoded) {
  const path = JSON.parse(encoded);
  if (!Array.isArray(path) || path.length > 32 || (path.length && !ROOTS.has(path[0]))) throw Error("Invalid sync record.");
  for (const part of path) {
    if (typeof part !== "string" || part.length > 1024 || !/^[ki]:/.test(part) || BAD_KEYS.has(part.slice(2))) throw Error("Invalid sync field.");
  }
  return path;
}

function flatten(value, previous, path = [], result = {}) {
  if (path.length > 32) throw Error("Business data is too deeply nested.");
  const id = key(path);
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const old = previous[id]?.find(v => v.node.type === "object")?.node;
    result[id] = old?.order !== undefined ? {type: "object", order: old.order} : {type: "object"};
    for (const [name, child] of Object.entries(value)) {
      if (BAD_KEYS.has(name)) throw Error("Invalid business data field.");
      flatten(child, previous, path.concat("k:" + name), result);
    }
  } else if (Array.isArray(value) && value.every(v => v && typeof v === "object" && typeof v.id === "string" && v.id)) {
    if (new Set(value.map(v => v.id)).size !== value.length) throw Error("Duplicate record IDs.");
    result[id] = {type: "array"};
    value.forEach((child, index) => {
      const childPath = path.concat("i:" + child.id);
      flatten(child, previous, childPath, result);
      const childKey = key(childPath);
      if (result[childKey].order === undefined) result[childKey].order = index;
    });
  } else {
    if (typeof value === "number" && !Number.isFinite(value)) throw Error("Invalid business number.");
    if (value === undefined || typeof value === "function") throw Error("Invalid business value.");
    result[id] = {type: "value", value: copy(value)};
  }
  return result;
}

export function projectBusiness(storage) {
  const tracker = storage.trackerSuiteV4;
  return {
    db: copy(storage.db || {}),
    profile: copy(storage.settings?.biz || {}),
    tracker: {app: "work-tracker-suite", version: 4, businesses: copy(tracker?.businesses || [])},
    notes: copy(storage.bsNotes || [])
  };
}

export function storagePatch(data, storage) {
  if (!data || !data.db || typeof data.db !== "object" || Array.isArray(data.db) ||
      !data.profile || typeof data.profile !== "object" || Array.isArray(data.profile) ||
      !Array.isArray(data.notes) || !Array.isArray(data.tracker?.businesses)) throw Error("Invalid business snapshot.");
  const patch = {
    db: copy(data.db),
    settings: {...(storage.settings || {}), biz: copy(data.profile)},
    bsNotes: copy(data.notes)
  };
  if (data.tracker.businesses.length) {
    const old = storage.trackerSuiteV4 || {};
    const ids = new Set(data.tracker.businesses.map(v => v.id));
    patch.trackerSuiteV4 = {
      ...copy(data.tracker), activeId: ids.has(old.activeId) ? old.activeId : data.tracker.businesses[0].id,
      revision: (Number.isSafeInteger(old.revision) ? old.revision : 0) + 1
    };
  }
  return patch;
}

export function emptyState() {
  return {format: FORMAT, schema: SCHEMA, clock: {}, nodes: {}, devices: {}};
}

export function validateState(state) {
  if (state?.format !== FORMAT || state.schema !== SCHEMA || !state.clock || typeof state.clock !== "object" || Array.isArray(state.clock) || !state.nodes || typeof state.nodes !== "object" || Array.isArray(state.nodes)) throw Error("Unsupported Drive sync file.");
  combineClocks(state.clock);
  if (state.devices !== undefined) {
    if (!state.devices || typeof state.devices !== "object" || Array.isArray(state.devices) || Object.keys(state.devices).length > 256) throw Error("Invalid sync device history.");
    for (const [id, device] of Object.entries(state.devices)) {
      if (BAD_KEYS.has(id) || !device || typeof device !== "object" || typeof device.name !== "string" || device.name.length > 120 || !Number.isSafeInteger(device.lastSeen) || device.lastSeen < 0 || typeof device.revoked !== "boolean") throw Error("Invalid sync device history.");
    }
  }
  if (Object.keys(state.nodes).length > 200000) throw Error("Drive snapshot has too many fields.");
  for (const [encoded, versions] of Object.entries(state.nodes)) {
    checkedPath(encoded);
    if (!Array.isArray(versions) || !versions.length || versions.length > 32) throw Error("Invalid sync versions.");
    for (const version of versions) {
      combineClocks(version.clock);
      if (!dominates(state.clock, version.clock) || !["object", "array", "value", "deleted"].includes(version.node?.type)) throw Error("Invalid sync version.");
      if (version.node.type === "value") flatten(version.node.value, {});
      if (version.node.order !== undefined && (!Number.isSafeInteger(version.node.order) || version.node.order < 0)) throw Error("Invalid record order.");
    }
  }
  return state;
}

function versionsJoined(versions) {
  let result = [];
  for (const incoming of versions) {
    const equalClock = result.find(v => dominates(v.clock, incoming.clock) && dominates(incoming.clock, v.clock));
    if (equalClock) {
      if (!equal(equalClock.node, incoming.node)) throw Error("A device reused a sync revision. Reconnect Drive before continuing.");
      continue;
    }
    if (result.some(v => dominates(v.clock, incoming.clock))) continue;
    result = result.filter(v => !dominates(incoming.clock, v.clock));
    result.push(copy(incoming));
  }
  // Concurrent writes of the same value need no user decision.
  const groups = [];
  for (const v of result) {
    const same = groups.find(g => equal(g.node, v.node));
    if (same) same.clock = combineClocks(same.clock, v.clock);
    else groups.push(v);
  }
  return groups.sort((a, b) => stable(a).localeCompare(stable(b)));
}

export function joinStates(...states) {
  const result = emptyState();
  for (const state of states) {
    validateState(state);
    result.clock = combineClocks(result.clock, state.clock);
    for (const [id, device] of Object.entries(state.devices || {})) {
      const current = result.devices[id];
      result.devices[id] = {name: !current || device.lastSeen >= current.lastSeen ? device.name : current.name, lastSeen: Math.max(current?.lastSeen || 0, device.lastSeen), revoked: !!(current?.revoked || device.revoked)};
    }
    for (const [path, versions] of Object.entries(state.nodes)) result.nodes[path] = versionsJoined((result.nodes[path] || []).concat(versions));
  }
  return result;
}

export function touchDevice(state, id, name, now = Date.now()) {
  validateState(state);
  if (!id || BAD_KEYS.has(id) || typeof name !== "string" || !Number.isSafeInteger(now) || now < 0) throw Error("Invalid sync device.");
  const result = copy(state); result.devices ||= {};
  const current = result.devices[id];
  if (!current?.revoked) result.devices[id] = {name: name.slice(0, 120), lastSeen: now, revoked: false};
  return result;
}

export function revokeDevice(state, id) {
  validateState(state);
  if (!state.devices?.[id]) throw Error("Device is no longer in the sync history.");
  const result = copy(state); result.devices[id].revoked = true; return result;
}

export function recordChanges(state, before, after, writer, visibleClock = state.clock) {
  validateState(state);
  if (!writer || BAD_KEYS.has(writer)) throw Error("Invalid sync device.");
  const left = flatten(before, state.nodes);
  const right = flatten(after, state.nodes);
  // Reusing an imported record ID must not restore fields hidden by its old
  // deletion. Keep concurrent unseen edits as conflicts through their clocks.
  const recreated = Object.keys(right).filter(p =>
    ["object", "array"].includes(right[p].type) &&
    !["object", "array"].includes(left[p]?.type) && state.nodes[p]
  ).map(checkedPath);
  for (const [encoded, versions] of Object.entries(state.nodes)) {
    if (left[encoded] || right[encoded]) continue;
    const parts = checkedPath(encoded);
    if (!recreated.some(parent => parent.length < parts.length && parent.every((part, i) => parts[i] === part))) continue;
    const live = versions.find(v => v.node.type !== "deleted");
    if (live) left[encoded] = copy(live.node);
  }
  const removedParents = Object.keys(left).filter(p => !right[p] && ["object", "array"].includes(left[p].type)).map(p => checkedPath(p));
  const changed = Object.keys({...left, ...right}).filter(path => {
    const parts = checkedPath(path);
    if (removedParents.some(parent => parent.length < parts.length && parent.every((part, i) => parts[i] === part))) return false;
    return !equal(left[path], right[path]) || (right[path] && !state.nodes[path]);
  });
  if (!changed.length) return copy(state);
  const clock = combineClocks(visibleClock);
  clock[writer] = (state.clock[writer] || 0) + 1;
  const result = copy(state);
  result.clock = combineClocks(state.clock, clock);
  for (const path of changed) {
    const node = right[path] || {type: "deleted", previousType: left[path]?.type};
    result.nodes[path] = versionsJoined((result.nodes[path] || []).concat({clock, node}));
  }
  return result;
}

export function materialize(state) {
  validateState(state);
  const conflicts = [];
  const children = new Map();
  const descendants = new Map();
  const paths = Object.keys(state.nodes).map(encoded => ({encoded, parts: checkedPath(encoded)}));
  for (const {encoded, parts} of [...paths].sort((a, b) => b.parts.length - a.parts.length)) {
    if (!parts.length) continue;
    const live = state.nodes[encoded].filter(v => v.node.type !== "deleted").map(v => v.clock);
    const aggregate = combineClocks(descendants.get(encoded), ...live);
    const parent = key(parts.slice(0, -1));
    descendants.set(parent, combineClocks(descendants.get(parent), aggregate));
  }
  for (const path of Object.keys(state.nodes)) {
    const parts = checkedPath(path);
    if (!parts.length) continue;
    const parent = key(parts.slice(0, -1));
    if (!children.has(parent)) children.set(parent, []);
    children.get(parent).push(parts.at(-1));
  }
  function read(path) {
    const encoded = key(path), versions = state.nodes[encoded] || [];
    if (!versions.length) return undefined;
    if (versions.length > 1) conflicts.push({path: encoded, type: "value", choices: versions.map(v => copy(v.node))});
    const selected = versions[0], node = selected.node;
    if (node.type === "deleted") {
      const edit = !dominates(selected.clock, descendants.get(encoded) || {});
      if (edit) conflicts.push({path: encoded, type: "delete", choices: [{type: "deleted"}, {type: node.previousType || "object"}]});
      return undefined;
    }
    if (node.type === "value") return copy(node.value);
    const parts = [...new Set(children.get(encoded) || [])].sort();
    if (node.type === "array") {
      const rows = [];
      for (const part of parts) {
        if (!part.startsWith("i:")) throw Error("Invalid array record.");
        const value = read(path.concat(part));
        if (value !== undefined) rows.push({value, order: state.nodes[key(path.concat(part))]?.[0]?.node.order ?? 0, id: part});
      }
      return rows.sort((a, b) => a.order - b.order || a.id.localeCompare(b.id)).map(v => v.value);
    }
    const object = {};
    for (const part of parts) {
      if (!part.startsWith("k:")) throw Error("Invalid object field.");
      const value = read(path.concat(part));
      if (value !== undefined) object[part.slice(2)] = value;
    }
    return object;
  }
  const data = read([]);
  return {data, conflicts};
}

export function resolveConflict(state, conflict, choice, writer) {
  const current = materialize(state).conflicts.find(v => v.path === conflict.path && v.type === conflict.type);
  if (!current || !equal(current.choices, conflict.choices)) throw Error("This conflict changed. Sync again before choosing a version.");
  const result = copy(state);
  const clock = combineClocks(state.clock);
  clock[writer] = (clock[writer] || 0) + 1;
  result.clock = clock;
  const node = conflict.choices[choice];
  if (!node) throw Error("Choose a conflict version.");
  result.nodes[conflict.path] = [{clock, node: copy(node)}];
  return result;
}

export function stateEqual(a, b) { return equal(a, b); }
