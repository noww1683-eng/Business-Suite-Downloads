(() => {
  "use strict";

  if (location.protocol !== "chrome-extension:") return;

  document.documentElement.style.visibility = "hidden";

  const hex = buffer => [...new Uint8Array(buffer)]
    .map(byte => byte.toString(16).padStart(2, "0"))
    .join("");

  const showFailure = () => {
    const render = () => {
      document.documentElement.style.visibility = "visible";
      document.body.innerHTML = `
        <main style="max-width:680px;margin:10vh auto;padding:32px;font:16px/1.5 system-ui;color:#172033">
          <h1>Business Suite could not start</h1>
          <p>A required application file is missing or has been changed.</p>
          <p>Remove this copy and reinstall Business Suite from the official Chrome Web Store listing.</p>
        </main>`;
    };
    if (document.body) render();
    else document.addEventListener("DOMContentLoaded", render, {once: true});
  };

  const verify = async () => {
    const manifestResponse = await fetch(chrome.runtime.getURL("package-integrity.json"), {cache: "no-store"});
    if (!manifestResponse.ok) throw new Error("Integrity manifest missing");
    const manifest = await manifestResponse.json();
    if (manifest.version !== 1 || !manifest.files || typeof manifest.files !== "object") {
      throw new Error("Integrity manifest invalid");
    }

    for (const [path, expectedHash] of Object.entries(manifest.files)) {
      if (!/^[A-Za-z0-9_./ -]+$/.test(path) || path.includes("..")) {
        throw new Error("Integrity path invalid");
      }
      const response = await fetch(chrome.runtime.getURL(path), {cache: "no-store"});
      if (!response.ok) throw new Error("Required package file missing");
      const actualHash = hex(await crypto.subtle.digest("SHA-256", await response.arrayBuffer()));
      if (actualHash !== expectedHash) throw new Error("Package file changed");
    }
    document.documentElement.style.visibility = "visible";
    return true;
  };

  globalThis.__businessSuiteIntegrityReady = verify().catch(error => {
    console.error("Business Suite package integrity check failed", error);
    showFailure();
    throw error;
  });
})();
