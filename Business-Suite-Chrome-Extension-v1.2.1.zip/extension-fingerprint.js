const BS_FP = (() => {
  "use strict";
  let cached;
  const resolve = async () => {
    // Preserve the existing Chrome installation identity across extension updates.
    const key = "business-suite-desktop-install-id";
    let id = localStorage.getItem(key);
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem(key, id);
    }
    const digest = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(`business-suite-desktop-v1|${id}`)
    );
    return Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, "0")).join("");
  };
  return () => cached || (cached = resolve().catch(error => {
    cached = null;
    throw error;
  }));
})();
