const API = "https://www.googleapis.com/drive/v3/files";
const UPLOAD_API = "https://www.googleapis.com/upload/drive/v3/files";
const USER_INFO = "https://www.googleapis.com/oauth2/v3/userinfo";
const CONFIG_KEY = "googleDriveWebV1";
const FOLDER_NAME = "Business Suite";
const LEGACY_FOLDER_NAME = "Business Suite Sync";
const MARKER_FILE = "Business-Suite-folder.json";
const FILE_PREFIX = "Business-Suite-sync-";
const FILE_SUFFIX = ".json";
const MAX_FILE = 40 * 1024 * 1024;
const MAX_TOTAL = 128 * 1024 * 1024;
const SCOPES = "openid email https://www.googleapis.com/auth/drive.file";

let accessToken = "";
let expiresAt = 0;
let tokenPromise = null;
let gisPromise = null;

const clientId = () => String(globalThis.BUSINESS_SUITE_GOOGLE_WEB_CLIENT_ID || "").trim();
const configured = () => /^\d+-[a-z0-9_-]+\.apps\.googleusercontent\.com$/i.test(clientId());
const id = bytes => {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  let binary = "";
  for (const value of data) binary += String.fromCharCode(value);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const validDriveId = value => typeof value === "string" && /^[A-Za-z0-9_-]{10,200}$/.test(value);
const validId = (value, size) => typeof value === "string" && value.length === size && /^[A-Za-z0-9_-]+$/.test(value);
const escapeQuery = value => String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'");

async function loadConfig() {
  const value = (await chrome.storage.local.get(CONFIG_KEY))[CONFIG_KEY];
  if (!value) return null;
  if (!validDriveId(value.driveFolderId) || !validId(value.folderId, 43) ||
      !validId(value.writerId, 43) || String(value.email || "").length > 320) {
    throw Error("The saved Google Drive setting is invalid.");
  }
  return value;
}

const saveConfig = value => chrome.storage.local.set({[CONFIG_KEY]: value});
const status = value => ({
  configured: configured(), connected: !!value,
  accountId: value?.folderId || "", email: value?.email || "", writerId: value?.writerId || ""
});

function loadGis() {
  if (globalThis.google?.accounts?.oauth2) return Promise.resolve();
  if (gisPromise) return gisPromise;
  gisPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(Error("Google sign-in could not be loaded. Check the internet connection."));
    document.head.append(script);
  });
  return gisPromise;
}

function extensionAccess(interactive) {
  const redirectUri = chrome.identity.getRedirectURL("google");
  const state = id(18);
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", clientId());
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "token");
  url.searchParams.set("scope", SCOPES);
  url.searchParams.set("include_granted_scopes", "true");
  url.searchParams.set("state", state);
  url.searchParams.set("prompt", interactive ? "select_account consent" : "none");
  return chrome.identity.launchWebAuthFlow({url: url.href, interactive}).then(result => {
    if (!result) throw Error("Google sign-in was closed.");
    const returned = new URL(result);
    const params = new URLSearchParams(returned.hash.slice(1));
    if (params.get("state") !== state) throw Error("Google sign-in returned an invalid response.");
    if (params.get("error")) throw Error(params.get("error_description") || params.get("error"));
    const token = params.get("access_token");
    if (!token) throw Error("Google sign-in did not return an access token.");
    accessToken = token;
    expiresAt = Date.now() + Math.max(60, Number(params.get("expires_in")) || 3600) * 1000;
    return token;
  }).catch(error => {
    const text = String(error?.message || error);
    if (/redirect_uri_mismatch/i.test(text)) {
      throw Error(`Add this authorised redirect URI to the Google OAuth Web client: ${redirectUri}`);
    }
    throw error;
  });
}

export async function googleAccess(interactive = false) {
  if (!configured()) throw Error("Google Drive OAuth Client ID has not been added to this Web App.");
  if (accessToken && Date.now() < expiresAt - 120000) return accessToken;
  if (tokenPromise) return tokenPromise;
  if (location.protocol === "chrome-extension:" && chrome.identity?.launchWebAuthFlow) {
    tokenPromise = extensionAccess(interactive).finally(() => { tokenPromise = null; });
    return tokenPromise;
  }
  tokenPromise = (async () => {
    await loadGis();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(Error("Google sign-in timed out. Try again.")), 120000);
      const client = google.accounts.oauth2.initTokenClient({
        client_id: clientId(), scope: SCOPES,
        callback: response => {
          clearTimeout(timeout);
          if (response?.error || !response?.access_token) {
            reject(Error(response?.error_description || response?.error || "Google sign-in was cancelled."));
            return;
          }
          accessToken = response.access_token;
          expiresAt = Date.now() + Math.max(60, Number(response.expires_in) || 3600) * 1000;
          resolve(accessToken);
        },
        error_callback: () => { clearTimeout(timeout); reject(Error("Google sign-in was closed.")); }
      });
      client.requestAccessToken({prompt: interactive ? "select_account consent" : ""});
    });
  })().finally(() => { tokenPromise = null; });
  return tokenPromise;
}

async function request(url, options = {}, json = true) {
  const token = await googleAccess(false);
  const response = await fetch(url, {...options, headers: {...options.headers, Authorization: `Bearer ${token}`}});
  if (response.status === 401) {
    accessToken = ""; expiresAt = 0;
    throw Error("Google Drive sign-in expired. Open Drive and connect again.");
  }
  if (!response.ok) throw Error(`Google Drive request failed (${response.status}).`);
  return json ? response.json() : response;
}

async function listFiles(query) {
  const files = [];
  let pageToken = "";
  do {
    const url = new URL(API);
    url.searchParams.set("q", query);
    url.searchParams.set("spaces", "drive");
    url.searchParams.set("pageSize", "100");
    url.searchParams.set("fields", "nextPageToken,files(id,name,size,modifiedTime)");
    if (pageToken) url.searchParams.set("pageToken", pageToken);
    const page = await request(url);
    files.push(...(page.files || []));
    if (files.length > 256) throw Error("The Drive folder contains too many Business Suite sync files.");
    pageToken = page.nextPageToken || "";
  } while (pageToken);
  return files;
}

async function createMetadata(metadata) {
  return request(API, {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(metadata)});
}

async function renameMetadata(fileId, name) {
  if (!validDriveId(fileId)) throw Error("Google Drive returned an invalid folder reference.");
  return request(`${API}/${encodeURIComponent(fileId)}?fields=id,name,size,modifiedTime`, {
    method: "PATCH", headers: {"Content-Type": "application/json"}, body: JSON.stringify({name})
  });
}

async function downloadFile(fileId) {
  if (!validDriveId(fileId)) throw Error("Google Drive returned an invalid file reference.");
  const response = await request(`${API}/${encodeURIComponent(fileId)}?alt=media`, {}, false);
  const blob = await response.blob();
  if (blob.size > MAX_FILE) throw Error("A Google Drive sync file exceeds the 40 MB limit.");
  return blob.text();
}

async function uploadFile(folderId, name, mime, data) {
  if (!validDriveId(folderId) || name.length > 240 || new Blob([data]).size > MAX_FILE) {
    throw Error("Business data exceeds the Google Drive sync limit.");
  }
  const boundary = `business-suite-${id(16)}`;
  const metadata = JSON.stringify({name, parents: [folderId]});
  const body = new Blob([
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n`,
    `--${boundary}\r\nContent-Type: ${mime}\r\n\r\n`, data, `\r\n--${boundary}--\r\n`
  ], {type: `multipart/related; boundary=${boundary}`});
  const url = `${UPLOAD_API}?uploadType=multipart&fields=id,name,size,modifiedTime`;
  return request(url, {method: "POST", headers: {"Content-Type": `multipart/related; boundary=${boundary}`}, body});
}

const syncName = name => {
  const match = /^Business-Suite-sync-([A-Za-z0-9_-]{43})-([A-Za-z0-9_-]{22})\.json$/.exec(name || "");
  return !!match;
};
const validSnapshot = value => value && value.schema === 1 && (
  value.format === "business-suite-drive-sync" && value.clock && value.nodes ||
  value.format === "business-suite-drive-encrypted" && value.kdf && value.cipher && typeof value.data === "string"
);

export const webDrive = {
  config: () => ({configured: configured(), clientId: clientId(), scope: SCOPES}),
  async drive_status() { return status(await loadConfig()); },
  async drive_connect(_, interactive = false) {
    await googleAccess(interactive);
    const folders = await listFiles(`name = '${FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`);
    let folder = folders[0];
    if (!folder) {
      const legacy = await listFiles(`name = '${LEGACY_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`);
      folder = legacy[0]
        ? await renameMetadata(legacy[0].id, FOLDER_NAME)
        : await createMetadata({name: FOLDER_NAME, mimeType: "application/vnd.google-apps.folder"});
    }
    if (!validDriveId(folder.id)) throw Error("Google Drive returned an invalid folder reference.");
    const markers = await listFiles(`'${escapeQuery(folder.id)}' in parents and name = '${MARKER_FILE}' and trashed = false`);
    let folderId;
    if (markers[0]) {
      const marker = JSON.parse(await downloadFile(markers[0].id));
      if (marker.format !== "business-suite-folder" || !validId(marker.id, 43)) throw Error("The Business Suite Drive folder marker is invalid.");
      folderId = marker.id;
    } else {
      folderId = id(32);
      await uploadFile(folder.id, MARKER_FILE, "application/json", JSON.stringify({format: "business-suite-folder", id: folderId}));
    }
    const user = await request(USER_INFO);
    const previous = await loadConfig();
    const value = {
      driveFolderId: folder.id, folderId,
      writerId: previous?.folderId === folderId ? previous.writerId : id(32),
      email: String(user.email || "Google Drive")
    };
    await saveConfig(value);
    return status(value);
  },
  async drive_rotate_writer() {
    const value = await loadConfig();
    if (!value) throw Error("Connect Google Drive first.");
    value.writerId = id(32); await saveConfig(value); return status(value);
  },
  async drive_pull() {
    const value = await loadConfig();
    if (!value) throw Error("Connect Google Drive first.");
    const files = await listFiles(`'${escapeQuery(value.driveFolderId)}' in parents and trashed = false`);
    const result = []; let total = 0;
    for (const file of files.filter(file => syncName(file.name))) {
      if (Number(file.size || 0) > MAX_FILE) throw Error("A Google Drive sync file exceeds the 40 MB limit.");
      const text = await downloadFile(file.id); total += new Blob([text]).size;
      if (total > MAX_TOTAL) throw Error("The Google Drive sync history exceeds the 128 MB limit.");
      let snapshot;
      try { snapshot = JSON.parse(text); } catch { throw Error("A Google Drive sync file is incomplete or damaged."); }
      if (!validSnapshot(snapshot) || snapshot.folderId !== value.folderId) throw Error("A Google Drive file does not belong to this Business Suite sync folder.");
      result.push(snapshot);
    }
    return result;
  },
  async drive_put({body}) {
    const value = await loadConfig();
    if (!value) throw Error("Connect Google Drive first.");
    if (new Blob([body]).size > MAX_FILE) throw Error("Business data exceeds the 40 MB Drive sync limit.");
    let snapshot;
    try { snapshot = JSON.parse(body); } catch { throw Error("Invalid business sync data."); }
    if (!validSnapshot(snapshot)) throw Error("Invalid business sync snapshot.");
    snapshot.folderId = value.folderId;
    const name = `${FILE_PREFIX}${value.writerId}-${id(16)}${FILE_SUFFIX}`;
    await uploadFile(value.driveFolderId, name, "application/json", JSON.stringify(snapshot));
    const files = await listFiles(`'${escapeQuery(value.driveFolderId)}' in parents and trashed = false`);
    const own = files.filter(file => file.name?.startsWith(`${FILE_PREFIX}${value.writerId}-`) && syncName(file.name))
      .sort((a, b) => String(b.modifiedTime || "").localeCompare(String(a.modifiedTime || "")));
    for (const file of own.slice(3)) await request(`${API}/${encodeURIComponent(file.id)}`, {method: "DELETE"}, false).catch(() => {});
  },
  async drive_disconnect() {
    await chrome.storage.local.remove(CONFIG_KEY);
    if (accessToken && globalThis.google?.accounts?.oauth2) google.accounts.oauth2.revoke(accessToken, () => {});
    accessToken = ""; expiresAt = 0;
  }
};
