(function () {
  "use strict";

  const key = "business-suite-page:" + location.pathname;
  let restoring = false;
  let restored = false;
  let detail = null;
  let observer;

  function read() {
    try { return JSON.parse(sessionStorage.getItem(key) || "null") || {}; }
    catch { return {}; }
  }

  function write(value) {
    try { sessionStorage.setItem(key, JSON.stringify(value)); } catch {}
  }

  function activePage() {
    const planner = document.querySelector("#side button.on[data-mod]");
    if (planner) return {kind: "planner", page: planner.dataset.mod};
    const tracker = document.querySelector('#nav button.active[data-action="tab"][data-type]');
    if (tracker) return {kind: "tracker", page: tracker.dataset.type};
    return null;
  }

  function capture() {
    const page = activePage();
    const previous = read();
    write({
      ...previous,
      ...(page || {}),
      detail: detail || previous.detail || null,
      scrollX: window.scrollX,
      scrollY: window.scrollY,
      viewScrollTop: document.querySelector("#view")?.scrollTop || 0
    });
  }

  function restoreScroll(saved) {
    const apply = () => {
      window.scrollTo(saved.scrollX || 0, saved.scrollY || 0);
      const view = document.querySelector("#view");
      if (view) view.scrollTop = saved.viewScrollTop || 0;
    };
    requestAnimationFrame(() => requestAnimationFrame(apply));
    setTimeout(apply, 250);
  }

  function restore() {
    if (restored || restoring) return;
    const saved = read();
    if (!saved.page) {
      if (activePage()) {
        restored = true;
        observer?.disconnect();
      }
      return;
    }
    const pageSelector = saved.kind === "planner"
      ? '#side button[data-mod="' + CSS.escape(saved.page) + '"]'
      : '#nav button[data-action="tab"][data-type="' + CSS.escape(saved.page) + '"]';
    const target = document.querySelector(pageSelector);
    if (!target) return;

    // Restoration is a one-time startup action. Stop observing before the
    // synthetic click mutates the page, otherwise every later user click is
    // mistaken for another reload and gets reverted to the saved page.
    restored = true;
    observer?.disconnect();
    restoring = true;
    const selected = target.matches(".on, .active");
    if (!selected) target.click();

    if (saved.kind === "tracker" && saved.detail) {
      requestAnimationFrame(() => {
        const selector = '[data-action="detail"][data-type="' + CSS.escape(saved.detail.type) + '"][data-id="' + CSS.escape(saved.detail.id) + '"]';
        document.querySelector(selector)?.click();
        restoreScroll(saved);
        restoring = false;
      });
    } else {
      restoreScroll(saved);
      restoring = false;
    }
  }

  document.addEventListener("click", event => {
    if (!(event.target instanceof Element)) return;
    const tab = event.target.closest?.('#nav button[data-action="tab"][data-type]');
    if (tab) detail = null;
    const record = event.target.closest?.('[data-action="detail"][data-type][data-id]');
    if (record) detail = {type: record.dataset.type, id: record.dataset.id};
    setTimeout(capture);
  }, true);
  addEventListener("scroll", capture, {passive: true});
  addEventListener("beforeunload", capture);

  observer = new MutationObserver(() => restore());
  observer.observe(document.documentElement, {childList: true, subtree: true});
  addEventListener("DOMContentLoaded", restore);
  window.__bsRefreshState = {capture};
})();
