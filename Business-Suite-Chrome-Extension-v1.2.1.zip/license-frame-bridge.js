(() => {
  "use strict";
  if (window !== top || typeof LIC === "undefined") return;

  const start = LIC.start.bind(LIC);
  LIC.start = callback => start(ok => {
    window.__businessSuiteLicenseCheck = module => Boolean(ok && LIC.has(module));
    if (typeof callback === "function") callback(ok);
  });
})();
