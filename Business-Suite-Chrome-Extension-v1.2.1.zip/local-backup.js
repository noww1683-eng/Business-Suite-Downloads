import {restoreLocalBackup} from "./drive-sync-store.js";
import {appendAudit, normalizeAudit, AUDIT_KEY} from "./audit-history.js";

const DATA_KEYS = ["db", "settings", "trackerSuiteV4", "bsNotes"];
const SETTINGS_KEY = "localBackupSettingsV1";
const FORMAT = "business-suite-local-backup";
const DAY = 86400000;
const DEFAULTS = {schedule: "daily", retention: 14};

const isObject = value => value && typeof value === "object" && !Array.isArray(value);

function normalizeSettings(value) {
  return {
    schedule: ["off", "daily", "weekly"].includes(value?.schedule) ? value.schedule : DEFAULTS.schedule,
    retention: [7, 14, 30].includes(Number(value?.retention)) ? Number(value.retention) : DEFAULTS.retention
  };
}

function envelope(data) {
  return {format: FORMAT, schema: 1, createdAt: new Date().toISOString(), data};
}

function validateBackup(value) {
  if (!isObject(value) || value.format !== FORMAT || value.schema !== 1 ||
      typeof value.createdAt !== "string" || !isObject(value.data)) {
    throw Error("This is not a supported Business Suite backup.");
  }
  const stack = [{value: value.data, depth: 0}];
  let nodes = 0;
  while (stack.length) {
    const item = stack.pop();
    if (++nodes > 500000 || item.depth > 40) throw Error("The backup structure is too large or deeply nested.");
    if (!item.value || typeof item.value !== "object") continue;
    for (const [key, child] of Object.entries(item.value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) throw Error("The backup contains an unsafe property name.");
      if (child && typeof child === "object") stack.push({value: child, depth: item.depth + 1});
    }
  }
  return value;
}

function countArrays(value) {
  if (!isObject(value)) return 0;
  return Object.values(value).reduce((total, item) => total + (Array.isArray(item) ? item.length : 0), 0);
}

function summary(backup) {
  const data = backup.data;
  const planner = countArrays(data.db);
  const businesses = Array.isArray(data.trackerSuiteV4?.businesses) ? data.trackerSuiteV4.businesses : [];
  const tracker = businesses.reduce((total, business) => total + countArrays(business?.data), 0);
  const notes = Array.isArray(data.bsNotes) ? data.bsNotes.length : 0;
  const businessName = data.settings?.biz?.name || "Business Suite";
  return {planner, tracker, notes, businesses: businesses.length, businessName};
}

function prepareRestoreData(backup, currentSettings) {
  const data = structuredClone(backup.data);
  if (isObject(data.settings) || currentSettings?.sec) {
    data.settings = {...(data.settings || {}), ...(currentSettings?.sec ? {sec: currentSettings.sec} : {})};
  }
  return data;
}

function formatDate(milliseconds) {
  return new Date(milliseconds).toLocaleString([], {dateStyle: "medium", timeStyle: "short"});
}

function toBase64(text) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = () => reject(reader.error || Error("Could not prepare the backup export."));
    reader.readAsDataURL(new Blob([text], {type: "application/json"}));
  });
}

export async function setupLocalBackup({dialog, store, invoke, beforeRestore, onRestore}) {
  const section = document.createElement("section");
  section.className = "backup-panel";
  section.innerHTML = '<h2>Automatic local backup</h2><p>Keep complete Planner, Tracker and Notes backups on this computer. Restore always shows a preview first. The device license and current PIN stay on this computer.</p><div class="backup-grid"><label>Schedule<select id="backupSchedule"><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="off">Off</option></select></label><label>Keep copies<select id="backupRetention"><option value="7">7 backups</option><option value="14">14 backups</option><option value="30">30 backups</option></select></label></div><div id="backupStatus" class="drive-status" role="status" aria-live="polite">Loading backup status…</div><div class="drive-actions"><button id="backupNow" type="button">Back up now</button><button id="backupExportCurrent" type="button">Export current data</button></div><label>Saved backups<select id="backupList"></select></label><div class="drive-actions"><button id="backupPreview" type="button">Preview selected</button><button id="backupExportSelected" type="button">Export selected</button></div><div id="backupPreviewPanel" class="backup-preview" hidden><strong id="backupPreviewTitle"></strong><div id="backupPreviewCounts"></div><p>This replaces current Planner, Tracker and Notes data. A safety backup is created first.</p><button id="backupRestore" type="button">Restore this backup</button></div><h3>Restore / merge audit history</h3><div id="backupAudit" class="backup-audit"></div>';
  dialog.querySelector("#driveConflicts").after(section);
  const $ = id => section.querySelector("#" + id);
  let settings = normalizeSettings((await store.get(SETTINGS_KEY))[SETTINGS_KEY]);
  let entries = [], selectedBackup = null, working = false;
  $("backupSchedule").value = settings.schedule;
  $("backupRetention").value = String(settings.retention);

  function setWorking(value) {
    working = value;
    for (const button of section.querySelectorAll("button")) button.disabled = value;
    $("backupSchedule").disabled = value;
    $("backupRetention").disabled = value;
  }

  function status(text, error = false) {
    $("backupStatus").textContent = text;
    $("backupStatus").dataset.error = String(error);
  }

  async function readCurrent() {
    const values = await store.get(DATA_KEYS);
    if (isObject(values.settings)) {
      values.settings = structuredClone(values.settings);
      delete values.settings.sec;
    }
    return JSON.stringify(envelope(Object.fromEntries(DATA_KEYS.filter(key => key in values).map(key => [key, values[key]]))));
  }

  async function refreshList(note = "") {
    entries = await invoke("local_backup_list");
    $("backupList").replaceChildren();
    if (!entries.length) {
      const option = document.createElement("option"); option.textContent = "No backups yet"; option.value = "";
      $("backupList").append(option);
    } else {
      for (const entry of entries) {
        const option = document.createElement("option"); option.value = entry.name;
        option.textContent = formatDate(entry.createdAt) + " · " + Math.max(1, Math.ceil(entry.size / 1024)) + " KB";
        $("backupList").append(option);
      }
    }
    const schedule = settings.schedule === "off" ? "Automatic backup is off." :
      (settings.schedule === "daily" ? "Daily" : "Weekly") + " automatic backup · keeping " + settings.retention + " copies.";
    const latest = entries[0] ? "\nLast backup: " + formatDate(entries[0].createdAt) + "." : "\nNo local backup has been created yet.";
    status((note ? note + "\n" : "") + schedule + latest);
    const audit = normalizeAudit((await store.get(AUDIT_KEY))[AUDIT_KEY]);
    $("backupAudit").replaceChildren(...(audit.length ? audit.slice(0, 20).map(item => {
      const row = document.createElement("div");
      const strong = document.createElement("strong"); strong.textContent = item.action;
      const small = document.createElement("small"); small.textContent = new Date(item.at).toLocaleString() + (item.detail ? " · " + item.detail : "");
      row.append(strong, small); return row;
    }) : [Object.assign(document.createElement("p"), {textContent: "No restore or merge operations recorded yet."})]));
  }

  async function createBackup(note = "Backup completed.") {
    const body = await readCurrent();
    await invoke("local_backup_write", {body, retention: settings.retention});
    await refreshList(note);
  }

  async function withWork(action) {
    if (working) return;
    setWorking(true);
    try { await action(); }
    catch (error) { status(String(error), true); }
    finally { setWorking(false); }
  }

  async function exportBody(body, createdAt) {
    const stamp = new Date(createdAt).toISOString().replace(/[:.]/g, "-");
    const payload = {
      b64: await toBase64(body),
      name: "Business-Suite-backup-" + stamp + ".json",
      mime: "application/json"
    };
    if (window.BSAndroid?.call) await window.BSAndroid.call("save", payload);
    else await invoke("save_export", payload);
  }

  async function loadSelected() {
    const name = $("backupList").value;
    if (!name) throw Error("Choose a saved backup first.");
    const body = await invoke("local_backup_read", {name});
    const backup = validateBackup(JSON.parse(body));
    return {body, backup};
  }

  $("backupSchedule").addEventListener("change", async () => {
    settings = normalizeSettings({...settings, schedule: $("backupSchedule").value});
    await store.set({[SETTINGS_KEY]: settings});
    await refreshList("Backup schedule saved.");
  });
  $("backupRetention").addEventListener("change", async () => {
    settings = normalizeSettings({...settings, retention: Number($("backupRetention").value)});
    await store.set({[SETTINGS_KEY]: settings});
    await refreshList("Backup retention saved.");
  });
  $("backupNow").addEventListener("click", () => withWork(() => createBackup()));
  $("backupExportCurrent").addEventListener("click", () => withWork(async () => {
    const body = await readCurrent();
    await exportBody(body, Date.now());
    status("Current data export completed.");
  }));
  $("backupPreview").addEventListener("click", () => withWork(async () => {
    const {backup} = await loadSelected();
    selectedBackup = backup;
    const counts = summary(backup);
    $("backupPreviewTitle").textContent = counts.businessName + " · " + new Date(backup.createdAt).toLocaleString();
    $("backupPreviewCounts").textContent = "Planner records: " + counts.planner + " · Tracker records: " + counts.tracker + " in " + counts.businesses + " business(es) · Notes: " + counts.notes;
    $("backupPreviewPanel").hidden = false;
    status("Preview ready. Review the counts before restoring.");
  }));
  $("backupExportSelected").addEventListener("click", () => withWork(async () => {
    const {body, backup} = await loadSelected();
    await exportBody(body, backup.createdAt);
    status("Selected backup export completed.");
  }));
  $("backupList").addEventListener("change", () => {
    selectedBackup = null; $("backupPreviewPanel").hidden = true;
  });
  $("backupRestore").addEventListener("click", () => withWork(async () => {
    if (!selectedBackup) throw Error("Preview the selected backup before restoring it.");
    if (!confirm("Restore this backup? Current Planner, Tracker and Notes data will be replaced after a safety backup is created.")) return;
    if (beforeRestore && !await beforeRestore()) return;
    const backupToRestore = selectedBackup;
    await createBackup("Safety backup created.");
    const current = await store.get("settings");
    await restoreLocalBackup(prepareRestoreData(backupToRestore, current.settings));
    await appendAudit(store, {action: "Local backup restored", detail: "Restored backup from " + new Date(backupToRestore.createdAt).toLocaleString() + "."});
    selectedBackup = null;
    $("backupPreviewPanel").hidden = true;
    await onRestore?.();
    await refreshList("Backup restored successfully.");
  }));

  await refreshList();
  const interval = settings.schedule === "daily" ? DAY : settings.schedule === "weekly" ? 7 * DAY : 0;
  if (interval && (!entries[0] || Date.now() - entries[0].createdAt >= interval)) {
    await withWork(() => createBackup("Scheduled backup completed."));
  }
  setInterval(async () => {
    if (settings.schedule === "off" || working) return;
    const current = await invoke("local_backup_list").catch(() => []);
    const due = settings.schedule === "daily" ? DAY : 7 * DAY;
    if (!current[0] || Date.now() - current[0].createdAt >= due) await withWork(() => createBackup("Scheduled backup completed."));
  }, 60 * 60 * 1000);
}

export const backupInternals = {normalizeSettings, envelope, validateBackup, summary, prepareRestoreData};
