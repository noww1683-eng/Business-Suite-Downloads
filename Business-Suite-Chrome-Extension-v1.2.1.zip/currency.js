(() => {
  "use strict";
  const currencies = [
    ["INR", "Indian Rupee"],
    ["AED", "UAE Dirham"],
    ["SAR", "Saudi Riyal"],
    ["USD", "US Dollar"],
    ["EUR", "Euro"],
    ["GBP", "British Pound"],
    ["QAR", "Qatari Riyal"],
    ["OMR", "Omani Rial"],
    ["KWD", "Kuwaiti Dinar"],
    ["BHD", "Bahraini Dinar"],
    ["CAD", "Canadian Dollar"],
    ["AUD", "Australian Dollar"],
    ["SGD", "Singapore Dollar"],
    ["MYR", "Malaysian Ringgit"],
    ["JPY", "Japanese Yen"],
    ["CNY", "Chinese Yuan"],
    ["PKR", "Pakistani Rupee"],
    ["BDT", "Bangladeshi Taka"],
    ["LKR", "Sri Lankan Rupee"],
    ["NPR", "Nepalese Rupee"],
    ["ZAR", "South African Rand"],
    ["NGN", "Nigerian Naira"],
    ["KES", "Kenyan Shilling"]
  ];
  const codes = Object.freeze(currencies.map(([code]) => code));
  const denominationValues = {
    INR: [500, 200, 100, 50, 20, 10, 5, 2, 1],
    AED: [1000, 500, 200, 100, 50, 20, 10, 5, 1, 0.5, 0.25],
    SAR: [500, 200, 100, 50, 10, 5, 1, 0.5, 0.25],
    USD: [100, 50, 20, 10, 5, 2, 1, 0.5, 0.25, 0.1, 0.05, 0.01],
    EUR: [500, 200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01],
    GBP: [50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01],
    QAR: [500, 200, 100, 50, 10, 5, 1, 0.5, 0.25],
    OMR: [50, 20, 10, 5, 1, 0.5, 0.1, 0.05, 0.025, 0.01, 0.005],
    KWD: [20, 10, 5, 1, 0.5, 0.25, 0.1, 0.05, 0.02, 0.01, 0.005],
    BHD: [20, 10, 5, 1, 0.5, 0.1, 0.05, 0.025, 0.01, 0.005],
    CAD: [100, 50, 20, 10, 5, 2, 1, 0.25, 0.1, 0.05],
    AUD: [100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05],
    SGD: [1000, 100, 50, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05],
    MYR: [100, 50, 20, 10, 5, 1, 0.5, 0.2, 0.1, 0.05],
    JPY: [10000, 5000, 2000, 1000, 500, 100, 50, 10, 5, 1],
    CNY: [100, 50, 20, 10, 5, 1, 0.5, 0.1],
    PKR: [5000, 1000, 500, 100, 50, 20, 10],
    BDT: [1000, 500, 200, 100, 50, 20, 10, 5, 2, 1],
    LKR: [5000, 1000, 500, 100, 50, 20, 10, 5, 2, 1],
    NPR: [1000, 500, 100, 50, 20, 10, 5, 2, 1],
    ZAR: [200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1],
    NGN: [1000, 500, 200, 100, 50, 20, 10, 5],
    KES: [1000, 500, 200, 100, 50, 20, 10, 5, 1]
  };
  const denominationsByCode = Object.freeze(Object.fromEntries(
    Object.entries(denominationValues).map(([code, values]) => [code, Object.freeze(values)])
  ));
  const normalize = code => codes.includes(String(code || "").toUpperCase())
    ? String(code).toUpperCase()
    : "INR";
  const format = (value, code = "INR") => new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: normalize(code),
    currencyDisplay: "code",
    maximumFractionDigits: ["OMR", "KWD", "BHD"].includes(normalize(code)) ? 3 :
      normalize(code) === "JPY" ? 0 : 2
  }).format(Number(value) || 0);
  const denominations = (code = "INR") => denominationsByCode[normalize(code)];
  globalThis.BusinessCurrency = Object.freeze({
    codes,
    options: Object.freeze(currencies.map(([code, name]) => Object.freeze([code, `${code} — ${name}`]))),
    normalize,
    format,
    denominations
  });
})();
