import {appendAudit} from "./audit-history.js";
import {clearPinSettings, rememberProcessed, validatePinReset} from "./admin-security-reset-core.js";

const STATE_KEY = "adminSecurityResetV1";
const bytes = value => Uint8Array.from(atob(value), character => character.charCodeAt(0));
let processing = Promise.resolve();

async function verifiedLease(answer) {
  if (!answer?.lease || !answer?.sig || !LICENSE_CONFIG?.PUBLIC_KEY) return null;
  try {
    const key = await crypto.subtle.importKey("raw", bytes(LICENSE_CONFIG.PUBLIC_KEY), {name: "Ed25519"}, false, ["verify"]);
    const valid = await crypto.subtle.verify({name: "Ed25519"}, key, bytes(answer.sig), new TextEncoder().encode(answer.lease));
    return valid ? JSON.parse(answer.lease) : null;
  } catch {
    return null;
  }
}

function notify(text) {
  const toast = document.querySelector("#hubToast");
  if (!toast) return;
  toast.textContent = text;
  toast.hidden = false;
  setTimeout(() => { toast.hidden = true; }, 8000);
}

async function processLease(answer) {
  const lease = await verifiedLease(answer);
  if (!lease || !Array.isArray(lease.securityActions)) return;
  const fingerprint = await BS_FP().catch(() => "");
  const saved = await chrome.storage.local.get([STATE_KEY, "settings"]);
  let processed = saved[STATE_KEY] || {ids: []};
  let settings = saved.settings;
  let reset = false;

  for (const action of lease.securityActions.slice(0, 20)) {
    if (processed.ids?.includes(action?.id) || !validatePinReset(action, lease, fingerprint)) continue;
    const result = clearPinSettings(settings);
    settings = result.settings;
    processed = rememberProcessed(processed, action.id);
    reset ||= result.changed;
    await appendAudit(chrome.storage.local, {
      action: "Admin-authorized PIN reset",
      detail: result.changed ? "Device PIN removed; business data was unchanged." : "Reset authorization received; no PIN was set."
    });
  }

  await chrome.storage.local.set({...(!reset ? {} : {settings}), [STATE_KEY]: processed});
  if (reset) {
    notify("PIN removed by an authorized admin reset. Business data was not changed.");
    const planner = document.querySelector("#f-planner");
    if (planner?.src) setTimeout(() => planner.contentWindow?.location.reload(), 250);
  }
}

function schedule(answer) {
  processing = processing.then(() => processLease(answer)).catch(console.error);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.licLease?.newValue) schedule(changes.licLease.newValue);
});
chrome.storage.local.get("licLease").then(value => schedule(value.licLease)).catch(console.error);
