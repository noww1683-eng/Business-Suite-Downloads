import {stateEqual} from "./drive-sync-core.js";

const KEYS = ["db", "settings", "trackerSuiteV4", "bsNotes"];

// Check and write in one IndexedDB transaction. A save queued just before a
// Drive update must be noticed rather than overwritten by a stale read.
export async function commitCloud(expected, patch, metadata, isCurrent = () => true) {
  const database = await new Promise((resolve, reject) => {
    const request = indexedDB.open("business-suite-android", 1);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  return new Promise((resolve, reject) => {
    const tx = database.transaction("local", "readwrite");
    const records = tx.objectStore("local");
    const current = {}, events = {};
    let remaining = KEYS.length, stale = false;
    tx.onabort = () => {
      database.close();
      if (stale) resolve(false);
      else reject(tx.error || Error("Could not apply Drive updates."));
    };
    tx.onerror = () => {};
    tx.oncomplete = () => {
      database.close();
      window.top.__bsStorageEvent.emit(events, "local");
      resolve(true);
    };
    for (const key of KEYS) {
      const request = records.get(key);
      request.onsuccess = () => {
        if (request.result !== undefined) current[key] = request.result;
        if (--remaining) return;
        if (!isCurrent() || !stateEqual(current, expected)) { stale = true; tx.abort(); return; }
        const values = {...patch, driveSyncMetaV1: metadata};
        for (const [name, value] of Object.entries(values)) {
          events[name] = {oldValue: current[name], newValue: value};
          records.put(value, name);
        }
      };
    }
  });
}

// Restore all business areas in one transaction so the app never observes a
// half-restored Planner/Tracker/Notes database.
export async function restoreLocalBackup(data) {
  const values = Object.fromEntries(KEYS.filter(key => key in data).map(key => [key, data[key]]));
  const database = await new Promise((resolve, reject) => {
    const request = indexedDB.open("business-suite-android", 1);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  return new Promise((resolve, reject) => {
    const tx = database.transaction("local", "readwrite");
    const records = tx.objectStore("local");
    const events = {};
    tx.onerror = () => {};
    tx.onabort = () => { database.close(); reject(tx.error || Error("Could not restore the backup.")); };
    tx.oncomplete = () => {
      database.close();
      window.top.__bsStorageEvent.emit(events, "local");
      resolve(true);
    };
    for (const key of KEYS) {
      const request = records.get(key);
      request.onsuccess = () => {
        const oldValue = request.result;
        if (key in values) {
          events[key] = {oldValue, newValue: values[key]};
          records.put(values[key], key);
        } else if (oldValue !== undefined) {
          events[key] = {oldValue};
          records.delete(key);
        }
      };
    }
  });
}
