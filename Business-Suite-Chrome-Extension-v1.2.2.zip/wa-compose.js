(() => {
  "use strict";

  const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
  const findComposer = () => document.querySelector('footer [contenteditable="true"]');
  const findAttachmentPreview = () => [...document.querySelectorAll(
    '[data-icon="send"], button[aria-label="Send"], [role="button"][aria-label="Send"]'
  )].find(element => !element.closest("footer"));

  function notice(message, success = true, duration = 12000) {
    let element = document.getElementById("business-suite-notice");
    if (!element) {
      element = document.createElement("div");
      element.id = "business-suite-notice";
      element.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:99999;padding:9px 18px;border-radius:12px;font:600 14px system-ui;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,.3);max-width:90vw;text-align:center";
      document.body.appendChild(element);
    }
    element.style.background = success ? "#128c7e" : "#b45309";
    element.textContent = message;
    clearTimeout(element.removeTimer);
    element.removeTimer = setTimeout(() => element.remove(), duration);
  }

  async function until(find, milliseconds) {
    const deadline = Date.now() + milliseconds;
    while (Date.now() < deadline) {
      const value = find();
      if (value) return value;
      await wait(250);
    }
    return null;
  }

  async function insertText(editor, text) {
    if (!text || editor.innerText.trim()) return;
    editor.focus();
    const lines = text.split("\n");
    for (let index = 0; index < lines.length; index += 1) {
      if (lines[index]) document.execCommand("insertText", false, lines[index]);
      if (index < lines.length - 1) document.execCommand("insertLineBreak");
    }
  }

  function fileFromBase64(saved) {
    const binary = atob(saved.b64);
    const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
    return new File([bytes], saved.name || "Business-Suite-invoice.pdf", {
      type: saved.mime || "application/pdf"
    });
  }

  async function attachFile(editor, saved) {
    const file = fileFromBase64(saved);
    try {
      const transfer = new DataTransfer();
      transfer.items.add(file);
      editor.focus();
      editor.dispatchEvent(new ClipboardEvent("paste", {
        clipboardData: transfer, bubbles: true, cancelable: true
      }));
    } catch {}
    if (await until(findAttachmentPreview, 6000)) return true;

    try {
      const attach = document.querySelector(
        'footer [data-icon="plus"], footer [data-icon="attach-menu-plus"], footer [data-icon="clip"], footer button[aria-label*="Attach" i], footer [role="button"][aria-label*="Attach" i]'
      );
      if (attach) {
        (attach.closest("button") || attach.closest('[role="button"]') || attach).click();
        await wait(900);
      }
      const inputs = [...document.querySelectorAll('input[type="file"]')];
      const input = inputs.find(item => !/image|video/i.test(item.accept || "")) || inputs[0];
      if (input) {
        const transfer = new DataTransfer();
        transfer.items.add(file);
        input.files = transfer.files;
        input.dispatchEvent(new Event("change", {bubbles: true}));
      }
    } catch {}
    return !!(await until(findAttachmentPreview, 8000));
  }

  (async () => {
    const {waPending, waFile} = await chrome.storage.local.get(["waPending", "waFile"]);
    const lifetime = waPending?.ttl || 90000;
    if (!waPending || Date.now() - waPending.t > lifetime) return;
    await chrome.storage.local.remove("waPending");

    const deadline = Date.now() + lifetime;
    let loginNoticeShown = false;
    while (Date.now() < deadline) {
      const pageText = document.body?.innerText || "";
      if (/phone number shared via url is invalid|isn.t on whatsapp/i.test(pageText)) {
        notice("Business Suite: this number is not on WhatsApp — check the phone number", false);
        return;
      }
      if (!loginNoticeShown && /Link with phone number|Use WhatsApp on your computer|Scan the QR code/i.test(pageText)) {
        loginNoticeShown = true;
        notice("Business Suite: log in to WhatsApp Web, then reopen this message from Business Suite", false, 20000);
      }

      const editor = findComposer();
      if (editor) {
        if (waPending.file && waFile && Date.now() - waFile.t < 900000) {
          notice("Business Suite: preparing the invoice PDF…", true, 15000);
          const attached = await attachFile(editor, waFile);
          await insertText(editor, waPending.text || "");
          if (!attached) {
            await chrome.runtime.sendMessage({type: "wa-save-file"});
            notice("Invoice downloaded. Attach it in WhatsApp, review the message, then press Send.", false, 20000);
            return;
          }
          notice("Invoice and message are ready. Review them, then press Send in WhatsApp.");
          return;
        }
        await insertText(editor, waPending.text || "");
        notice("Business Suite prepared the message. Review it, then press Send in WhatsApp.");
        return;
      }
      await wait(500);
    }
    notice("Open the chat again from Business Suite after WhatsApp Web is ready.", false);
  })().catch(error => {
    console.error("Business Suite WhatsApp preparation failed", error);
    notice("Business Suite could not prepare this message. Please try again.", false);
  });
})();
