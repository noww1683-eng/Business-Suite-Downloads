"use strict";

async function readXLSX(r) {
  const e = await r.arrayBuffer();
  const n = new DataView(e);
  let s = -1;
  for (let r = e.byteLength - 22; r >= Math.max(0, e.byteLength - 65557); r--) {
    if (n.getUint32(r, true) === 101010256) {
      s = r;
      break;
    }
  }
  if (s < 0) {
    throw Error("Invalid XLSX ZIP.");
  }
  const o = n.getUint16(s + 10, true);
  let a = n.getUint32(s + 16, true);
  let i = 0;
  if (o > 500) {
    throw Error("Workbook has too many files.");
  }
  for (let r = 0; r < o; r++) {
    if (n.getUint32(a, true) !== 33639248) {
      throw Error("Invalid ZIP directory.");
    }
    i += n.getUint32(a + 24, true);
    if (i > 26214400) {
      throw Error("Workbook expands beyond 25 MB.");
    }
    a += 46 + n.getUint16(a + 28, true) + n.getUint16(a + 30, true) + n.getUint16(a + 32, true);
  }
  const x = await JSZip.loadAsync(e);
  const l = async r => {
    const n = x.file(r);
    if (!n) {
      throw Error("Missing workbook part: " + r);
    }
    const s = await n.async("string");
    if (/<!DOCTYPE/i.test(s)) {
      throw Error("Unsupported XML document type.");
    }
    const o = new DOMParser().parseFromString(s, "application/xml");
    if (o.getElementsByTagName("parsererror").length) {
      throw Error("Invalid workbook XML.");
    }
    return o;
  };
  const _ = (r, e) => [...r.getElementsByTagNameNS("*", e)];
  const w = x.file("xl/sharedStrings.xml") ? _(await l("xl/sharedStrings.xml"), "si").map(r => _(r, "t").map(r => r.textContent).join("")) : [];
  const f = await l("xl/workbook.xml");
  const c = _(f, "sheet")[0];
  if (!c) {
    throw Error("No worksheet.");
  }
  const g = _(f, "workbookPr")[0];
  if (g && ["1", "true"].includes(g.getAttribute("date1904"))) {
    throw Error("This workbook uses 1904 dates. Save as CSV with ISO dates first.");
  }
  const b = c.getAttribute("r:id") || c.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
  const h = await l("xl/_rels/workbook.xml.rels");
  const d = _(h, "Relationship").find(r => r.getAttribute("Id") === b);
  if (!d || d.getAttribute("TargetMode") === "External") {
    throw Error("Unsupported worksheet reference.");
  }
  let u = d.getAttribute("Target");
  u = u.startsWith("/") ? u.slice(1) : "xl/" + u;
  if (u.includes("..")) {
    throw Error("Unsupported worksheet path.");
  }
  const m = await l(u);
  return {
    rows: _(m, "row").map(r => {
      const n = [];
      for (const t of _(r, "c")) {
        if (_(t, "f").length) {
          throw Error("Formula cells are not imported. Paste values in Excel first.");
        }
        const r = t.getAttribute("r") || "";
        const s = r.match(/^[A-Z]+/)?.[0];
        if (!s) {
          continue;
        }
        let o = 0;
        for (const r of s) {
          o = o * 26 + r.charCodeAt(0) - 64;
        }
        if (o > 50) {
          throw Error("Use a simple table with at most 50 columns.");
        }
        const a = t.getAttribute("t");
        const i = _(t, "v")[0]?.textContent || "";
        n[o - 1] = a === "s" ? w[Number(i)] || "" : a === "inlineStr" ? _(t, "t").map(r => r.textContent).join("") : i;
      }
      return n;
    }).filter(r => r.some(r => String(r || "").trim())),
    sheet: c.getAttribute("name")
  };
}
