(() => {
  const e = "bp-check";
  const t = () => {
    chrome.alarms.create(e, {
      periodInMinutes: 30
    });
    o();
  };
  chrome.runtime.onInstalled.addListener(t);
  chrome.runtime.onStartup.addListener(t);
  chrome.alarms.onAlarm.addListener(n => {
    if (n.name === e) {
      o();
    }
  });
  chrome.storage.onChanged.addListener((e, t) => {
    if (t === "local" && (e.db || e.settings)) {
      o(true);
    }
  });
  const s = {
    en: {
      cash: e => "🔴 Cash due: " + e + " payment" + (e > 1 ? "s" : ""),
      tasks: n => n + " task" + (n > 1 ? "s" : "") + " due",
      fups: n => n + " follow-up" + (n > 1 ? "s" : "") + " due",
      appts: e => e + " appointment" + (e > 1 ? "s" : "") + " today"
    },
    hi: {
      cash: n => "🔴 कैश देय: " + n + " भुगतान",
      tasks: n => n + " कार्य बाकी",
      fups: n => n + " फ़ॉलो-अप बाकी",
      appts: e => "आज " + e + " अपॉइंटमेंट"
    },
    ar: {
      cash: e => "🔴 مدفوعات مستحقة: " + e,
      tasks: e => e + " مهام مستحقة",
      fups: e => e + " متابعات مستحقة",
      appts: n => n + " مواعيد اليوم"
    }
  };
  const r = n => Number(n) || 0;
  const a = e => String(e).padStart(2, "0");
  async function o(e) {
    const {
      db: o = {},
      settings: g = {},
      notified: i = {}
    } = await chrome.storage.local.get(["db", "settings", "notified"]);
    const c = new Date();
    const u = c.getFullYear() + "-" + a(c.getMonth() + 1) + "-" + a(c.getDate());
    const l = n => o[n] || [];
    const p = n => n.kind !== "Return" && (n.pay ?? n.status) !== "Paid";
    const f = n => Math.max(0, r("total" in n ? n.total : n.amount) - r(n.rcv));
    const _ = [...l("sales").filter(n => p(n) && n.due && n.due <= u).map(n => ({
      n: n.customer || n.no,
      a: f(n)
    })), ...l("payments").filter(n => p(n) && n.due && n.due <= u).map(n => ({
      n: n.party,
      a: f(n)
    }))];
    const b = l("tasks").filter(n => n.status !== "Done" && n.due && n.due <= u).length;
    const h = l("leads").filter(n => !["Won", "Lost"].includes(n.stage) && n.follow && n.follow <= u).length;
    const m = l("appts").filter(n => n.status === "Booked" && n.date === u).length;
    const d = _.length + b;
    globalThis.badgeParts.p = d;
    globalThis.updateBadge();
    if (e || (g.biz || {}).notify === "off" || c.getHours() < 8) {
      return;
    }
    const y = _.length + "|" + b + "|" + h + "|" + m;
    if (!d && !h && !m) {
      return;
    }
    if (i.date === u && i.sig === y && c.getHours() - (i.hour ?? 0) < 4) {
      return;
    }
    const z = s[g.lang] || s.en;
    const C = [];
    if (!g.sec || !g.sec.hash) {
      _.slice(0, 3).forEach(n => C.push(n.n + " — " + BusinessCurrency.format(n.a, (g.biz || {}).currency || "INR")));
    }
    if (b) {
      C.push(z.tasks(b));
    }
    if (h) {
      C.push(z.fups(h));
    }
    if (m) {
      C.push(z.appts(m));
    }
    chrome.notifications.create("bp-" + Date.now(), {
      type: "basic",
      iconUrl: "icon128.png",
      title: _.length ? z.cash(_.length) : "Business Planner",
      message: C.join("\n") || " ",
      priority: 2,
      requireInteraction: !!_.length
    });
    await chrome.storage.local.set({
      notified: {
        date: u,
        sig: y,
        hour: c.getHours()
      }
    });
  }
})();
