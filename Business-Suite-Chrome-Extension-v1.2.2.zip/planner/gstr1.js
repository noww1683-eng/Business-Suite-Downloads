(function (e) {
  "use strict";

  const s = {
    "01": "Jammu & Kashmir",
    "02": "Himachal Pradesh",
    "03": "Punjab",
    "04": "Chandigarh",
    "05": "Uttarakhand",
    "06": "Haryana",
    "07": "Delhi",
    "08": "Rajasthan",
    "09": "Uttar Pradesh",
    10: "Bihar",
    11: "Sikkim",
    12: "Arunachal Pradesh",
    13: "Nagaland",
    14: "Manipur",
    15: "Mizoram",
    16: "Tripura",
    17: "Meghalaya",
    18: "Assam",
    19: "West Bengal",
    20: "Jharkhand",
    21: "Odisha",
    22: "Chhattisgarh",
    23: "Madhya Pradesh",
    24: "Gujarat",
    26: "Dadra & Nagar Haveli and Daman & Diu",
    27: "Maharashtra",
    29: "Karnataka",
    30: "Goa",
    31: "Lakshadweep",
    32: "Kerala",
    33: "Tamil Nadu",
    34: "Puducherry",
    35: "Andaman & Nicobar Islands",
    36: "Telangana",
    37: "Andhra Pradesh",
    38: "Ladakh",
    97: "Other Territory"
  };
  const n = e => Number(e) || 0;
  const r = e => Math.round((n(e) + Number.EPSILON) * 100) / 100;
  const a = /^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/;
  const o = e => String(e || "").replace(/\s+/g, "").toUpperCase();
  const i = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const l = e => {
    const n = String(e || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (n) {
      return n[3] + "-" + i[+n[2] - 1] + "-" + n[1];
    } else {
      return "";
    }
  };
  const g = e => String(e ?? "").replace(/[&<>"]/g, e => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;"
  })[e]).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
  function m(e) {
    const n = e.head.map((t, n) => Math.min(48, Math.max(String(t).length + 2, ...e.rows.map(e => String(e[n] ?? "").length + 2), 10)));
    const r = (e, t, n, r) => {
      const o = (e => {
        let t = "";
        for (e++; e > 0; e = Math.floor((e - 1) / 26)) {
          t += String.fromCharCode(65 + (e - 1) % 26);
        }
        return t;
      })(t) + (n + 1);
      if (typeof e === "number" && isFinite(e)) {
        return "<c r=\"" + o + "\" s=\"" + (r ? 1 : 2) + "\"><v>" + e + "</v></c>";
      } else {
        return "<c r=\"" + o + "\" s=\"" + (r ? 1 : 0) + "\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + g(e) + "</t></is></c>";
      }
    };
    const a = [e.head, ...e.rows];
    return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>" + n.map((e, t) => "<col min=\"" + (t + 1) + "\" max=\"" + (t + 1) + "\" width=\"" + e + "\" customWidth=\"1\"/>").join("") + "</cols><sheetData>" + a.map((e, t) => "<row r=\"" + (t + 1) + "\">" + e.map((e, s) => r(e, s, t, t === 0)).join("") + "</row>").join("") + "</sheetData></worksheet>";
  }
  const c = () => typeof Blob !== "undefined" && typeof document != "undefined" ? "blob" : "uint8array";
  const p = e => {
    e = String(e ?? "");
    if (/[",\r\n]/.test(e)) {
      return "\"" + e.replace(/"/g, "\"\"") + "\"";
    } else {
      return e;
    }
  };
  const u = e => "﻿" + [e.head, ...e.rows].map(e => e.map(p).join(",")).join("\r\n");
  e.Gstr1 = {
    build: function (e, i) {
      const m = i.biz || {};
      const c = i.customers || [];
      const p = o(m.gst);
      const u = /^\d{2}/.test(p) ? p.slice(0, 2) : "";
      const f = (i.sales || []).filter(t => (t.date || "").slice(0, 7) === e);
      const d = (i.purchases || []).filter(t => (t.date || "").slice(0, 7) === e);
      const b = [];
      if (p) {
        if (!a.test(p)) {
          b.push("Your own GST number in Business Profile does not look valid.");
        }
      } else {
        b.push("Your own GST number is not set in Business Profile.");
      }
      const h = f.map(e => {
        w = e.customer;
        const i = c.find(e => (e.name || "").trim().toLowerCase() === (w || "").trim().toLowerCase()) || {};
        const l = o(i.gstin);
        const p = a.test(l);
        const f = e.kind === "Return" ? -1 : 1;
        const d = (p ? l.slice(0, 2) : "") || (e => {
          const t = String(e || "").toLowerCase();
          if (!t) {
            return "";
          }
          for (const [e, n] of Object.entries(s)) {
            if (t.includes(n.toLowerCase())) {
              return e;
            }
          }
          return "";
        })(i.place) || u;
        const b = d && u ? d !== u : m.gstType === "igst";
        const h = r(n(e.taxable ?? e.total) * f);
        const x = r(n(e.gstAmt) * f);
        const C = r(n(e.total) * f);
        var w;
        var v;
        return {
          s: e,
          c: i,
          gstin: l,
          reg: p,
          bad: !!l && !p,
          sign: f,
          posCode: d,
          pos: (v = d, v && s[v] ? v + "-" + s[v] : ""),
          inter: b,
          rate: n(e.gst),
          taxable: h,
          tax: x,
          igst: b ? x : 0,
          cgst: b ? 0 : r(x / 2),
          sgst: b ? 0 : r(x - r(x / 2)),
          total: C
        };
      });
      h.filter(e => e.bad).forEach(e => b.push("Invoice " + e.s.no + ": customer GST number \"" + e.c.gstin + "\" is not valid — treated as unregistered."));
      h.filter(e => !e.posCode).forEach(e => b.push("Invoice " + e.s.no + ": place of supply unknown (set your GST number / the customer's GST number)."));
      const x = h.filter(e => !String(e.s.hsn || "").trim());
      if (x.length) {
        b.push(x.length + " invoice line(s) have no HSN/SAC code — fill the \"HSN / SAC code\" field on the bill.");
      }
      const C = {};
      const w = h.filter(e => e.sign > 0);
      const v = h.filter(e => e.sign < 0);
      C.b2b = {
        name: "B2B",
        head: ["GSTIN/UIN of Recipient", "Receiver Name", "Invoice Number", "Invoice date", "Invoice Value", "Place Of Supply", "Reverse Charge", "Applicable % of Tax Rate", "Invoice Type", "E-Commerce GSTIN", "Rate", "Taxable Value", "Cess Amount", "IGST", "CGST", "SGST"],
        rows: w.filter(e => e.reg).map(e => [e.gstin, e.s.customer || e.c.name || "", e.s.no, l(e.s.date), e.total, e.pos, "N", "", "Regular B2B", "", e.rate, e.taxable, 0, e.igst, e.cgst, e.sgst])
      };
      const y = new Map();
      h.filter(e => !e.reg).forEach(e => {
        const s = e.pos + "|" + e.rate;
        const n = y.get(s) || {
          pos: e.pos,
          rate: e.rate,
          taxable: 0,
          igst: 0,
          cgst: 0,
          sgst: 0
        };
        n.taxable += e.taxable;
        n.igst += e.igst;
        n.cgst += e.cgst;
        n.sgst += e.sgst;
        y.set(s, n);
      });
      C.b2cs = {
        name: "B2CS",
        head: ["Type", "Place Of Supply", "Applicable % of Tax Rate", "Rate", "Taxable Value", "Cess Amount", "E-Commerce GSTIN", "IGST", "CGST", "SGST"],
        rows: [...y.values()].sort((e, t) => e.pos.localeCompare(t.pos) || e.rate - t.rate).map(e => ["OE", e.pos, "", e.rate, r(e.taxable), 0, "", r(e.igst), r(e.cgst), r(e.sgst)])
      };
      C.cdnr = {
        name: "CDNR",
        head: ["GSTIN/UIN of Recipient", "Receiver Name", "Note Number", "Note Date", "Note Type", "Place Of Supply", "Reverse Charge", "Note Supply Type", "Note Value", "Applicable % of Tax Rate", "Rate", "Taxable Value", "Cess Amount", "IGST", "CGST", "SGST"],
        rows: v.filter(e => e.reg).map(e => [e.gstin, e.s.customer || "", e.s.no, l(e.s.date), "C", e.pos, "N", "Regular B2B", Math.abs(e.total), "", e.rate, Math.abs(e.taxable), 0, Math.abs(e.igst), Math.abs(e.cgst), Math.abs(e.sgst)])
      };
      const z = new Map();
      h.forEach(e => {
        const s = String(e.s.hsn || "").trim();
        const r = s + "|" + e.rate;
        const a = z.get(r) || {
          hsn: s,
          desc: e.s.item || "",
          qty: 0,
          total: 0,
          taxable: 0,
          igst: 0,
          cgst: 0,
          sgst: 0,
          rate: e.rate
        };
        a.qty += n(e.s.qty) * e.sign;
        a.total += e.total;
        a.taxable += e.taxable;
        a.igst += e.igst;
        a.cgst += e.cgst;
        a.sgst += e.sgst;
        z.set(r, a);
      });
      C.hsn = {
        name: "HSN",
        head: ["HSN", "Description", "UQC", "Total Quantity", "Total Value", "Rate", "Taxable Value", "Integrated Tax Amount", "Central Tax Amount", "State/UT Tax Amount", "Cess Amount"],
        rows: [...z.values()].map(e => [e.hsn || "(missing)", e.desc, "NOS-NUMBERS", r(e.qty), r(e.total), e.rate, r(e.taxable), r(e.igst), r(e.cgst), r(e.sgst), 0])
      };
      const B = w.map(e => String(e.s.no || "")).filter(Boolean).sort();
      const I = v.map(e => String(e.s.no || "")).filter(Boolean).sort();
      C.docs = {
        name: "Docs",
        head: ["Nature of Document", "Sr. No. From", "Sr. No. To", "Total Number", "Cancelled"],
        rows: [...(B.length ? [["Invoices for outward supply", B[0], B[B.length - 1], B.length, 0]] : []), ...(I.length ? [["Credit Note", I[0], I[I.length - 1], I.length, 0]] : [])]
      };
      C.register = {
        name: "Sales register",
        head: ["Invoice", "Date", "Type", "Customer", "Customer GSTIN", "Place Of Supply", "Item", "HSN/SAC", "Qty", "Rate %", "Taxable", "IGST", "CGST", "SGST", "Total", "Payment"],
        rows: h.map(e => [e.s.no, l(e.s.date), e.s.kind === "Return" ? "Credit note" : "Invoice", e.s.customer || "", e.c.gstin || "", e.pos, e.s.item || "", e.s.hsn || "", n(e.s.qty) * e.sign, e.rate, e.taxable, e.igst, e.cgst, e.sgst, e.total, e.s.pay || ""])
      };
      C.purchases = {
        name: "Purchases (ITC)",
        head: ["Date", "Supplier", "Item", "Rate %", "Taxable", "GST", "Total"],
        rows: d.filter(e => n(e.gstAmt)).map(e => [l(e.date), e.supplier || "", e.item || "", n(e.gst), r(e.taxable ?? n(e.total) - n(e.gstAmt)), r(e.gstAmt), r(e.total)])
      };
      const M = {
        taxable: r(h.reduce((e, t) => e + t.taxable, 0)),
        igst: r(h.reduce((e, t) => e + t.igst, 0)),
        cgst: r(h.reduce((e, t) => e + t.cgst, 0)),
        sgst: r(h.reduce((e, t) => e + t.sgst, 0)),
        value: r(h.reduce((e, t) => e + t.total, 0)),
        itc: (L = C.purchases.rows, D = 5, r(L.reduce((e, t) => e + n(t[D]), 0)))
      };
      var L;
      var D;
      C.summary = {
        name: "Summary",
        head: ["Item", "Value"],
        rows: [["Business", m.name || ""], ["GSTIN", p], ["Return period", e], ["Invoices / credit notes", w.length + " / " + v.length], ["Total taxable value (net of credit notes)", M.taxable], ["IGST", M.igst], ["CGST", M.cgst], ["SGST", M.sgst], ["Total invoice value", M.value], ["B2B invoices", C.b2b.rows.length], ["B2C (small) groups", C.b2cs.rows.length], ["Credit notes (registered)", C.cdnr.rows.length], ["Input tax credit from purchases (GST paid)", M.itc], ["Net GST payable (output − input credit)", r(M.igst + M.cgst + M.sgst - M.itc)], ["", ""], ["CHECK BEFORE FILING", b.length ? "" : "No problems found in the data."], ...b.map(e => ["", e]), ["", ""], ["Note", "Prepared from Business Planner data as working papers for your accountant. Please verify before filing on the GST portal."]]
      };
      return {
        tables: C,
        order: ["summary", "b2b", "b2cs", "cdnr", "hsn", "docs", "register", "purchases"],
        warnings: b,
        totals: M,
        counts: {
          invoices: w.length,
          credits: v.length
        }
      };
    },
    toXlsx: async function (s) {
      const r = new (e.JSZip || (typeof require !== "undefined" ? require("../tracker/vendor/jszip.min.js") : null))();
      const a = new Set();
      const o = s.order.map(e => s.tables[e]);
      const i = o.map(e => ((e, s) => {
        let r = String(e).replace(/[\\\/\?\*\[\]:]/g, " ").slice(0, 31) || "Sheet";
        let a = r;
        let o = 2;
        while (s.has(a.toLowerCase())) {
          a = r.slice(0, 28) + " " + o++;
        }
        s.add(a.toLowerCase());
        return a;
      })(e.name, a));
      r.file("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" + o.map((e, t) => "<Override PartName=\"/xl/worksheets/sheet" + (t + 1) + ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>").join("") + "</Types>");
      r.file("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
      r.file("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>" + i.map((e, t) => "<sheet name=\"" + g(e) + "\" sheetId=\"" + (t + 1) + "\" r:id=\"rId" + (t + 1) + "\"/>").join("") + "</sheets></workbook>");
      r.file("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + o.map((e, t) => "<Relationship Id=\"rId" + (t + 1) + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet" + (t + 1) + ".xml\"/>").join("") + "<Relationship Id=\"rId" + (o.length + 1) + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
      r.file("xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF167768\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
      o.forEach((e, t) => r.file("xl/worksheets/sheet" + (t + 1) + ".xml", m(e)));
      return r.generateAsync({
        type: c(),
        mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        compression: "DEFLATE"
      });
    },
    toCsvZip: async function (s) {
      const r = new (e.JSZip || (typeof require !== "undefined" ? require("../tracker/vendor/jszip.min.js") : null))();
      s.order.forEach((e, t) => {
        const o = s.tables[e];
        r.file(String(t + 1).padStart(2, "0") + "-" + o.name.replace(/[^A-Za-z0-9]+/g, "-").replace(/-$/, "") + ".csv", u(o));
      });
      return r.generateAsync({
        type: c(),
        mimeType: "application/zip",
        compression: "DEFLATE"
      });
    },
    toCsv: u,
    STATES: s
  };
  if (typeof module != "undefined" && module.exports) {
    module.exports = e.Gstr1;
  }
})(typeof window !== "undefined" ? window : globalThis);
