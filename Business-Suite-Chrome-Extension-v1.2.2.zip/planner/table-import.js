"use strict";

const TI = {
  file: "",
  headers: [],
  data: [],
  map: {},
  module: "customers",
  result: null,
  busy: false
};
const TI_MODULES = ["customers", "products", "stock", "sales", "ledger", "payments", "staff", "suppliers"];
const TI_REQUIRED = {
  customers: ["name"],
  products: ["name", "cost", "price"],
  stock: ["item", "bal"],
  sales: ["no", "date", "customer", "qty", "rate", "rcv"],
  ledger: ["date", "type", "amount"],
  payments: ["dir", "party", "amount", "rcv"],
  staff: ["name", "salary"],
  suppliers: ["name"]
};
const TI_ALIAS = {
  name: ["customername", "clientname", "productname", "staffname", "suppliername"],
  phone: ["mobile", "mobilenumber", "contact"],
  no: ["invoice", "invoiceno", "invoicenumber", "billno"],
  date: ["invoicedate", "billdate"],
  customer: ["customername", "client"],
  item: ["product", "productname", "description"],
  qty: ["quantity"],
  rate: ["unitprice", "price"],
  rcv: ["received", "amountreceived", "paidamount"],
  due: ["duedate"],
  bal: ["stock", "balance", "quantity", "closingstock"],
  min: ["minimumstock"],
  cat: ["category"],
  amount: ["total", "expenseamount"],
  party: ["customer", "supplier"],
  cost: ["costprice"],
  price: ["sellingprice"],
  salary: ["monthlysalary"]
};
function tiFields() {
  return modById[TI.module].f.filter(t => !["pay", "status", "kind", "present", "leave"].includes(t.k) || !["sales", "payments", "staff"].includes(TI.module)).filter(e => !["kind"].includes(e.k) || TI.module !== "sales").concat(["sales", "payments"].includes(TI.module) ? [{
    k: "paidOn",
    l: "Received on (required when received > 0)",
    t: "date"
  }] : []);
}
function tiCSV(e) {
  const r = (e = e.replace(/^\uFEFF/, "")).split(/\r?\n/)[0];
  const n = r.includes("\t") ? "\t" : r.split(";").length > r.split(",").length ? ";" : ",";
  const s = [];
  let i = [];
  let a = "";
  let o = false;
  for (let r = 0; r < e.length; r++) {
    const t = e[r];
    if (o) {
      if (t === "\"") {
        if (e[r + 1] === "\"") {
          a += "\"";
          r++;
        } else {
          o = false;
        }
      } else {
        a += t;
      }
    } else if (t === "\"") {
      if (a) {
        throw Error("Invalid CSV quotes.");
      }
      o = true;
    } else if (t === n) {
      i.push(a);
      a = "";
    } else if (t === "\n" || t === "\r") {
      if (t === "\r" && e[r + 1] === "\n") {
        r++;
      }
      i.push(a);
      s.push(i);
      i = [];
      a = "";
    } else {
      a += t;
    }
  }
  if (o) {
    throw Error("Unclosed CSV quotation.");
  }
  if (a || i.length) {
    i.push(a);
    s.push(i);
  }
  return s.filter(e => e.some(e => String(e).trim()));
}
function tiDate(e) {
  if (!e) {
    return "";
  }
  let r = String(e).trim();
  if (/^\d+(\.0+)?$/.test(r)) {
    const e = Number(r);
    if (e < 61 || e > 100000) {
      throw Error("Invalid Excel date");
    }
    return new Date(Date.UTC(1899, 11, 30) + e * 86400000).toISOString().slice(0, 10);
  }
  let n = r.match(/^(\d{2})[\/.](\d{2})[\/.](\d{4})$/);
  if (n) {
    r = n[3] + "-" + n[2] + "-" + n[1];
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(r) || isNaN(Date.parse(r)) || new Date(r + "T00:00:00Z").toISOString().slice(0, 10) !== r) {
    throw Error("Use YYYY-MM-DD or DD/MM/YYYY");
  }
  return r;
}
function tiNumber(e) {
  const r = String(e).trim().replace(/^[A-Za-z]{3}\s*/, "").replace(/[₹$€£¥,\s]/g, "");
  if (!/^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(r) || !Number.isFinite(Number(r))) {
    throw Error("Invalid number");
  }
  return Number(r);
}
function tiMatch() {
  TI.map = {};
  for (const t of tiFields()) {
    const r = [t.k, t.l, ...(TI_ALIAS[t.k] || [])].map(nk);
    const n = TI.headers.findIndex(t => r.includes(nk(t)));
    TI.map[t.k] = n < 0 ? "" : String(n);
  }
  TI.result = null;
}
async function tiRead(e) {
  if (!e) {
    return;
  }
  if (e.size > 5242880) {
    throw Error("Maximum file size: 5 MB. Split larger files.");
  }
  let r;
  let n = "";
  if (/\.xlsx$/i.test(e.name)) {
    const s = await readXLSX(e);
    r = s.rows;
    n = " · first worksheet: " + s.sheet;
  } else {
    if (!/\.(csv|tsv)$/i.test(e.name)) {
      throw Error("Choose .xlsx, .csv or .tsv. Save old .xls files as .xlsx first.");
    }
    r = tiCSV(await e.text());
  }
  if (r.length < 2) {
    throw Error("Include a header row and at least one data row.");
  }
  if (r.length > 5001) {
    throw Error("Maximum 5,000 data rows per file.");
  }
  const s = Array.from(r.shift(), e => String(e ?? "").trim());
  if (s.length > 50 || s.some(e => !e) || new Set(s.map(e => e.toLowerCase())).size !== s.length) {
    throw Error("Use 1–50 unique, non-empty column headers.");
  }
  if (r.some(e => e.length > s.length)) {
    throw Error("A row contains more values than the header row.");
  }
  TI.headers = s;
  TI.data = r;
  TI.file = e.name + n;
  tiMatch();
  render();
}
function tiKey(e) {
  const r = {
    customers: "name",
    products: "name",
    stock: "item",
    sales: "no",
    staff: "name",
    suppliers: "name"
  }[TI.module];
  if (r) {
    return String(e[r] || "").trim().toLowerCase();
  } else {
    return JSON.stringify(tiFields().map(t => e[t.k] ?? ""));
  }
}
function tiPreview() {
  const t = tiFields();
  const r = TI_REQUIRED[TI.module];
  const n = r.filter(e => TI.map[e] === "");
  if (n.length) {
    throw Error("Map required columns: " + n.join(", "));
  }
  const s = Object.values(TI.map).filter(e => e !== "");
  if (new Set(s).size !== s.length) {
    throw Error("Map each source column to only one field.");
  }
  const i = new Set(rows(TI.module).map(tiKey));
  const a = [];
  const o = [];
  let l = 0;
  TI.data.forEach((n, s) => {
    try {
      const e = {
        id: uid(),
        created: today()
      };
      for (const s of t) {
        const t = TI.map[s.k] === "" ? "" : String(n[Number(TI.map[s.k])] ?? "").trim();
        if (!t && r.includes(s.k)) {
          throw Error(s.l + " is required");
        }
        if (t) {
          try {
            e[s.k] = s.t === "number" ? tiNumber(t) : s.t === "date" ? tiDate(t) : t;
            if (s.t === "number" && e[s.k] < 0) {
              throw Error("Negative values are not supported");
            }
            if (s.t === "select") {
              const r = s.opts.find(e => String(e).toLowerCase() === t.toLowerCase());
              if (!r) {
                throw Error("Choose " + s.opts.join(" / "));
              }
              e[s.k] = r;
            }
          } catch (e) {
            throw Error(s.l + ": " + e.message);
          }
        }
      }
      if (TI.module === "sales") {
        if (e.qty <= 0) {
          throw Error("Quantity must be positive");
        }
        e.discount = e.discount || 0;
        e.gst = e.gst || 0;
        if (e.discount > e.qty * e.rate) {
          throw Error("Discount exceeds sale amount");
        }
        if (e.gst > 100) {
          throw Error("GST must be 0–100");
        }
        e.kind = "Sale";
        gstCalc(e, e.qty * e.rate - e.discount);
      }
      if (["sales", "payments"].includes(TI.module)) {
        const t = TI.module === "sales" ? e.total : e.amount;
        if (e.rcv > t) {
          throw Error("Received exceeds total");
        }
        if (e.rcv > 0 && !e.paidOn) {
          throw Error("Received on date is required");
        }
        if (e.date && e.paidOn && e.paidOn < e.date) {
          throw Error("Receipt date is before invoice date");
        }
        e.pays = e.rcv > 0 ? [{
          date: e.paidOn,
          amt: e.rcv
        }] : [];
        e[TI.module === "sales" ? "pay" : "status"] = e.rcv >= t ? "Paid" : e.rcv > 0 ? "Partial" : "Pending";
      }
      if (TI.module === "products") {
        e.kind = e.kind || "Product";
      }
      const s = tiKey(e);
      if (i.has(s)) {
        l++;
        return;
      }
      i.add(s);
      a.push(e);
    } catch (e) {
      o.push({
        row: s + 2,
        message: e.message
      });
    }
  });
  return {
    records: a,
    errors: o,
    duplicates: l
  };
}
function tiPanel() {
  const t = TI.module;
  const r = tiFields();
  const n = TI.result;
  return "<div class=\"panel\" id=\"tableImport\"><h3>Excel / CSV Import Wizard</h3><p>One client and one category per import. Files stay on this device. XLSX uses the first worksheet; formulas must be pasted as values. Maximum 5 MB / 5,000 rows.</p><div class=\"grid\"><label>Category<select id=\"tiModule\">" + TI_MODULES.map(r => "<option value=\"" + r + "\" " + (r === t ? "selected" : "") + ">" + esc(modById[r].n) + "</option>").join("") + "</select></label><label>Upload file<input id=\"tiFile\" type=\"file\" accept=\".xlsx,.csv,.tsv\"></label></div><p>Dates: YYYY-MM-DD or DD/MM/YYYY. Keep phone numbers as Text in Excel. One row = one single-item invoice (unique invoice number). Multi-line invoices, returns and attendance are not supported here. Received amount becomes one receipt on the mapped date. Bills use your Business Profile GST settings. Stock import is a closing-stock snapshot; historical bills do not reduce it again. Import receipt amounts only once, not again as Income or Payment Tracking.</p>" + (TI.file ? "<h4>" + esc(TI.file) + " — " + TI.data.length + " rows</h4><div class=\"grid\">" + r.map(r => "<label>" + esc(r.l) + (TI_REQUIRED[t].includes(r.k) ? " *" : "") + "<select data-ti-map=\"" + r.k + "\"><option value=\"\">Skip / blank</option>" + TI.headers.map((t, n) => "<option value=\"" + n + "\" " + (TI.map[r.k] === String(n) ? "selected" : "") + ">" + esc(t) + "</option>").join("") + "</select></label>").join("") + "</div><p><button data-ti=\"preview\">Validate & preview</button> <button data-ti=\"cancel\">Clear file</button></p>" : "") + (n ? "<p><b>" + n.records.length + " new records · " + n.duplicates + " duplicates skipped · " + n.errors.length + " errors</b></p>" + (n.errors.length ? "<p role=\"alert\">Fix these rows in your source file and upload again. Import is blocked until all errors are corrected.</p><ul>" + n.errors.slice(0, 30).map(t => "<li>Row " + t.row + ": " + esc(t.message) + "</li>").join("") + "</ul>" + (n.errors.length > 30 ? "<p>Only the first 30 errors are shown.</p>" : "") : "") + "<div class=\"tablewrap\"><table><thead><tr>" + r.map(t => "<th>" + esc(t.l) + "</th>").join("") + "</tr></thead><tbody>" + n.records.slice(0, 20).map(t => "<tr>" + r.map(r => "<td>" + esc(t[r.k] ?? "") + "</td>").join("") + "</tr>").join("") + "</tbody></table></div><p>Preview shows the first 20 new records. Existing records with the same name / invoice number are skipped, never overwritten. For ledger and payments, exact field matches are skipped.</p><button data-ti=\"json\" " + (n.errors.length || !n.records.length ? "disabled" : "") + ">Download Planner JSON</button> <button class=\"primary\" data-ti=\"import\" " + (n.errors.length || !n.records.length ? "disabled" : "") + ">Backup & add to Planner</button>" : "") + "</div>";
}
const tiOldBackupExtras = backupExtras;
backupExtras = function () {
  return tiPanel() + tiOldBackupExtras();
};
document.addEventListener("change", async e => {
  try {
    if (e.target.id === "tiFile") {
      await tiRead(e.target.files[0]);
    }
    if (e.target.id === "tiModule") {
      TI.module = e.target.value;
      tiMatch();
      render();
    }
    if (e.target.matches("[data-ti-map]")) {
      TI.map[e.target.dataset.tiMap] = e.target.value;
      TI.result = null;
      render();
    }
  } catch (e) {
    TI.file = "";
    TI.data = [];
    TI.result = null;
    render();
    toast(e.message, true);
  }
});
document.addEventListener("click", async e => {
  const r = e.target.closest("[data-ti]");
  if (r && !TI.busy && !isLocked()) {
    try {
      const e = r.dataset.ti;
      if (e === "cancel") {
        TI.file = "";
        TI.data = [];
        TI.result = null;
        return render();
      }
      TI.result = tiPreview();
      if (e === "preview") {
        return render();
      }
      const n = TI.result;
      if (n.errors.length || !n.records.length) {
        throw Error("Resolve errors and preview new records first.");
      }
      if (e === "json") {
        return download("planner-" + TI.module + "-import.json", JSON.stringify({
          app: "business-planner",
          savedAt: new Date().toISOString(),
          db: {
            [TI.module]: n.records
          }
        }, null, 2), "application/json");
      }
      if (e === "import") {
        TI.busy = true;
        download("planner-before-import-" + Date.now() + ".json", JSON.stringify({
          app: "business-planner",
          savedAt: new Date().toISOString(),
          db: state.db,
          biz: biz()
        }, null, 2), "application/json");
        if (!confirm("Confirm the backup has finished downloading. Add " + n.records.length + " " + modById[TI.module].n + " records to " + (biz().name || "this Planner") + "? Existing records are kept.")) {
          return;
        }
        const e = JSON.parse(JSON.stringify(state.db));
        e[TI.module] = (e[TI.module] || []).concat(n.records);
        if (hasChrome) {
          await chrome.storage.local.set({
            db: e
          });
        } else {
          localStorage.setItem("bp", JSON.stringify({
            db: e,
            settings: state.settings
          }));
        }
        state.db = e;
        TI.result = null;
        TI.file = "";
        TI.data = [];
        render();
        toast("Import completed.");
      }
    } catch (e) {
      toast(e.message, true);
    } finally {
      TI.busy = false;
    }
  }
});
