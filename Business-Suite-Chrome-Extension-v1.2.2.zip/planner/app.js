"use strict";

const $ = (e, a = document) => a.querySelector(e);
const pad = e => String(e).padStart(2, "0");
const ymd = e => e.getFullYear() + "-" + pad(e.getMonth() + 1) + "-" + pad(e.getDate());
const today = () => ymd(new Date());
const addDays = (e, a) => {
  const s = new Date(e + "T00:00:00");
  s.setDate(s.getDate() + a);
  return ymd(s);
};
const money = e => BusinessCurrency.format(e, biz().currency || "INR");
const esc = e => String(e ?? "").replace(/[&<>"']/g, e => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "\"": "&quot;",
  "'": "&#39;"
})[e]);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const fmtDate = e => {
  if (!e) {
    return "—";
  }
  const [a, n, s] = e.split("-");
  if (s) {
    return s + "-" + n + "-" + a;
  } else {
    return e;
  }
};
const num = e => Number(e) || 0;
const sum = (e, a = e => e) => e.reduce((e, n) => e + num(a(n)), 0);
const daysBetween = (e, a) => Math.round((new Date(e + "T00:00:00") - new Date(a + "T00:00:00")) / 86400000);
const F = (e, a, n = "text", s = {}) => ({
  k: e,
  l: a,
  t: n,
  ...s
});
const PLAN_STATUS = ["Not started", "In progress", "Completed", "On hold"];
const PLAN_FIELDS = [F("name", "Plan name", "text", {
  req: 1
}), F("goal", "Goal", "text"), F("budget", "Budget (₹)", "number", {
  m: 1
}), F("person", "Responsible person"), F("start", "Start date", "date"), F("deadline", "Deadline", "date"), F("tasks", "Tasks", "textarea", {
  span: 2
}), F("status", "Status", "select", {
  opts: PLAN_STATUS
}), F("result", "Actual result", "textarea", {
  span: 2
})];
const MODS = [{
  id: "dashboard",
  n: "Dashboard",
  i: "🏠",
  basic: 1,
  g: "Overview",
  custom: "dashboard"
}, {
  id: "goals",
  n: "Goals & Targets",
  i: "🎯",
  g: "Overview",
  title: e => e.name,
  f: [F("name", "Goal name", "text", {
    req: 1
  }), F("type", "Measure", "select", {
    opts: ["Sales", "Profit", "New customers"]
  }), F("period", "Period", "select", {
    opts: ["Daily", "Monthly", "Yearly"]
  }), F("target", "Target", "number"), F("start", "From", "date", {
    req: 1
  }), F("end", "To", "date", {
    req: 1
  })],
  cols: ["name", "type", "period", "start", "end", "target", {
    l: "Actual",
    f: e => goalActual(e),
    num: 1,
    m: 1
  }, {
    l: "Progress",
    f: e => bar(goalActual(e), e.target),
    html: 1
  }]
}, {
  id: "plans",
  n: "Business Planner",
  i: "📋",
  basic: 1,
  g: "Plan",
  f: PLAN_FIELDS,
  cols: ["name", "goal", "budget", "person", "start", "deadline", "status", "result"],
  due: e => planDue(e)
}, {
  id: "tasks",
  n: "Tasks & Calendar",
  i: "✅",
  basic: 1,
  g: "Plan",
  f: [F("name", "Task", "text", {
    req: 1,
    span: 2
  }), F("who", "Assigned to"), F("priority", "Priority", "select", {
    opts: ["High", "Medium", "Low"]
  }), F("due", "Due date", "date"), F("remind", "Reminder date", "date"), F("progress", "Progress %", "number"), F("status", "Status", "select", {
    opts: ["To do", "In progress", "Done"]
  })],
  cols: ["name", "who", "priority", "due", "progress", "status"],
  quick: {
    k: "status",
    v: "Done",
    l: "✓ Done"
  },
  due: e => e.status === "Done" ? "" : e.due && e.due < today() ? "due" : e.due === today() || e.remind === today() ? "soon" : ""
}, {
  id: "customers",
  n: "Customers (CRM)",
  i: "👥",
  basic: 1,
  g: "Sell",
  title: e => e.name,
  f: [F("name", "Customer name", "text", {
    req: 1
  }), F("phone", "Phone", "tel"), F("place", "Place"), F("gstin", "Customer GST number"), F("needs", "Needs / interests", "text", {
    span: 2
  }), F("notes", "Notes", "textarea", {
    span: 2
  })],
  cols: ["name", "phone", "place", "needs", {
    l: "Purchases",
    f: e => sum(salesOf(e.name), salesNet),
    num: 1,
    m: 1
  }, {
    l: "Orders",
    f: e => salesOf(e.name).length,
    num: 1
  }],
  rowActs: () => [["statement", "Statement"]]
}, {
  id: "leads",
  n: "Leads & Follow-ups",
  i: "📞",
  basic: 1,
  g: "Sell",
  title: e => e.name,
  f: [F("name", "Name", "text", {
    req: 1
  }), F("phone", "Phone", "tel"), F("source", "Source", "select", {
    opts: ["Walk-in", "Phone", "WhatsApp", "Instagram", "Facebook", "Referral", "Other"]
  }), F("interest", "Interested in"), F("stage", "Stage", "select", {
    opts: ["New", "Contacted", "Quotation sent", "Won", "Lost"]
  }), F("follow", "Next follow-up", "date"), F("value", "Expected value (₹)", "number", {
    m: 1
  }), F("note", "Note", "text", {
    span: 2
  })],
  cols: ["name", "phone", "interest", "stage", "follow", "value"],
  due: e => ["Won", "Lost"].includes(e.stage) ? "" : e.follow && e.follow < today() ? "due" : e.follow === today() ? "soon" : ""
}, {
  id: "quotes",
  n: "Quotation & Estimates",
  i: "📝",
  g: "Sell",
  f: [F("no", "Quotation no.", "text", {
    req: 1
  }), F("date", "Date", "date"), F("customer", "Customer", "text", {
    list: "customers"
  }), F("valid", "Valid till", "date"), F("items", "Items / description", "textarea", {
    span: 2
  }), F("amount", "Amount", "number", {
    m: 1
  }), F("status", "Status", "select", {
    opts: ["Draft", "Sent", "Approved", "Rejected", "Invoiced"]
  })],
  cols: ["no", "date", "customer", "amount", "valid", "status"],
  rowActs: e => [...(e.status === "Approved" ? [["toInvoice", "→ Invoice"]] : []), ["print", "Print"]]
}, {
  id: "sales",
  n: "Sales & Billing",
  i: "🧾",
  basic: 1,
  g: "Sell",
  f: [F("no", "Invoice no.", "text", {
    req: 1,
    def: "nextinv"
  }), F("date", "Date", "date", {
    req: 1,
    def: "today"
  }), F("customer", "Customer", "text", {
    list: "customers"
  }), F("phone", "Customer phone (for WhatsApp)", "tel"), F("item", "Product / service", "text", {
    list: "products"
  }), F("hsn", "HSN / SAC code (for GST)", "text"), F("qty", "Qty", "number", {
    def: 1
  }), F("rate", "Rate", "number"), F("discount", "Discount", "number"), F("gst", "GST %", "number", {
    def: "gstdef"
  }), F("kind", "Type", "select", {
    opts: ["Sale", "Return"]
  }), F("pay", "Payment", "select", {
    opts: ["Pending", "Partial", "Paid"]
  }), F("rcv", "Amount received so far", "number", {
    m: 1
  }), F("due", "Payment last date", "date"), F("note", "Note")],
  cols: ["no", "date", "customer", "item", {
    l: "Total",
    f: e => salesNet(e),
    num: 1,
    m: 1
  }, {
    l: "Received",
    f: e => e.kind === "Return" ? 0 : num(e.rcv),
    num: 1,
    m: 1
  }, {
    l: "Balance",
    f: e => balance(e),
    num: 1,
    m: 1
  }, "pay", "due"],
  calc: e => {
    gstCalc(e, num(e.qty) * num(e.rate) - num(e.discount));
    settle(e, "pay", e.total);
    restock(e, "item", e.kind === "Return" ? num(e.qty) : -num(e.qty));
  },
  stockRevert: 1,
  due: e => unpaid(e) && e.due && e.due <= today() ? "due" : "",
  rowActs: e => [...(unpaid(e) ? [["addPay", "+ Payment"], ["wa", "WhatsApp"]] : []), ["waInv", "📄 PDF"], ["print", "Print"]]
}, {
  id: "recurring",
  n: "Repeating Items",
  i: "🔁",
  g: "Money",
  f: [F("title", "Title (rent, salary, EMI…)", "text", {
    req: 1,
    span: 2
  }), F("kind", "Create as", "select", {
    opts: ["Expense", "Income", "To pay"]
  }), F("cat", "Category", "text", {
    list: "expcats"
  }), F("amount", "Amount", "number", {
    req: 1,
    m: 1
  }), F("day", "Day of month (1-28)", "number", {
    def: 1
  }), F("start", "Start date", "date", {
    def: "today"
  }), F("end", "End date (optional)", "date"), F("active", "Active", "select", {
    opts: ["Yes", "No"]
  })],
  cols: ["title", "kind", "cat", "amount", "day", "start", "end", "active", {
    l: "Last created",
    f: e => e.last || "—"
  }]
}, {
  id: "gst",
  n: "GST Report",
  i: "🧮",
  g: "Money",
  custom: "gst"
}, {
  id: "budget",
  n: "Budget Planning",
  i: "💼",
  g: "Money",
  f: [F("cat", "Category", "text", {
    req: 1,
    list: "expcats"
  }), F("month", "Month", "month", {
    req: 1,
    def: "month"
  }), F("amount", "Budget", "number", {
    m: 1
  })],
  cols: ["cat", "month", "amount", {
    l: "Actual spent",
    f: e => budgetActual(e),
    num: 1,
    m: 1
  }, {
    l: "Used",
    f: e => bar(budgetActual(e), e.amount, true),
    html: 1
  }],
  due: e => budgetActual(e) > num(e.amount) && num(e.amount) > 0 ? "due" : ""
}, {
  id: "ledger",
  n: "Income & Expenses",
  i: "💰",
  basic: 1,
  g: "Money",
  f: [F("date", "Date", "date", {
    req: 1,
    def: "today"
  }), F("type", "Type", "select", {
    opts: ["Expense", "Income"]
  }), F("cat", "Category", "text", {
    list: "expcats"
  }), F("amount", "Amount (₹)", "number", {
    req: 1,
    m: 1
  }), F("note", "Note", "text", {
    span: 2
  })],
  cols: ["date", "type", "cat", "amount", "note"],
  sortBy: "date"
}, {
  id: "cashflow",
  n: "Cash Flow Planning",
  i: "📈",
  g: "Money",
  custom: "cashflow",
  f: [F("date", "Expected date", "date", {
    req: 1
  }), F("dir", "Direction", "select", {
    opts: ["Incoming", "Outgoing"]
  }), F("desc", "Description", "text", {
    span: 2
  }), F("amount", "Amount", "number", {
    m: 1
  })],
  cols: ["date", "dir", "desc", "amount"],
  sortBy: "date",
  asc: 1
}, {
  id: "payments",
  n: "Payment Tracking",
  i: "⏰",
  basic: 1,
  g: "Money",
  f: [F("dir", "Type", "select", {
    opts: ["To receive", "To pay"]
  }), F("party", "Customer / supplier", "text", {
    req: 1,
    list: "customers"
  }), F("phone", "Phone (for WhatsApp)", "tel"), F("amount", "Amount", "number", {
    req: 1,
    m: 1
  }), F("rcv", "Amount paid so far (₹)", "number", {
    m: 1
  }), F("due", "Last date to pay", "date"), F("inst", "Installment details", "text"), F("remind", "Reminder date", "date"), F("status", "Status", "select", {
    opts: ["Pending", "Partial", "Paid"]
  })],
  cols: ["party", "dir", "amount", {
    l: "Paid",
    f: e => num(e.rcv),
    num: 1,
    m: 1
  }, {
    l: "Balance",
    f: e => balance(e),
    num: 1,
    m: 1
  }, "due", "inst", "status"],
  calc: e => settle(e, "status", num(e.amount)),
  due: e => unpaid(e) && e.due && e.due <= today() ? "due" : "",
  sortDue: 1,
  rowActs: e => unpaid(e) ? [["addPay", "+ Payment"], ["wa", "WhatsApp"]] : []
}, {
  id: "products",
  n: "Products & Services",
  i: "📦",
  basic: 1,
  g: "Stock",
  f: [F("name", "Name", "text", {
    req: 1
  }), F("kind", "Type", "select", {
    opts: ["Product", "Service"]
  }), F("cost", "Cost", "number"), F("price", "Selling price", "number")],
  cols: ["name", "kind", "cost", "price", {
    l: "Profit",
    f: e => num(e.price) - num(e.cost),
    num: 1,
    m: 1
  }, {
    l: "Margin",
    f: e => num(e.price) ? Math.round((num(e.price) - num(e.cost)) / num(e.price) * 100) + "%" : "—",
    num: 1
  }]
}, {
  id: "stock",
  n: "Stock & Purchase",
  i: "🏬",
  g: "Stock",
  f: [F("item", "Item", "text", {
    req: 1,
    list: "products"
  }), F("bal", "Stock balance", "number"), F("min", "Low-stock level", "number"), F("reorder", "Reorder quantity", "number"), F("supplier", "Supplier", "text", {
    list: "suppliers"
  }), F("po", "Purchase order", "select", {
    opts: ["None", "Ordered", "Received"]
  }), F("last", "Last purchase date", "date")],
  cols: ["item", "bal", "min", "reorder", "supplier", "po"],
  due: e => lowStock(e) ? "due" : ""
}, {
  id: "purchases",
  n: "Purchases",
  i: "🛒",
  g: "Stock",
  f: [F("date", "Date", "date", {
    req: 1,
    def: "today"
  }), F("supplier", "Supplier", "text", {
    list: "suppliers"
  }), F("item", "Item", "text", {
    req: 1,
    list: "stockitems"
  }), F("qty", "Qty", "number", {
    req: 1
  }), F("rate", "Rate (₹)", "number"), F("gst", "GST %", "number", {
    def: "gstdef"
  }), F("pay", "Payment", "select", {
    opts: ["Paid", "Pending"]
  }), F("note", "Note")],
  cols: ["date", "supplier", "item", "qty", "rate", {
    l: "Amount",
    f: e => e.total ?? num(e.qty) * num(e.rate),
    num: 1,
    m: 1
  }, "pay"],
  sortBy: "date",
  calc: e => {
    gstCalc(e, num(e.qty) * num(e.rate));
    restock(e, "item", num(e.qty));
    const n = stockFind(e.item);
    if (n) {
      n.last = e.date;
      if (n.po === "Ordered") {
        n.po = "Received";
      }
    }
  },
  stockRevert: 1
}, {
  id: "suppliers",
  n: "Suppliers",
  i: "🚚",
  g: "Stock",
  title: e => e.name,
  f: [F("name", "Supplier", "text", {
    req: 1
  }), F("phone", "Phone", "tel"), F("items", "Items supplied"), F("rates", "Rates", "text"), F("last", "Last purchase", "date"), F("owe", "Payment due to supplier (₹)", "number", {
    m: 1
  }), F("due", "Pay by", "date")],
  cols: ["name", "phone", "items", "rates", "last", "owe", "due"],
  due: e => num(e.owe) > 0 && e.due && e.due <= today() ? "due" : ""
}, {
  id: "marketing",
  n: "Marketing Planner",
  i: "📣",
  g: "Grow",
  f: [F("name", "Campaign", "text", {
    req: 1
  }), F("audience", "Target audience"), F("start", "Start", "date"), F("end", "End", "date"), F("budget", "Budget (₹)", "number", {
    m: 1
  }), F("inq", "Inquiries", "number"), F("sales", "Sales result", "number", {
    m: 1
  }), F("status", "Status", "select", {
    opts: ["Planned", "Running", "Finished"]
  })],
  cols: ["name", "audience", "start", "end", "budget", "inq", "sales", "status"]
}, {
  id: "content",
  n: "Content Calendar",
  i: "🗓️",
  g: "Grow",
  f: [F("date", "Date", "date", {
    req: 1
  }), F("platform", "Platform", "select", {
    opts: ["Instagram", "Facebook", "WhatsApp", "YouTube", "Other"]
  }), F("kind", "Type", "select", {
    opts: ["Post", "Reel", "Story", "Offer"]
  }), F("content", "Content", "textarea", {
    span: 2
  }), F("status", "Approval", "select", {
    opts: ["Draft", "Approved", "Posted"]
  })],
  cols: ["date", "platform", "kind", "content", "status"],
  sortBy: "date",
  asc: 1
}, {
  id: "staff",
  n: "Staff Management",
  i: "🧑‍💼",
  g: "Operate",
  title: e => e.name,
  f: [F("name", "Name", "text", {
    req: 1
  }), F("role", "Role"), F("phone", "Phone", "tel"), F("work", "Work allocation", "text", {
    span: 2
  }), F("shift", "Shift"), F("salary", "Salary (₹)", "number", {
    m: 1
  }), F("present", "Days present (this month)", "number"), F("leave", "Leave days", "number")],
  cols: ["name", "role", "work", "shift", "present", "leave", "salary"]
}, {
  id: "jobs",
  n: "Projects / Job Orders",
  i: "🛠️",
  g: "Operate",
  f: [F("client", "Client", "text", {
    req: 1,
    list: "customers"
  }), F("job", "Job / work"), F("stage", "Stage", "select", {
    opts: ["Enquiry", "Started", "In progress", "Ready", "Delivered"]
  }), F("materials", "Materials", "text"), F("cost", "Cost", "number", {
    m: 1
  }), F("value", "Job value", "number", {
    m: 1
  }), F("delivery", "Delivery date", "date"), F("status", "Completion", "select", {
    opts: ["Open", "Completed", "Cancelled"]
  })],
  cols: ["client", "job", "stage", "delivery", "cost", "value", "status"],
  due: e => e.status === "Open" && e.delivery && e.delivery < today() ? "due" : e.status === "Open" && e.delivery === today() ? "soon" : ""
}, {
  id: "appts",
  n: "Appointments",
  i: "📅",
  g: "Operate",
  f: [F("title", "Title", "text", {
    req: 1
  }), F("customer", "Customer", "text", {
    list: "customers"
  }), F("date", "Date", "date", {
    req: 1
  }), F("time", "Time", "time"), F("kind", "Type", "select", {
    opts: ["Meeting", "Service booking", "Site visit"]
  }), F("status", "Status", "select", {
    opts: ["Booked", "Done", "Cancelled"]
  })],
  cols: ["title", "customer", "date", "time", "kind", "status"],
  sortBy: "date",
  asc: 1,
  due: e => e.status === "Booked" && e.date === today() ? "soon" : ""
}, {
  id: "support",
  n: "Customer Support",
  i: "🎧",
  g: "Operate",
  f: [F("customer", "Customer", "text", {
    req: 1,
    list: "customers"
  }), F("kind", "Type", "select", {
    opts: ["Complaint", "Service request", "Warranty"]
  }), F("date", "Date", "date", {
    def: "today"
  }), F("details", "Details", "textarea", {
    span: 2
  }), F("warranty", "Warranty till", "date"), F("status", "Status", "select", {
    opts: ["Open", "In progress", "Resolved"]
  })],
  cols: ["customer", "kind", "date", "details", "warranty", "status"],
  due: e => e.status !== "Resolved" ? "soon" : ""
}, {
  id: "docs",
  n: "Documents",
  i: "📁",
  g: "Operate",
  f: [F("name", "Document", "text", {
    req: 1
  }), F("kind", "Type", "select", {
    opts: ["Agreement", "Bill", "Receipt", "Licence", "Insurance", "Other"]
  }), F("party", "Party"), F("date", "Date", "date"), F("renew", "Renewal date", "date"), F("link", "Where kept / link", "text", {
    span: 2
  })],
  cols: ["name", "kind", "party", "date", "renew", "link"],
  due: e => e.renew && e.renew < today() ? "due" : e.renew && e.renew <= addDays(today(), 15) ? "soon" : ""
}, {
  id: "reports",
  n: "Reports & Analysis",
  i: "📊",
  basic: 1,
  g: "Grow",
  custom: "reports"
}, {
  id: "growth",
  n: "Growth Planning",
  i: "🚀",
  g: "Grow",
  f: [...PLAN_FIELDS.slice(0, 6), F("invest", "New investment (₹)", "number", {
    m: 1
  }), F("xcost", "Expected cost", "number", {
    m: 1
  }), F("xinc", "Expected income", "number", {
    m: 1
  }), ...PLAN_FIELDS.slice(6)],
  cols: ["name", "goal", "invest", "xcost", "xinc", {
    l: "Expected gain",
    f: e => num(e.xinc) - num(e.xcost) - num(e.invest),
    num: 1,
    m: 1
  }, "deadline", "status"]
}, {
  id: "settings",
  n: "Business Profile",
  i: "⚙️",
  basic: 1,
  g: "System",
  custom: "settings"
}, {
  id: "backup",
  n: "Backup",
  i: "💾",
  basic: 1,
  g: "System",
  custom: "backup"
}];
const modById = Object.fromEntries(MODS.map(e => [e.id, e]));
const DATEKEY = {
  sales: "date",
  ledger: "date",
  purchases: "date",
  quotes: "date",
  support: "date",
  appts: "date",
  content: "date",
  docs: "date",
  cashflow: "date",
  closings: "date",
  tasks: "due",
  payments: "due",
  jobs: "delivery",
  plans: "start",
  growth: "start",
  marketing: "start",
  goals: "start",
  attendance: "month",
  budget: "month"
};
let afterRender = () => {};
let isLocked = () => false;
const CUSTOM = {};
const state = {
  db: {},
  settings: {
    mode: "basic"
  },
  mod: "dashboard",
  q: "",
  gq: "",
  filter: ""
};
const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
async function load() {
  let a;
  if (hasChrome) {
    a = await chrome.storage.local.get(["db", "settings"]);
  } else {
    try {
      a = JSON.parse(localStorage.getItem("bp") || "{}");
    } catch {
      a = {};
    }
  }
  state.db = a.db || {};
  state.settings = {
    ...state.settings,
    ...(a.settings || {})
  };
}
async function persist() {
  const a = {
    db: state.db,
    settings: state.settings
  };
  if (hasChrome) {
    await chrome.storage.local.set(a);
  } else {
    localStorage.setItem("bp", JSON.stringify(a));
  }
  render();
}
const rows = e => state.db[e] ||= [];
const salesNet = e => (e.kind === "Return" ? -1 : 1) * num(e.total ?? num(e.qty) * num(e.rate) - num(e.discount));
const salesOf = e => rows("sales").filter(a => (a.customer || "").trim().toLowerCase() === (e || "").trim().toLowerCase());
const inRange = (e, a, n) => e && (!a || e >= a) && (!n || e <= n);
const isPaidSale = e => e.pay === "Paid";
const moneyIn = (e, a) => sum(rows("sales"), n => sum((n.pays || []).filter(n => inRange(n.date, e, a)), e => e.amt) * (n.kind === "Return" ? -1 : 1)) + sum(rows("ledger").filter(n => n.type === "Income" && inRange(n.date, e, a)), e => e.amount);
const moneyOut = (e, a) => sum(rows("ledger").filter(n => n.type === "Expense" && inRange(n.date, e, a)), e => e.amount);
function goalActual(e) {
  const n = e.start;
  const s = e.end;
  if (e.type === "Sales") {
    return sum(rows("sales").filter(e => inRange(e.date, n, s)), salesNet);
  } else if (e.type === "Profit") {
    return moneyIn(n, s) - moneyOut(n, s);
  } else {
    return 0;
  }
}
const goalActualFix = e => e.type === "New customers" ? rows("customers").filter(a => inRange(a.created, e.start, e.end)).length : goalActual(e);
MODS.find(e => e.id === "goals").cols[6].f = e => goalActualFix(e);
MODS.find(e => e.id === "goals").cols[7].f = e => bar(goalActualFix(e), e.target);
const budgetActual = e => sum(rows("ledger").filter(a => a.type === "Expense" && (a.cat || "").toLowerCase() === (e.cat || "").toLowerCase() && (a.date || "").slice(0, 7) === e.month), e => e.amount);
const unpaid = e => e.kind !== "Return" && (e.pay ?? e.status) !== "Paid";
const totalOf = e => "total" in e ? num(e.total) : num(e.amount);
const balance = e => e.kind === "Return" ? 0 : Math.max(0, totalOf(e) - num(e.rcv));
function settle(e, a, n) {
  e.pays = e.pays || [];
  if (e.kind === "Return") {
    e[a] = "Paid";
    e.rcv = n;
    e.pays = [{
      date: e.date || today(),
      amt: n
    }];
    return;
  }
  let t = e[a] === "Paid" ? n : num(e.rcv);
  const p = t - sum(e.pays, e => e.amt);
  if (p) {
    e.pays.push({
      date: today(),
      amt: p
    });
  }
  e.rcv = t;
  e[a] = t >= n && n > 0 ? "Paid" : t > 0 ? "Partial" : "Pending";
}
const stockFind = e => rows("stock").find(a => (a.item || "").trim().toLowerCase() === (e || "").trim().toLowerCase() && e);
function unstock(e) {
  if (e.stk) {
    const n = stockFind(e.stk.item);
    if (n) {
      n.bal = num(n.bal) - e.stk.delta;
    }
    e.stk = null;
  }
}
function restock(e, a, n) {
  unstock(e);
  const t = stockFind(e[a]);
  if (t && n) {
    t.bal = num(t.bal) + n;
    e.stk = {
      item: t.item,
      delta: n
    };
    if (num(t.min) > 0 && num(t.bal) <= num(t.min)) {
      setTimeout(() => toast("⚠ Low stock: " + t.item + " — " + t.bal + " left", true), 400);
    }
  }
}
function migrate() {
  rows("sales").forEach(a => {
    if (!a.pays) {
      a.pays = a.pay === "Paid" && a.kind !== "Return" ? [{
        date: a.paidOn || a.date || today(),
        amt: num(a.total)
      }] : [];
      a.rcv = sum(a.pays, e => e.amt);
    }
  });
  rows("payments").forEach(a => {
    if (!a.pays) {
      a.pays = a.status === "Paid" ? [{
        date: a.paidOn || today(),
        amt: num(a.amount)
      }] : [];
      a.rcv = sum(a.pays, e => e.amt);
    }
  });
}
const biz = () => state.settings.biz || {};
const phoneFor = e => (rows("customers").concat(rows("suppliers")).find(a => (a.name || "").trim().toLowerCase() === (e || "").trim().toLowerCase() && a.phone) || {}).phone || "";
const waTpl = () => {
  const e = biz().waTpl;
  if (e && e !== OLD_WA) {
    return e;
  } else {
    return DEFAULT_WA;
  }
};
const waFull = e => {
  let n = String(e || "").replace(/\D/g, "").replace(/^0+/, "");
  if (n && n.length <= 10) {
    n = (biz().cc || "91") + n;
  }
  return n;
};
const waFill = (e, a) => e.replace(/\{name\}/g, a.customer || a.party || "").replace(/\{amount\}/g, money(balance(a))).replace(/\{date\}/g, a.due ? fmtDate(a.due) : "as agreed").replace(/\{business\}/g, biz().name || "our business").replace(/\{billref\}/g, a.no ? " (Invoice " + a.no + ")" : "").replace(/\{bill\}/g, a.no || "");
let waCtx = null;
const waInvText = e => "Dear " + (e.customer || "") + ",\n\nPlease find attached " + (e.kind === "Return" ? "credit note" : "invoice") + " " + (e.no || "") + " dated " + fmtDate(e.date) + " for " + money(e.total) + "." + (balance(e) > 0 ? "\nBalance due: " + money(balance(e)) + (e.due ? " (by " + fmtDate(e.due) + ")" : "") : "") + "\n\nThank you for your business.\n\nBest regards,\n" + (biz().name || "");
function sendWhatsApp(e, a, n) {
  if (!a) {
    return;
  }
  waCtx = {
    m: e,
    r: a
  };
  const t = a.customer || a.party || "";
  const p = !!n && !!n.pdf;
  $("#waName").textContent = t || "—";
  $("#waPhone").value = a.phone || phoneFor(t) || "";
  $("#waText").value = p ? waInvText(a) : waFill(waTpl(), a);
  $("#waPdfRow").hidden = e.id !== "sales";
  $("#waPdf").checked = p;
  $("#waErr").textContent = "";
  $("#waDlg").showModal();
  localize();
  setTimeout(() => $("#waPhone").focus(), 30);
}
$("#waCancel").addEventListener("click", () => $("#waDlg").close());
$("#waForm").addEventListener("submit", async e => {
  e.preventDefault();
  const {
    r: n
  } = waCtx || {};
  if (!n) {
    return;
  }
  const s = waFull($("#waPhone").value);
  if (!/^[1-9]\d{7,14}$/.test(s)) {
    $("#waErr").textContent = t("Enter a valid phone number (with country code, or 10 digits)");
    return;
  }
  if (n.phone !== s) {
    n.phone = s;
    await persist();
  }
  let p = false;
  if (!$("#waPdfRow").hidden && $("#waPdf").checked) {
    const e = $("#waForm button.primary");
    e.disabled = true;
    $("#waErr").textContent = "";
    try {
      const {
        inner: e
      } = docParts("invoice", n);
      const s = await PdfShare.htmlToPdf(DOC_CSS(), e);
      const t = await PdfShare.blobToBase64(s);
      const _ = (n.kind === "Return" ? "CreditNote-" : "Invoice-") + (String(n.no || "bill").replace(/[^\w.-]+/g, "_") || "bill") + ".pdf";
      await chrome.storage.local.set({
        waFile: {
          name: _,
          mime: "application/pdf",
          b64: t,
          t: Date.now()
        }
      });
      p = true;
    } catch (n) {
      e.disabled = false;
      $("#waErr").textContent = t("Could not create the PDF") + ": " + (n && n.message || n);
      return;
    }
    e.disabled = false;
  }
  try {
    await chrome.runtime.sendMessage({
      type: "wa-open",
      phone: s,
      text: $("#waText").value,
      file: p,
      mode: ((await chrome.storage.local.get("hubSettings")).hubSettings || {}).waMode || "window",
      screen: {
        w: screen.availWidth,
        h: screen.availHeight
      }
    });
  } catch {
    return toast("Could not open WhatsApp — please try again", true);
  }
  $("#waDlg").close();
});
const OLD_WA = "Namaskaram {name}, {business}-il ninnu. ₹{amount} baaki und. Avasana date: {date}. Dayavayi adakkane. Nanni.";
const DEFAULT_WA = "Dear {name},\n\nThis is a gentle reminder from {business} regarding the outstanding balance of {amount}{billref}.\nDue date: {date}\n\nKindly arrange the payment at your earliest convenience. If you have already paid, please disregard this message.\n\nThank you for your business.\n\nBest regards,\n{business}";
const shiftMonth = (e, a) => {
  const [s, t] = e.split("-").map(Number);
  const p = new Date(s, t - 1 + a, 1);
  return p.getFullYear() + "-" + pad(p.getMonth() + 1);
};
function gstCalc(e, a) {
  const s = num(e.gst);
  a = Math.max(0, a);
  if (!s) {
    e.taxable = a;
    e.gstAmt = 0;
    e.total = a;
    return;
  }
  if (biz().gstIncl === "yes") {
    e.total = a;
    e.gstAmt = Math.round((a - a / (1 + s / 100)) * 100) / 100;
    e.taxable = a - e.gstAmt;
  } else {
    e.taxable = a;
    e.gstAmt = Math.round(a * s) / 100;
    e.total = a + e.gstAmt;
  }
}
function runRecurring() {
  const a = today();
  const n = a.slice(0, 7);
  let s = 0;
  rows("recurring").filter(a => a.active !== "No").forEach(t => {
    let _ = t.last ? shiftMonth(t.last, 1) : (t.start || a).slice(0, 7);
    const b = Math.min(28, Math.max(1, num(t.day) || 1));
    while (_ <= n && (!t.end || _ + "-01" <= t.end)) {
      const e = _ + "-" + pad(b);
      if (t.kind !== "To pay" && e > a) {
        break;
      }
      if (t.start && e < t.start) {
        t.last = _;
        _ = shiftMonth(_, 1);
      } else {
        if (t.kind === "To pay") {
          rows("payments").push({
            id: uid(),
            created: a,
            dir: "To pay",
            party: t.title,
            amount: t.amount,
            rcv: 0,
            pays: [],
            due: e,
            inst: "Repeating",
            status: "Pending"
          });
        } else {
          rows("ledger").push({
            id: uid(),
            created: a,
            date: e,
            type: t.kind,
            cat: t.cat || t.title,
            amount: t.amount,
            note: "Repeating: " + t.title
          });
        }
        t.last = _;
        _ = shiftMonth(_, 1);
        s++;
      }
    }
  });
  return s;
}
const csvCell = e => {
  e = String(e ?? "");
  if (/[",\r\n]/.test(e)) {
    return "\"" + e.replace(/"/g, "\"\"") + "\"";
  } else {
    return e;
  }
};
const CSV_EXTRA = {
  sales: [["Taxable", e => e.taxable ?? e.total], ["GST amount", e => e.gstAmt || 0], ["Total", e => e.total], ["Received", e => e.rcv || 0], ["Balance", e => balance(e)]],
  purchases: [["GST amount", e => e.gstAmt || 0], ["Total", e => e.total]],
  payments: [["Balance", e => balance(e)]]
};
function csvOf(e) {
  const n = CSV_EXTRA[e.id] || [];
  const s = [[...e.f.map(e => e.l), ...n.map(e => e[0])]];
  rows(e.id).forEach(t => s.push([...e.f.map(e => t[e.k]), ...n.map(e => e[1](t))]));
  return "﻿" + s.map(e => e.map(csvCell).join(",")).join("\r\n");
}
const exportable = () => MODS.filter(e => e.f);
function exportCsv(e) {
  if (!rows(e.id).length) {
    return toast("Nothing to export yet", true);
  }
  download(e.id + ".csv", csvOf(e), "text/csv");
}
function exportAll() {
  const a = exportable().filter(a => rows(a.id).length);
  if (!a.length) {
    return toast("Nothing to export yet", true);
  }
  a.forEach((e, a) => setTimeout(() => exportCsv(e), a * 400));
}
const lowStock = e => num(e.min) > 0 && num(e.bal) <= num(e.min) && e.po !== "Ordered";
const planDue = e => e.status !== "Completed" && e.deadline && e.deadline < today() ? "due" : "";
function payDue(e, a, n) {
  if (e[a] === n && e.due && e.due <= today()) {
    return "due";
  } else {
    return "";
  }
}
const dueLabel = e => {
  const n = daysBetween(today(), e.due);
  if (n === 0) {
    return "DUE TODAY";
  } else {
    return "OVERDUE " + n + " day" + (n > 1 ? "s" : "");
  }
};
function bar(e, a, n) {
  const t = num(a) ? Math.round(num(e) / num(a) * 100) : 0;
  return "<div style=\"display:flex;gap:8px;align-items:center\"><div class=\"bartrack\"><i class=\"" + (n ? t > 100 ? "r" : "" : t >= 100 ? "g" : "") + "\" style=\"width:" + Math.min(100, t) + "%\"></i></div><span class=\"sub\">" + t + "%</span></div>";
}
function alerts() {
  const a = [];
  rows("payments").filter(a => unpaid(a) && a.due && a.due <= today()).forEach(n => a.push({
    mod: "payments",
    r: n,
    name: n.party,
    amt: balance(n),
    tag: n.dir
  }));
  rows("sales").filter(a => unpaid(a) && a.due && a.due <= today()).forEach(n => a.push({
    mod: "sales",
    r: n,
    name: n.customer || n.no,
    amt: balance(n),
    tag: "Invoice " + (n.no || "")
  }));
  return a.sort((a, n) => a.r.due.localeCompare(n.r.due));
}
const GOOD = ["Paid", "Won", "Done", "Approved", "Completed", "Resolved", "Delivered", "Posted", "Received", "Finished", "Incoming", "Income", "To receive"];
const BAD = ["Lost", "Rejected", "Cancelled", "Outgoing", "Expense", "High", "To pay", "Return"];
const WARN = ["Partial", "Pending", "Ordered", "Open", "Sent", "In progress", "Running", "Medium", "Booked", "Quotation sent", "On hold"];
const chip = e => e ? "<span class=\"chip " + (GOOD.includes(e) ? "good" : BAD.includes(e) ? "bad" : WARN.includes(e) ? "warn" : "info") + "\">" + esc(e) + "</span>" : "—";
function cell(e, a, n) {
  if (typeof n === "object") {
    const e = n.f(a);
    if (n.html) {
      return e;
    } else if (n.m) {
      return money(e);
    } else {
      return esc(e);
    }
  }
  const t = e.f.find(e => e.k === n);
  const p = a[n];
  if (t.t === "select") {
    return chip(p);
  } else if (t.t === "date") {
    if ((n === "due" || n === "deadline") && a[n] && payOrPlanLate(a)) {
      return "<b style=\"color:var(--red)\">" + fmtDate(p) + "</b>";
    } else {
      return fmtDate(p);
    }
  } else if (t.m) {
    return money(p);
  } else {
    return esc(p);
  }
}
const payOrPlanLate = e => e.due && e.due < today() && (e.status === "Pending" || e.pay === "Pending") || e.deadline && e.deadline < today() && e.status !== "Completed";
const isNumCol = (e, a) => typeof a === "object" ? a.num : (e.f.find(e => e.k === a) || {}).t === "number";
const colLabel = (e, a) => typeof a === "object" ? a.l : e.f.find(e => e.k === a).l;
const rowTitle = (e, a) => a[e.f[0].k] || "(untitled)";
function tableFor(e, a) {
  if (!a.length) {
    return "<p class=\"empty\">Nothing here yet. Click “+ Add” to create the first entry.</p>";
  }
  const s = a => e.due ? {
    due: 0,
    soon: 1
  }[e.due(a)] ?? 2 : 2;
  const t = [...a].sort((a, t) => s(a) - s(t) || (e.sortDue ? (a.due || "9").localeCompare(t.due || "9") : 0));
  return "<div class=\"tablewrap\"><table><thead><tr>" + e.cols.map(a => "<th class=\"" + (isNumCol(e, a) ? "num" : "") + "\">" + esc(colLabel(e, a)) + "</th>").join("") + "<th></th></tr></thead><tbody>\n  " + t.map(a => {
    const t = e.due ? e.due(a) : "";
    return "<tr data-id=\"" + a.id + "\" class=\"" + t + "\">" + e.cols.map((n, p) => "<td class=\"" + (isNumCol(e, n) ? "num" : "") + "\">" + cell(e, a, n) + (p !== 0 || t !== "due" || e.id !== "payments" && e.id !== "sales" || !a.due ? p === 0 && t === "due" && e.id === "stock" ? "<span class=\"dueTag\">LOW STOCK</span>" : "" : "<span class=\"dueTag\">⚠ " + dueLabel(a) + "</span>") + "</td>").join("") + "\n  <td class=\"acts\">" + (e.quick && a[e.quick.k] !== e.quick.v ? "<button data-act=\"quick\">" + e.quick.l + "</button>" : "") + (e.rowActs ? e.rowActs(a) : []).map(([e, a]) => "<button data-act=\"" + e + "\">" + a + "</button>").join("") + "<button data-act=\"edit\">Edit</button><button data-act=\"del\" class=\"danger\">✕</button></td></tr>";
  }).join("") + "\n  </tbody></table></div>";
}
function alertBox() {
  const a = alerts();
  if (a.length) {
    return "<div class=\"alertBox\"><div class=\"alertHead\">🔴 CASH RED ALERT — " + a.length + " payment" + (a.length > 1 ? "s" : "") + " past the last date · " + money(sum(a, a => a.amt)) + "</div>\n  " + a.map(a => "<div class=\"alertRow\" data-mod=\"" + a.mod + "\" data-id=\"" + a.r.id + "\"><b>" + esc(a.name) + "</b><span>" + esc(a.tag) + "</span><span>" + money(a.amt) + "</span><span>Last date " + fmtDate(a.r.due) + "</span><span class=\"dueTag\">" + dueLabel(a.r) + "</span><button data-act=\"wa\">WhatsApp</button><button data-act=\"openAlert\">Open</button></div>").join("") + "</div>";
  } else {
    return "";
  }
}
const card = (e, a, n = "") => "<div class=\"card " + n + "\"><div class=\"k\">" + e + "</div><div class=\"v\">" + a + "</div></div>";
const MODE_BASIC = () => state.settings.mode === "basic";
const visibleMods = () => MODS.filter(e => !MODE_BASIC() || e.basic);
function renderDashboard() {
  const a = today();
  const n = a.slice(0, 7);
  const s = !MODE_BASIC();
  const t = sum(rows("sales").filter(n => n.date === a), salesNet);
  const p = moneyIn(a, a);
  const _ = moneyOut(a, a);
  const b = sum(rows("sales").filter(unpaid), balance);
  const r = sum(rows("payments").filter(a => unpaid(a) && a.dir !== "To pay"), balance);
  const l = sum(rows("payments").filter(e => unpaid(e) && e.dir === "To pay"), balance);
  const o = rows("tasks").filter(n => n.status !== "Done" && n.due && n.due <= a);
  const i = rows("leads").filter(e => !["Won", "Lost"].includes(e.stage) && e.follow && e.follow <= a);
  const c = rows("appts").filter(n => n.status === "Booked" && n.date === a);
  const d = rows("plans").filter(a => a.status === "In progress");
  const u = rows("stock").filter(lowStock);
  const x = rows("docs").filter(n => n.renew && n.renew <= addDays(a, 15));
  const m = (a, n, s) => a.length ? "<div class=\"list\">" + a.slice(0, 8).map(a => "<div data-mod=\"" + s + "\" data-id=\"" + a.id + "\">" + n(a) + "<span class=\"grow\"></span><button data-act=\"openAlert\" style=\"padding:2px 10px\">Open</button></div>").join("") + "</div>" : "<p class=\"empty\">All clear ✓</p>";
  return "<div class=\"bar\"><h2>Dashboard</h2><span class=\"sub\">" + fmtDate(a) + "</span></div>" + alertBox() + (typeof dashExtras == "function" ? dashExtras() : "") + "\n  <div class=\"cards\">" + card("Today's sales", money(t)) + card("Money in today", money(p), "good") + card("Expense today", money(_), "bad") + "\n  " + card("This month profit", money(moneyIn(n + "-01", n + "-31") - moneyOut(n + "-01", n + "-31")), moneyIn(n + "-01", n + "-31") >= moneyOut(n + "-01", n + "-31") ? "good" : "bad") + "\n  " + card("Pending to receive", money(b + r), "warn") + card("Pending to pay", money(l), "warn") + "</div>\n  <div class=\"two\"><section><h3>Tasks due (" + o.length + ")</h3>" + m(o, a => "<b>" + esc(a.name) + "</b> <span class=\"sub\">" + esc(a.who) + "</span> " + chip(a.priority) + " <span class=\"sub\">" + fmtDate(a.due) + "</span>", "tasks") + "</section>\n  <section><h3>Follow-ups due (" + i.length + ")</h3>" + m(i, e => "<b>" + esc(e.name) + "</b> <span class=\"sub\">" + esc(e.phone) + "</span> " + chip(e.stage), "leads") + "</section>\n  <section><h3>Plans in progress (" + d.length + ")</h3>" + m(d, a => "<b>" + esc(a.name) + "</b> <span class=\"sub\">" + esc(a.person) + " · by " + fmtDate(a.deadline) + "</span>", "plans") + "</section>\n  " + (s ? "<section><h3>Today's appointments (" + c.length + ")</h3>" + m(c, e => "<b>" + esc(e.title) + "</b> <span class=\"sub\">" + esc(e.time) + " " + esc(e.customer) + "</span>", "appts") + "</section>\n  <section><h3>Low stock (" + u.length + ")</h3>" + m(u, a => "<b>" + esc(a.item) + "</b> <span class=\"sub\">balance " + esc(a.bal) + "</span> <span class=\"chip bad\">reorder " + esc(a.reorder || "") + "</span>", "stock") + "</section>\n  <section><h3>Renewals in 15 days (" + x.length + ")</h3>" + m(x, a => "<b>" + esc(a.name) + "</b> <span class=\"sub\">" + fmtDate(a.renew) + "</span>", "docs") + "</section>" : "") + "</div>\n  " + (MODE_BASIC() ? "<p class=\"sub\" style=\"margin-top:20px\">Need stock, suppliers, quotations, GST, marketing, staff and more? Switch to Advanced mode at the top.</p>" : "");
}
function renderCashflow(e) {
  const n = today();
  let s = moneyIn() - moneyOut();
  const t = [...[...rows("cashflow")].filter(e => e.date >= n).sort((e, n) => e.date.localeCompare(n.date)), ...rows("payments").filter(e => unpaid(e) && e.due && e.due >= n).map(e => ({
    date: e.due,
    dir: e.dir === "To pay" ? "Outgoing" : "Incoming",
    desc: e.party + " (payment)",
    amount: balance(e),
    auto: 1
  }))].sort((e, n) => e.date.localeCompare(n.date));
  const p = {};
  t.forEach(e => {
    const s = e.date.slice(0, 7);
    (p[s] = p[s] || {
      i: 0,
      o: 0
    })[e.dir === "Incoming" ? "i" : "o"] += num(e.amount);
  });
  let _ = s;
  let b = null;
  const r = Object.keys(p).sort().map(e => {
    _ += p[e].i - p[e].o;
    if (_ < 0 && !b) {
      b = e;
    }
    return "<tr><td>" + esc(e) + "</td><td class=\"num\">" + money(p[e].i) + "</td><td class=\"num\">" + money(p[e].o) + "</td><td class=\"num\"><b style=\"color:" + (_ < 0 ? "var(--red)" : "var(--green)") + "\">" + money(_) + "</b></td></tr>";
  }).join("");
  return "<div class=\"bar\"><h2>" + e.n + "</h2><span class=\"grow\"></span><button class=\"primary\" data-act=\"add\">+ Add expected item</button></div>\n  <div class=\"cards\">" + card("Cash in hand (money in − out so far)", money(s), s >= 0 ? "good" : "bad") + card("Expected incoming", money(sum(t.filter(e => e.dir === "Incoming"), e => e.amount)), "good") + card("Expected outgoing", money(sum(t.filter(e => e.dir === "Outgoing"), e => e.amount)), "bad") + "</div>\n  " + (b ? "<div class=\"alertBox\"><div class=\"alertHead\">🔴 Cash will run short in " + b + " — plan funds in advance</div></div>" : t.length ? "<p class=\"sub\">✓ Cash looks sufficient for all planned items.</p>" : "") + "\n  <section><h3>Month-wise forecast</h3>" + (r ? "<div class=\"tablewrap\"><table><thead><tr><th>Month</th><th class=\"num\">Incoming</th><th class=\"num\">Outgoing</th><th class=\"num\">Balance after</th></tr></thead><tbody>" + r + "</tbody></table></div>" : "<p class=\"empty\">Add expected incoming / outgoing items. Pending payments with last dates are included automatically.</p>") + "</section>\n  <section><h3>Planned items</h3>" + tableFor(e, applySearch(e, rows(e.id))) + "</section>";
}
function renderReports() {
  const a = {};
  rows("sales").forEach(e => {
    const n = (e.date || "").slice(0, 7);
    if (n) {
      a[n] = (a[n] || 0) + salesNet(e);
    }
  });
  const n = {};
  rows("ledger").filter(a => a.type === "Expense").forEach(a => {
    const t = a.cat || "Other";
    n[t] = (n[t] || 0) + num(a.amount);
  });
  const s = {};
  rows("sales").filter(a => a.kind !== "Return").forEach(a => {
    const t = a.item || "—";
    s[t] = (s[t] || 0) + num(a.qty) * 1;
  });
  const t = {};
  rows("sales").forEach(a => {
    const n = a.item || "—";
    t[n] = (t[n] || 0) + salesNet(a);
  });
  const p = (a, n, s) => {
    return (t = a, Object.entries(t).sort((e, a) => a[1] - e[1])).slice(0, 10).map(([t, p]) => {
      return "<div><b style=\"min-width:130px\">" + esc(t) + "</b><div class=\"bartrack\"><i class=\"" + (s || "") + "\" style=\"width:" + Math.round(p / (_ = a, Math.max(1, ...Object.values(_))) * 100) + "%\"></i></div><span>" + n(p) + "</span></div>";
      var _;
    }).join("") || "<div class=\"sub\">No data yet</div>";
    var t;
  };
  const _ = [...new Set([...Object.keys(a), ...rows("ledger").map(a => (a.date || "").slice(0, 7))])].filter(Boolean).sort().reverse().slice(0, 12);
  const b = rows("goals");
  return "<div class=\"bar\"><h2>Reports & Analysis</h2></div>\n  <div class=\"cards\">" + card("Total sales", money(sum(rows("sales"), salesNet))) + card("Total money in", money(moneyIn()), "good") + card("Total expenses", money(moneyOut()), "bad") + card("Net profit", money(moneyIn() - moneyOut()), moneyIn() >= moneyOut() ? "good" : "bad") + "</div>\n  <section><h3>Month-wise sales, money in, expenses & profit</h3>" + (_.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Month</th><th class=\"num\">Sales</th><th class=\"num\">Money in</th><th class=\"num\">Expenses</th><th class=\"num\">Profit</th></tr></thead><tbody>" + _.map(n => {
    const t = moneyIn(n + "-01", n + "-31");
    const p = moneyOut(n + "-01", n + "-31");
    return "<tr><td>" + n + "</td><td class=\"num\">" + money(a[n] || 0) + "</td><td class=\"num\">" + money(t) + "</td><td class=\"num\">" + money(p) + "</td><td class=\"num\"><b style=\"color:" + (t >= p ? "var(--green)" : "var(--red)") + "\">" + money(t - p) + "</b></td></tr>";
  }).join("") + "</tbody></table></div>" : "<p class=\"empty\">No data yet.</p>") + "</section>\n  <div class=\"two\"><section><h3>Expenses by category</h3><div class=\"list\">" + p(n, money, "r") + "</div></section>\n  <section><h3>Best-selling (by value)</h3><div class=\"list\">" + p(t, money, "g") + "</div></section></div>\n  <section><h3>Target vs actual</h3>" + (b.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Goal</th><th>Period</th><th class=\"num\">Target</th><th class=\"num\">Actual</th><th>Progress</th></tr></thead><tbody>" + b.map(a => "<tr><td>" + esc(a.name) + "</td><td>" + fmtDate(a.start) + " → " + fmtDate(a.end) + "</td><td class=\"num\">" + esc(a.target) + "</td><td class=\"num\">" + goalActualFix(a) + "</td><td>" + bar(goalActualFix(a), a.target) + "</td></tr>").join("") + "</tbody></table></div>" : "<p class=\"empty\">" + (MODE_BASIC() ? "Goals are in Advanced mode." : "Add goals under “Goals & Targets”.") + "</p>") + "</section>";
}
function gstRows(e) {
  return {
    sg: rows("sales").filter(n => (n.date || "").slice(0, 7) === e && num(n.gstAmt)),
    pu: rows("purchases").filter(a => (a.date || "").slice(0, 7) === e && num(a.gstAmt))
  };
}
function renderGst() {
  const a = state.gstMonth ||= today().slice(0, 7);
  const {
    sg: n,
    pu: s
  } = gstRows(a);
  const t = a => a.kind === "Return" ? -1 : 1;
  const p = sum(n, e => e.gstAmt * t(e));
  const _ = sum(s, a => a.gstAmt);
  const b = sum(n, e => e.taxable * t(e));
  const r = biz().gstType === "igst" ? [["IGST", 1]] : [["CGST", 0.5], ["SGST", 0.5]];
  return "<div class=\"bar\"><h2>🧮 GST Report</h2><input type=\"month\" id=\"gstMonth\" value=\"" + a + "\"><span class=\"grow\"></span><button data-act=\"exportGst\">⬇ CSV</button><button class=\"primary\" data-act=\"exportGstr1\">⬇ GSTR-1 Excel</button><button data-act=\"exportGstr1Csv\">⬇ GSTR-1 CSV</button></div>\n  <div class=\"cards\">" + card("Taxable sales", money(b)) + card("GST collected (sales)", money(p), "warn") + card("GST paid (purchases)", money(_), "good") + card("GST payable (collected − paid)", money(p - _), p - _ > 0 ? "bad" : "good") + "</div>\n  <section><h3>Sales invoices with GST</h3>" + (n.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>GST number</th><th class=\"num\">GST %</th><th class=\"num\">Taxable</th>" + r.map(e => "<th class=\"num\">" + e[0] + "</th>").join("") + "<th class=\"num\">Total</th></tr></thead><tbody>\n  " + n.map(a => {
    const s = rows("customers").find(e => (e.name || "").toLowerCase() === (a.customer || "").toLowerCase()) || {};
    return "<tr><td>" + esc(a.no) + "</td><td>" + fmtDate(a.date) + "</td><td>" + esc(a.customer) + "</td><td>" + esc(s.gstin) + "</td><td class=\"num\">" + esc(a.gst) + "%</td><td class=\"num\">" + money(a.taxable * t(a)) + "</td>" + r.map(e => "<td class=\"num\">" + money(a.gstAmt * e[1] * t(a)) + "</td>").join("") + "<td class=\"num\">" + money(a.total * t(a)) + "</td></tr>";
  }).join("") + "</tbody></table></div>" : "<p class=\"empty\">No GST invoices in this month. Set the GST % when you create a bill.</p>") + "</section>\n  <section><h3>Purchases with GST</h3>" + (s.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Date</th><th>Supplier</th><th>Item</th><th class=\"num\">GST %</th><th class=\"num\">GST amount</th><th class=\"num\">Total</th></tr></thead><tbody>" + s.map(a => "<tr><td>" + fmtDate(a.date) + "</td><td>" + esc(a.supplier) + "</td><td>" + esc(a.item) + "</td><td class=\"num\">" + esc(a.gst) + "%</td><td class=\"num\">" + money(a.gstAmt) + "</td><td class=\"num\">" + money(a.total) + "</td></tr>").join("") + "</tbody></table></div>" : "<p class=\"empty\">No purchases with GST in this month.</p>") + "</section>";
}
function exportGst() {
  const a = state.gstMonth || today().slice(0, 7);
  const {
    sg: n,
    pu: s
  } = gstRows(a);
  const t = [["Type", "Number", "Date", "Party", "GST %", "Taxable", "GST", "Total"]];
  n.forEach(a => t.push(["Sale", a.no, a.date, a.customer, a.gst, a.taxable * (a.kind === "Return" ? -1 : 1), a.gstAmt * (a.kind === "Return" ? -1 : 1), a.total * (a.kind === "Return" ? -1 : 1)]));
  s.forEach(a => t.push(["Purchase", "", a.date, a.supplier, a.gst, a.taxable, a.gstAmt, a.total]));
  download("gst-" + a + ".csv", "﻿" + t.map(a => a.map(csvCell).join(",")).join("\r\n"), "text/csv");
}
function renderBackup() {
  return "<div class=\"bar\"><h2>Backup</h2></div><div class=\"panel\"><h3>Save a backup file</h3><p>" + Object.values(state.db).reduce((e, a) => e + a.length, 0) + " records saved in this browser. Download a backup regularly.</p>\n  <button class=\"primary\" data-act=\"export\">Download backup (.json)</button></div>\n  <div class=\"panel\"><h3>Export to Excel (CSV)</h3><p>Open these files in Excel — handy for your accountant.</p><div class=\"row\" style=\"display:flex;gap:8px;flex-wrap:wrap\"><button class=\"primary\" data-act=\"exportAll\">Download everything</button>" + exportable().map(e => "<button data-act=\"exportOne\" data-m=\"" + e.id + "\">" + e.i + " " + e.n + "</button>").join("") + "</div></div>\n  " + (typeof backupExtras == "function" ? backupExtras() : "") + "\n  " + (typeof restorePanel === "function" ? restorePanel() : "");
}
async function exportGstr1(e) {
  const n = state.gstMonth || today().slice(0, 7);
  const s = Gstr1.build(n, {
    sales: rows("sales"),
    purchases: rows("purchases"),
    customers: rows("customers"),
    biz: biz()
  });
  if (!s.counts.invoices && !s.counts.credits) {
    return toast("No sales invoices in this month", true);
  }
  try {
    const t = e === "csv" ? await Gstr1.toCsvZip(s) : await Gstr1.toXlsx(s);
    download("GSTR1-" + n + (e === "csv" ? "-csv.zip" : ".xlsx"), t, e === "csv" ? "application/zip" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    toast(s.warnings.length ? "Exported — " + s.warnings.length + " point(s) to check, see the Summary sheet" : "GSTR-1 file downloaded ✓", !!s.warnings.length);
  } catch (e) {
    toast("Export failed: " + (e && e.message || e), true);
  }
}
const BIZ_FIELDS = [["name", "Business name"], ["currency", "Currency", "sel", BusinessCurrency.options], ["phone", "Phone"], ["address", "Address", "area"], ["gst", "GST number"], ["gstRate", "Default GST % on bills"], ["gstIncl", "Price includes GST?", "sel", [["no", "No – GST is added on top"], ["yes", "Yes – GST is already in the price"]]], ["gstType", "GST type on bills", "sel", [["cgst", "CGST + SGST (same state)"], ["igst", "IGST (other state)"]]], ["bank", "Bank name"], ["acc", "Account number"], ["ifsc", "IFSC"], ["upi", "UPI ID"], ["prefix", "Invoice prefix (e.g. INV-)"], ["cc", "Country code for WhatsApp (91 = India)"], ["color", "Bill colour (accent)", "color"], ["notify", "Browser notifications for due payments", "sel", [["on", "On"], ["off", "Off"]]], ["terms", "Terms / footer note on bills", "area"], ["waTpl", "WhatsApp reminder message", "area"]];
function renderSettings() {
  const a = biz();
  return "<div class=\"bar\"><h2>⚙️ Business Profile</h2></div><p class=\"sub\">This appears on printed invoices and quotations, and in WhatsApp reminders.</p>\n  <div class=\"panel\"><div class=\"grid\">" + BIZ_FIELDS.map(([n, s, t, p]) => "<label class=\"" + (t === "area" ? "span2" : "") + "\">" + s + (t === "area" ? "<textarea data-nolang data-biz=\"" + n + "\" rows=\"" + (n === "waTpl" ? 9 : 2) + "\">" + esc(n === "waTpl" ? waTpl() : a[n] ?? "") + "</textarea>" : t === "color" ? "<input type=\"color\" data-biz=\"" + n + "\" value=\"" + esc(a[n] || "#2563eb") + "\" style=\"height:38px;padding:3px\">" : t === "sel" ? "<select data-biz=\"" + n + "\">" + p.map(([s, t]) => "<option value=\"" + s + "\" " + ((a[n] || p[0][0]) === s ? "selected" : "") + ">" + t + "</option>").join("") + "</select>" : "<input data-biz=\"" + n + "\" value=\"" + esc(a[n] ?? (n === "cc" ? "91" : "")) + "\">") + "</label>").join("") + "\n  <label class=\"span2\">Logo " + (a.logo ? "<img src=\"" + a.logo + "\" style=\"max-height:70px;max-width:240px;object-fit:contain;align-self:flex-start\"><span><button data-act=\"rmLogo\" type=\"button\">Remove logo</button></span>" : "") + "<input type=\"file\" id=\"logoFile\" accept=\"image/*\"></label></div>\n  <p class=\"sub\" style=\"margin-top:10px\">Changing currency updates how amounts are displayed; it does not convert saved values.</p><p class=\"sub\" style=\"margin-top:10px\">WhatsApp message words: {name} {amount} {date} {business} {bill} {billref}</p></div>" + (typeof settingsExtras === "function" ? settingsExtras() : "");
}
const DOC_CSS = () => {
  const a = biz().color || "#2563eb";
  return ":root{--ac:" + a + "}" + DOC_CSS0;
};
const DOC_CSS0 = "\n  body{-webkit-print-color-adjust:exact;print-color-adjust:exact;font:14px/1.5 system-ui,\"Noto Sans Malayalam\",sans-serif;color:#111;margin:0;padding:28px 36px;max-width:820px;margin:auto}\n  .hd{display:flex;justify-content:space-between;gap:20px;border-bottom:4px solid var(--ac);padding-bottom:14px}.hd img{max-height:80px;max-width:200px;object-fit:contain}\n  h1{margin:0;font-size:22px;color:var(--ac)}.t{font-size:28px;font-weight:800;letter-spacing:.1em;text-align:right;color:var(--ac)}.muted{color:#555}.meta{display:flex;justify-content:space-between;margin:18px 0}\n  table{width:100%;border-collapse:collapse;margin-top:6px}th,td{border-bottom:1px solid #ccc;padding:8px;text-align:left;vertical-align:top}th{background:var(--ac);color:#fff;font-size:12px;text-transform:uppercase;letter-spacing:.04em}.n{text-align:right}\n  .sum{margin-left:auto;width:280px;margin-top:12px}.sum div{display:flex;justify-content:space-between;padding:4px 8px}.sum .g{font-weight:800;font-size:17px;border-top:2px solid var(--ac);color:var(--ac)}\n  .stamp{display:inline-block;border:3px solid #16a34a;color:#16a34a;font-weight:800;padding:2px 14px;transform:rotate(-6deg);margin-top:8px}\n  .bank{margin-top:22px;padding:10px 14px;border:1px solid #ccc;border-radius:6px;font-size:13px}.foot{margin-top:26px;color:#555;font-size:12.5px;white-space:pre-line}\n  #pbtn{position:fixed;top:10px;right:10px;padding:8px 16px;font:inherit;cursor:pointer}@media print{#pbtn{display:none}body{padding:0}}";
function openHtml(e) {
  const n = window.open(URL.createObjectURL(new Blob([e], {
    type: "text/html"
  })), "_blank");
  if (!n) {
    return toast("Allow pop-ups to print", true);
  }
  n.addEventListener("load", () => {
    n.document.getElementById("pbtn").onclick = () => n.print();
    setTimeout(() => n.print(), 400);
  });
}
function docParts(e, a) {
  const s = biz();
  const p = e === "quote";
  const _ = a.kind === "Return";
  const b = rows("customers").find(e => (e.name || "").trim().toLowerCase() === (a.customer || "").trim().toLowerCase()) || {};
  const r = t(p ? "QUOTATION" : _ ? "CREDIT NOTE" : "INVOICE");
  const l = p ? "<tr><td>" + esc(a.items || "").replace(/\n/g, "<br>") + "</td><td class=\"n\">" + money(a.amount) + "</td></tr>" : "<tr><td>" + esc(a.item) + "</td><td class=\"n\">" + esc(a.qty) + "</td><td class=\"n\">" + money(a.rate) + "</td><td class=\"n\">" + money(a.discount) + "</td><td class=\"n\">" + money(num(a.gstAmt) ? a.taxable : a.total) + "</td></tr>";
  const o = p ? "<th>" + t("Description") + "</th><th class=\"n\">" + t("Amount") + "</th>" : "<th>" + t("Item") + "</th><th class=\"n\">" + t("Qty") + "</th><th class=\"n\">" + t("Rate") + "</th><th class=\"n\">" + t("Discount") + "</th><th class=\"n\">" + t("Amount") + "</th>";
  const i = num(p ? a.amount : a.total);
  return {
    title: r,
    inner: "<div class=\"hd\"><div>" + (s.logo ? "<img src=\"" + s.logo + "\"><br>" : "") + "<h1>" + esc(s.name || "Your Business") + "</h1><div class=\"muted\">" + esc(s.address || "").replace(/\n/g, "<br>") + (s.phone ? "<br>" + t("Phone") + ": " + esc(s.phone) : "") + (s.gst ? "<br>GSTIN: " + esc(s.gst) : "") + "</div></div>\n  <div><div class=\"t\">" + r + "</div></div></div>\n  <div class=\"meta\"><div><b>" + t("Bill to") + "</b><br>" + esc(a.customer || "—") + (b.phone ? "<br>" + esc(b.phone) : "") + (b.gstin ? "<br>GSTIN: " + esc(b.gstin) : "") + (b.place ? "<br>" + esc(b.place) : "") + "</div>\n  <div style=\"text-align:right\"><b>" + t("No") + ":</b> " + esc(a.no) + "<br><b>" + t("Date") + ":</b> " + fmtDate(a.date) + (p && a.valid ? "<br><b>" + t("Valid till") + ":</b> " + fmtDate(a.valid) : "") + (!p && a.due && unpaid(a) ? "<br><b>" + t("Pay by") + ":</b> " + fmtDate(a.due) : "") + "</div></div>\n  <table><thead><tr>" + o + "</tr></thead><tbody>" + l + "</tbody></table>\n  <div class=\"sum\">" + (!p && num(a.gstAmt) ? "<div><span>" + t("Taxable value") + "</span><span>" + money(a.taxable) + "</span></div>" + (biz().gstType === "igst" ? [["IGST", 1]] : [["CGST", 0.5], ["SGST", 0.5]]).map(([e, s]) => "<div><span>" + e + " " + num(a.gst) * s + "%</span><span>" + money(a.gstAmt * s) + "</span></div>").join("") : "") + "<div class=\"g\"><span>" + t("Total") + "</span><span>" + money(i) + "</span></div>\n  " + (p || _ ? "" : "<div><span>" + t("Received") + "</span><span>" + money(a.rcv) + "</span></div><div><b>" + t("Balance due") + "</b><b>" + money(balance(a)) + "</b></div>") + "</div>\n  " + (p || _ || unpaid(a) ? "" : "<div class=\"stamp\">" + t("PAID") + "</div>") + "\n  " + ((s.bank || s.acc || s.upi) && (p || unpaid(a)) ? "<div class=\"bank\"><b>" + t("Payment details") + "</b><br>" + (s.bank ? t("Bank") + ": " + esc(s.bank) + "<br>" : "") + (s.acc ? "A/c no: " + esc(s.acc) + (s.ifsc ? " · IFSC: " + esc(s.ifsc) : "") + "<br>" : "") + (s.upi ? "UPI: " + esc(s.upi) : "") + "</div>" : "") + "\n  <div class=\"foot\">" + esc(s.terms || t("Thank you for your business.")) + "</div>"
  };
}
function printDoc(e, a) {
  const {
    title: s,
    inner: p
  } = docParts(e, a);
  openHtml("<!doctype html><html lang=\"" + lang() + "\" dir=\"" + (lang() === "ar" ? "rtl" : "ltr") + "\"><head><meta charset=\"utf-8\"><title>" + s + " " + esc(a.no) + "</title><style>" + DOC_CSS() + "</style></head><body>\n  <button id=\"pbtn\">" + t("Print / Save as PDF") + "</button>\n  " + p + "</body></html>");
}
function printStatement(e) {
  const n = biz();
  const s = (e.name || "").trim().toLowerCase();
  const p = [];
  rows("sales").filter(e => (e.customer || "").trim().toLowerCase() === s).forEach(e => {
    if (e.kind === "Return") {
      p.push({
        d: e.date,
        t: t("Credit note") + " " + (e.no || ""),
        cr: num(e.total)
      });
    } else {
      p.push({
        d: e.date,
        t: t("Invoice") + " " + (e.no || "") + " – " + (e.item || ""),
        dr: num(e.total)
      });
      (e.pays || []).forEach(e => p.push({
        d: e.date,
        t: t("Payment received"),
        cr: num(e.amt)
      }));
    }
  });
  rows("payments").filter(e => e.dir !== "To pay" && (e.party || "").trim().toLowerCase() === s).forEach(e => {
    p.push({
      d: e.due || e.created,
      t: e.inst || t("Payment due"),
      dr: num(e.amount)
    });
    (e.pays || []).forEach(e => p.push({
      d: e.date,
      t: t("Payment received"),
      cr: num(e.amt)
    }));
  });
  p.sort((e, n) => (e.d || "").localeCompare(n.d || ""));
  let _ = 0;
  const b = p.map(e => {
    _ += num(e.dr) - num(e.cr);
    return "<tr><td>" + fmtDate(e.d) + "</td><td>" + esc(e.t) + "</td><td class=\"n\">" + (e.dr ? money(e.dr) : "") + "</td><td class=\"n\">" + (e.cr ? money(e.cr) : "") + "</td><td class=\"n\">" + money(_) + "</td></tr>";
  }).join("");
  openHtml("<!doctype html><html lang=\"" + lang() + "\" dir=\"" + (lang() === "ar" ? "rtl" : "ltr") + "\"><head><meta charset=\"utf-8\"><title>" + t("STATEMENT") + " " + esc(e.name) + "</title><style>" + DOC_CSS() + "</style></head><body>\n  <button id=\"pbtn\">" + t("Print / Save as PDF") + "</button>\n  <div class=\"hd\"><div>" + (n.logo ? "<img src=\"" + n.logo + "\"><br>" : "") + "<h1>" + esc(n.name || "Your Business") + "</h1><div class=\"muted\">" + esc(n.address || "").replace(/\n/g, "<br>") + (n.phone ? "<br>" + t("Phone") + ": " + esc(n.phone) : "") + (n.gst ? "<br>GSTIN: " + esc(n.gst) : "") + "</div></div><div><div class=\"t\">" + t("STATEMENT") + "</div></div></div>\n  <div class=\"meta\"><div><b>" + t("Customer") + "</b><br>" + esc(e.name) + (e.phone ? "<br>" + esc(e.phone) : "") + (e.place ? "<br>" + esc(e.place) : "") + "</div><div style=\"text-align:end\"><b>" + t("Date") + ":</b> " + fmtDate(today()) + "</div></div>\n  <table><thead><tr><th>" + t("Date") + "</th><th>" + t("Details") + "</th><th class=\"n\">" + t("Billed") + "</th><th class=\"n\">" + t("Received") + "</th><th class=\"n\">" + t("Balance") + "</th></tr></thead><tbody>" + (b || "<tr><td colspan=\"5\">" + t("No bills yet") + "</td></tr>") + "</tbody></table>\n  <div class=\"sum\"><div class=\"g\"><span>" + t("Balance due") + "</span><span>" + money(_) + "</span></div></div>\n  " + ((n.bank || n.acc || n.upi) && _ > 0 ? "<div class=\"bank\"><b>" + t("Payment details") + "</b><br>" + (n.bank ? t("Bank") + ": " + esc(n.bank) + "<br>" : "") + (n.acc ? "A/c no: " + esc(n.acc) + (n.ifsc ? " · IFSC: " + esc(n.ifsc) : "") + "<br>" : "") + (n.upi ? "UPI: " + esc(n.upi) : "") + "</div>" : "") + "</body></html>");
}
const lang = () => state.settings.lang || "en";
const PREFIXES = ["Invoice", "Last date", "balance", "reorder", "Pay by", "Valid till", "Credit note"];
const PATTERNS = [[/^(\d+) entries$/, "$entries"], [/^🔴 CASH RED ALERT — (\d+) payments? past the last date · (.*)$/, "$alert"], [/^OVERDUE (\d+) days?$/, "$overdue"], [/^Cash will run short in (.*) — plan funds in advance$/, "$short"], [/^⚠ Low stock: (.*) — (.*) left$/, "$low"], [/^(\d+) records saved in this browser\. Download a backup regularly\.$/, "$records"], [/^Balance (.*)$/, "$bal2"], [/^Invoice (.*) created in Sales & Billing$/, "$invcreated"], [/^(\d+) repeating items? created$/, "$recur"], [/^· by (.*)$/, "$by"]];
function t(e) {
  const n = lang();
  if (n === "en" || !e) {
    return e;
  }
  const s = I18N[n] || {};
  if (s[e = String(e)]) {
    return s[e];
  }
  let p;
  for (const [n, t] of PATTERNS) {
    if ((p = e.match(n)) && s[t]) {
      return s[t].replace(/\{(\d)\}/g, (e, a) => p[+a]);
    }
  }
  if (p = e.match(/^(.*?)( \(₹\)| \*)$/)) {
    const e = t(p[1]);
    if (e !== p[1]) {
      return e + p[2];
    }
  }
  if (p = e.match(/^([^\p{L}\d₹]+?)\s+(.*\p{L}.*)$/u)) {
    const e = t(p[2]);
    if (e !== p[2]) {
      return p[1] + " " + e;
    }
  }
  if ((p = e.match(/^(.*) \((\d+)\)$/)) && s[p[1]]) {
    return s[p[1]] + " (" + p[2] + ")";
  }
  if ((p = e.match(/^(New|Edit) · (.*)$/)) && s[p[1]]) {
    return s[p[1]] + " · " + t(p[2]);
  }
  if ((p = e.match(/^(All) (.*)$/)) && s.All) {
    return s.All + " " + t(p[2][0].toUpperCase() + p[2].slice(1));
  }
  for (const a of PREFIXES) {
    if (e.startsWith(a + " ") && s[a]) {
      return s[a] + " " + e.slice(a.length + 1);
    }
  }
  if (window.__miss) {
    window.__miss.add(e);
  }
  return e;
}
function localize() {
  const a = lang();
  document.documentElement.lang = a;
  document.documentElement.dir = a === "ar" ? "rtl" : "ltr";
  const n = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let s;
  const p = [];
  while (s = n.nextNode()) {
    p.push(s);
  }
  p.forEach(a => {
    const s = a.parentNode.nodeName;
    if (s === "SCRIPT" || s === "STYLE" || a.parentNode.closest && a.parentNode.closest("[data-nolang]")) {
      return;
    }
    const p = a._en ?? a.nodeValue;
    if (!p.trim()) {
      return;
    }
    const _ = p.match(/^\s*/)[0];
    const b = p.match(/\s*$/)[0];
    const r = p.trim();
    a._en = p;
    const l = t(r);
    a.nodeValue = _ + l + b;
  });
  document.querySelectorAll("[placeholder]").forEach(a => {
    a._ph = a._ph ?? a.getAttribute("placeholder");
    a.setAttribute("placeholder", t(a._ph));
  });
  document.querySelectorAll("[title]").forEach(a => {
    a._tt = a._tt ?? a.getAttribute("title");
    a.setAttribute("title", t(a._tt));
  });
}
function applySearch(e, a) {
  const s = (state.q || state.gq).trim().toLowerCase();
  if (s) {
    return a.filter(e => Object.values(e).join(" ").toLowerCase().includes(s));
  } else {
    return a;
  }
}
function renderModule(e) {
  const n = rows(e.id);
  let s = [...n].sort((a, n) => {
    const t = e.sortBy || null;
    if (!t) {
      const s = DATEKEY[e.id] || "created";
      return (n[s] || n.created || "").localeCompare(a[s] || a.created || "") || (n.id || "").localeCompare(a.id || "");
    }
    return (e.asc ? 1 : -1) * (a[t] || "").localeCompare(n[t] || "");
  });
  s = applySearch(e, s);
  const t = e.f.find(e => e.t === "select" && ["status", "stage", "pay", "type", "dir"].includes(e.k));
  if (t && state.filter) {
    s = s.filter(e => e[t.k] === state.filter);
  }
  return "<div class=\"bar\"><h2>" + e.i + " " + e.n + "</h2><span class=\"sub\">" + n.length + " entries</span><span class=\"grow\"></span>\n  <input type=\"search\" id=\"modQ\" placeholder=\"Search…\" value=\"" + esc(state.q) + "\" style=\"width:200px\">\n  " + (t ? "<select id=\"modF\"><option value=\"\">All " + esc(t.l.toLowerCase()) + "</option>" + t.opts.map(e => "<option " + (state.filter === e ? "selected" : "") + ">" + esc(e) + "</option>").join("") + "</select>" : "") + "\n  <button data-act=\"exportCsv\">⬇ CSV</button><button class=\"primary\" data-act=\"add\">+ Add</button></div>\n  " + (["payments", "sales"].includes(e.id) ? alertBox() : "") + "\n  " + tableFor(e, s) + "\n  " + (e.id === "plans" || e.id === "growth" ? "<p class=\"sub\" style=\"margin-top:10px\">Plan fields: Plan name → Goal → Budget → Responsible person → Start date → Deadline → Tasks → Status → Actual result</p>" : "");
}
function renderSide() {
  let a = "";
  let n = "";
  const s = alerts().length;
  visibleMods().forEach(t => {
    if (t.g !== n) {
      a += "<div class=\"grp\">" + t.g + "</div>";
      n = t.g;
    }
    a += "<button data-mod=\"" + t.id + "\" class=\"" + (state.mod === t.id ? "on" : "") + "\"><span>" + (t.i || "") + "</span>" + t.n + (t.id !== "payments" && t.id !== "dashboard" || !s ? "" : "<span class=\"badge\">" + s + "</span>") + "</button>";
  });
  $("#side").innerHTML = a;
}
function render() {
  if (isLocked()) {
    afterRender();
    return;
  }
  if (!visibleMods().some(e => e.id === state.mod)) {
    state.mod = "dashboard";
  }
  document.querySelectorAll("#mode button").forEach(a => a.classList.toggle("on", a.dataset.mode === state.settings.mode));
  renderSide();
  const a = modById[state.mod];
  if (state.gq) {
    a.custom;
  }
  $("#view").innerHTML = a.custom === "dashboard" ? renderDashboard() : a.custom === "cashflow" ? renderCashflow(a) : a.custom === "reports" ? renderReports() : a.custom === "backup" ? renderBackup() : a.custom === "settings" ? renderSettings() : a.custom === "gst" ? renderGst() : CUSTOM[a.custom] ? CUSTOM[a.custom](a) : renderModule(a);
  $("#lang").value = lang();
  localize();
  afterRender();
  const n = alerts().length;
  document.title = n ? "(" + n + ") ⚠ Payment due – Business Planner" : "Business Planner";
  const s = {
    customers: rows("customers").map(a => a.name),
    products: rows("products").map(e => e.name),
    suppliers: rows("suppliers").map(e => e.name),
    stockitems: [...rows("stock").map(e => e.item), ...rows("products").map(a => a.name)],
    expcats: [...new Set([...rows("ledger"), ...rows("budget")].map(a => a.cat))]
  };
  document.querySelectorAll("datalist").forEach(e => e.remove());
  Object.entries(s).forEach(([a, n]) => {
    const s = document.createElement("datalist");
    s.id = "dl-" + a;
    s.innerHTML = [...new Set(n.filter(Boolean))].map(e => "<option value=\"" + esc(e) + "\">").join("");
    document.body.appendChild(s);
  });
}
const dlg = $("#dlg");
let tt;
let editing = null;
function openForm(e, a) {
  const s = a ? rows(e.id).find(e => e.id === a) : null;
  editing = {
    m: e,
    id: a
  };
  $("#dlgTitle").textContent = (s ? "Edit · " : "New · ") + e.n;
  $("#formBody").innerHTML = e.f.map(e => {
    let t = s ? s[e.k] ?? "" : e.def === "today" ? today() : e.def === "month" ? today().slice(0, 7) : e.def === "gstdef" ? biz().gstRate || "" : e.def === "nextinv" ? (biz().prefix || "INV-") + (rows("sales").length + 1) : e.def ?? (e.t === "select" ? e.opts[0] : "");
    const p = "id=\"f_" + e.k + "\" " + (e.req ? "required" : "") + " " + (e.list ? "list=\"dl-" + e.list + "\"" : "");
    const _ = e.t === "select" ? "<select " + p + ">" + e.opts.map(e => "<option " + (e === t ? "selected" : "") + ">" + esc(e) + "</option>").join("") + "</select>" : e.t === "textarea" ? "<textarea " + p + " rows=\"3\">" + esc(t) + "</textarea>" : "<input " + p + " type=\"" + (e.t === "number" ? "number\" step=\"any" : e.t) + "\" value=\"" + esc(t) + "\">";
    return "<label class=\"" + (e.span ? "span2" : "") + "\">" + esc(e.l) + (e.req ? " *" : "") + _ + "</label>";
  }).join("");
  dlg.showModal();
  localize();
}
function toast(e, a) {
  const s = $("#toast");
  s.textContent = t(e);
  s.className = a ? "err" : "";
  s.hidden = false;
  clearTimeout(tt);
  tt = setTimeout(() => s.hidden = true, 2800);
}
function download(e, a, n) {
  const t = document.createElement("a");
  t.href = URL.createObjectURL(new Blob([a], {
    type: n
  }));
  t.download = e;
  t.click();
  setTimeout(() => URL.revokeObjectURL(t.href), 20000);
}
$("#cancelBtn").addEventListener("click", () => dlg.close());
$("#form").addEventListener("submit", async e => {
  e.preventDefault();
  const {
    m: n,
    id: s
  } = editing;
  const t = {};
  let p;
  n.f.forEach(e => {
    t[e.k] = $("#f_" + e.k).value.trim();
  });
  if (s) {
    p = rows(n.id).find(e => e.id === s);
    Object.assign(p, t);
  } else {
    p = {
      id: uid(),
      created: today(),
      ...t
    };
    rows(n.id).push(p);
  }
  if (n.calc) {
    n.calc(p);
  }
  dlg.close();
  await persist();
  toast("Saved");
});
document.addEventListener("click", async e => {
  const n = e.target.closest("#mode button");
  if (n) {
    state.settings.mode = n.dataset.mode;
    return persist();
  }
  const s = e.target.closest("#side button");
  if (s) {
    state.mod = s.dataset.mod;
    state.q = "";
    state.filter = "";
    return render();
  }
  const p = e.target.closest("[data-act]");
  if (!p) {
    return;
  }
  const _ = p.closest("[data-id]");
  const b = _?.dataset.id;
  const r = modById[_?.dataset.mod || state.mod];
  switch (p.dataset.act) {
    case "add":
      return openForm(r);
    case "edit":
      return openForm(r, b);
    case "openAlert":
      state.mod = r.id;
      render();
      return openForm(r, b);
    case "del":
      if (confirm(t("Delete this entry?"))) {
        const e = rows(r.id).find(e => e.id === b);
        if (r.stockRevert) {
          unstock(e);
        }
        state.db[r.id] = rows(r.id).filter(e => e.id !== b);
        await persist();
      }
      return;
    case "addPay":
      {
        const e = rows(r.id).find(e => e.id === b);
        const n = balance(e);
        const s = prompt(t("Amount received now?") + " (" + t("balance") + " " + money(n) + ")", n);
        if (s === null) {
          return;
        }
        const p = num(s);
        if (p <= 0) {
          return;
        }
        e.pays = e.pays || [];
        e.pays.push({
          date: today(),
          amt: p
        });
        e.rcv = sum(e.pays, e => e.amt);
        const _ = r.id === "sales" ? "pay" : "status";
        e[_] = e.rcv >= totalOf(e) ? "Paid" : "Partial";
        await persist();
        return toast(e[_] === "Paid" ? "Fully paid ✓" : "Balance " + money(balance(e)));
      }
    case "rmLogo":
      {
        const e = {
          ...biz()
        };
        delete e.logo;
        state.settings.biz = e;
        return persist();
      }
    case "statement":
      return printStatement(rows("customers").find(e => e.id === b));
    case "exportCsv":
      return exportCsv(r);
    case "exportAll":
      return exportAll();
    case "exportOne":
      return exportCsv(modById[p.dataset.m]);
    case "exportGst":
      return exportGst();
    case "wa":
      return sendWhatsApp(r, rows(r.id).find(e => e.id === b));
    case "waInv":
      return sendWhatsApp(r, rows(r.id).find(e => e.id === b), {
        pdf: true
      });
    case "exportGstr1":
      return exportGstr1("xlsx");
    case "exportGstr1Csv":
      return exportGstr1("csv");
    case "print":
      return printDoc(r.id === "sales" ? "invoice" : "quote", rows(r.id).find(e => e.id === b));
    case "quick":
      {
        const e = rows(r.id).find(e => e.id === b);
        e[r.quick.k] = r.quick.v;
        r.quick.also?.(e);
        await persist();
        return;
      }
    case "toInvoice":
      {
        const e = rows("quotes").find(e => e.id === b);
        const n = "INV-" + (rows("sales").length + 1);
        rows("sales").push({
          id: uid(),
          created: today(),
          no: n,
          date: today(),
          customer: e.customer,
          item: (e.items || "").split("\n")[0],
          qty: 1,
          rate: e.amount,
          discount: 0,
          kind: "Sale",
          pay: "Pending",
          rcv: 0,
          pays: [],
          due: "",
          total: num(e.amount),
          note: "From quotation " + e.no
        });
        e.status = "Invoiced";
        await persist();
        return toast("Invoice " + n + " created in Sales & Billing");
      }
    case "export":
      return download("business-planner-backup.json", JSON.stringify({
        app: "business-planner",
        savedAt: new Date().toISOString(),
        db: state.db,
        biz: state.settings.biz || {}
      }, null, 2), "application/json");
  }
});
document.addEventListener("input", e => {
  if (e.target.id === "modQ") {
    state.q = e.target.value;
    const a = e.target.selectionStart;
    render();
    const n = $("#modQ");
    n.focus();
    n.setSelectionRange(a, a);
  }
  if (e.target.id === "gsearch") {
    state.gq = e.target.value;
    if (modById[state.mod].custom) {
      state.mod = visibleMods().find(e => !e.custom)?.id || state.mod;
    }
    render();
  }
});
document.addEventListener("change", async e => {
  if (e.target.id === "lang") {
    state.settings.lang = e.target.value;
    return persist();
  }
  if (e.target.id === "gstMonth" && e.target.value) {
    state.gstMonth = e.target.value;
    return render();
  }
  if (e.target.dataset.biz) {
    state.settings.biz = {
      ...biz(),
      [e.target.dataset.biz]: e.target.value.trim()
    };
    await persist();
    return toast("Saved");
  }
  if (e.target.id === "logoFile" && e.target.files[0]) {
    const n = new Image();
    n.onload = async () => {
      const s = Math.min(1, 300 / n.width);
      const t = document.createElement("canvas");
      t.width = n.width * s;
      t.height = n.height * s;
      t.getContext("2d").drawImage(n, 0, 0, t.width, t.height);
      state.settings.biz = {
        ...biz(),
        logo: t.toDataURL("image/png")
      };
      await persist();
    };
    n.src = URL.createObjectURL(e.target.files[0]);
    return;
  }
  if (e.target.id === "modF") {
    state.filter = e.target.value;
    render();
  }
});
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && !dlg.open && !document.querySelector("input[type=\"file\"]")) {
    render();
  }
});
document.addEventListener("DOMContentLoaded", () => load().then(async () => {
  migrate();
  const a = runRecurring();
  if (a) {
    await persist();
    toast(a + " repeating item" + (a > 1 ? "s" : "") + " created");
  } else {
    render();
  }
}));
