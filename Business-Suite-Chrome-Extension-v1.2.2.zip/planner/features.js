"use strict";

(function () {
  const t = (e, t) => {
    const s = MODS.findIndex(e => e.id === t);
    MODS.splice(s + 1, 0, e);
    modById[e.id] = e;
  };
  t({
    id: "closing",
    n: "Daily Cash Closing",
    i: "🏧",
    basic: 1,
    g: "Money",
    custom: "closing"
  }, "ledger");
  t({
    id: "attendance",
    n: "Attendance & Salary",
    i: "🗓️",
    g: "Operate",
    custom: "attendance"
  }, "staff");
  t({
    id: "charts",
    n: "Profit & Charts",
    i: "📉",
    basic: 1,
    g: "Grow",
    custom: "charts"
  }, "reports");
  CUSTOM.closing = renderClosing;
  CUSTOM.attendance = renderAttendance;
  CUSTOM.charts = renderCharts;
})();
const gotoMod = e => {
  state.mod = e;
  state.q = "";
  state.filter = "";
  render();
  window.scrollTo(0, 0);
};
const monthName = e => {
  const [n, s] = e.split("-").map(Number);
  return new Date(n, s - 1, 1).toLocaleString("en", {
    month: "short"
  }) + " " + String(n).slice(2);
};
const monthLong = e => {
  const [n, s] = e.split("-").map(Number);
  return new Date(n, s - 1, 1).toLocaleString("en", {
    month: "long",
    year: "numeric"
  });
};
const lastDay = e => {
  const [n, s] = e.split("-").map(Number);
  return e + "-" + pad(new Date(n, s, 0).getDate());
};
const mIn = e => moneyIn(e + "-01", lastDay(e));
const mOut = e => moneyOut(e + "-01", lastDay(e));
const mSales = e => sum(rows("sales").filter(t => (t.date || "").slice(0, 7) === e), salesNet);
const cashBalance = () => moneyIn() - moneyOut();
const shortMoney = e => {
  const n = Math.abs(e);
  const s = e < 0 ? "-" : "";
  if (n >= 10000000) {
    return s + (n / 10000000).toFixed(1).replace(/\.0$/, "") + "Cr";
  } else if (n >= 100000) {
    return s + (n / 100000).toFixed(1).replace(/\.0$/, "") + "L";
  } else if (n >= 1000) {
    return s + (n / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  } else {
    return s + Math.round(n);
  }
};
const niceMax = e => {
  if (e <= 0) {
    return 4;
  }
  const n = Math.pow(10, Math.floor(Math.log10(e)));
  const s = e / n;
  return (s <= 1 ? 1 : s <= 2 ? 2 : s <= 4 ? 4 : s <= 8 ? 8 : 10) * n;
};
const tipAttr = e => "data-tip=\"" + esc(e) + "\"";
function barsChart(e, t, n, s = {}) {
  const r = s.w || 720;
  const i = s.h || 260;
  const o = 50;
  const c = r - o - 12;
  const d = i - 14 - 28;
  const p = e.length || 1;
  const l = [...t.flatMap(e => e.v), ...(n ? n.v : [])];
  let u = niceMax(Math.max(0, ...l));
  let y = Math.min(0, ...l);
  if (y < 0) {
    y = -niceMax(-y);
  }
  const m = e => 14 + d - (e - y) / (u - y || 1) * d;
  const b = m(0);
  const f = c / p;
  const g = Math.max(4, Math.min(26, f / (t.length + 1.2)));
  let h = "";
  for (let e = 0; e <= 4; e++) {
    const t = y + (u - y) * e / 4;
    const n = m(t);
    h += "<line x1=\"" + o + "\" x2=\"" + (r - 12) + "\" y1=\"" + n + "\" y2=\"" + n + "\" class=\"gl\"/><text x=\"44\" y=\"" + (n + 4) + "\" text-anchor=\"end\" class=\"ax\">" + shortMoney(t) + "</text>";
  }
  h += "<line x1=\"" + o + "\" x2=\"" + (r - 12) + "\" y1=\"" + b + "\" y2=\"" + b + "\" class=\"zl\"/>";
  e.forEach((e, n) => {
    const r = o + f * n + f / 2;
    const c = r - (t.length * g + (t.length - 1) * 3) / 2;
    t.forEach((e, t) => {
      const r = e.v[n] || 0;
      const i = Math.min(m(r), b);
      const o = Math.max(Math.abs(m(r) - b), r ? 2 : 0);
      h += "<rect x=\"" + (c + t * (g + 3)) + "\" y=\"" + i + "\" width=\"" + g + "\" height=\"" + o + "\" rx=\"4\" style=\"fill:" + e.c + "\"/>";
    });
    h += "<text x=\"" + r + "\" y=\"" + (i - 8) + "\" text-anchor=\"middle\" class=\"ax\">" + esc(e) + "</text>";
  });
  if (n) {
    const e = n.v.map((e, t) => o + f * t + f / 2 + "," + m(e));
    h += "<polyline points=\"" + e.join(" ") + "\" class=\"ln\"/>" + n.v.map((e, t) => "<circle cx=\"" + (o + f * t + f / 2) + "\" cy=\"" + m(e) + "\" r=\"4\" class=\"dot\"/>").join("");
  }
  e.forEach((e, s) => {
    const i = t.map(e => e.n + ": " + money(e.v[s])).concat(n ? [n.n + ": " + money(n.v[s])] : []);
    h += "<rect x=\"" + (o + f * s) + "\" y=\"" + 14 + "\" width=\"" + f + "\" height=\"" + d + "\" fill=\"transparent\" " + tipAttr("<b>" + esc(e) + "</b><br>" + i.map(esc).join("<br>")) + "/>";
  });
  return "<svg viewBox=\"0 0 " + r + " " + i + "\" class=\"chart\" role=\"img\" aria-label=\"" + esc(s.label || "Bar chart") + "\">" + h + "</svg>";
}
function linesChart(e, t, n = {}) {
  const a = n.h || 230;
  const r = 656;
  const i = a - 14 - 28;
  const o = e.length;
  const c = niceMax(Math.max(0, ...t.flatMap(e => e.v)));
  const d = e => 14 + i - e / c * i;
  const p = e => 50 + (o > 1 ? r * e / (o - 1) : 328);
  let l = "";
  for (let e = 0; e <= 4; e++) {
    const t = d(c * e / 4);
    l += "<line x1=\"50\" x2=\"706\" y1=\"" + t + "\" y2=\"" + t + "\" class=\"gl\"/><text x=\"44\" y=\"" + (t + 4) + "\" text-anchor=\"end\" class=\"ax\">" + shortMoney(c * e / 4) + "</text>";
  }
  const u = Math.ceil(o / 8);
  e.forEach((e, t) => {
    if (t % u === 0 || t === o - 1) {
      l += "<text x=\"" + p(t) + "\" y=\"" + (a - 8) + "\" text-anchor=\"middle\" class=\"ax\">" + esc(e) + "</text>";
    }
  });
  t.forEach(e => {
    l += "<polyline points=\"" + e.v.map((e, t) => p(t) + "," + d(e)).join(" ") + "\" class=\"ln\" style=\"stroke:" + e.c + "\"/>";
    if (o <= 16) {
      l += e.v.map((n, s) => "<circle cx=\"" + p(s) + "\" cy=\"" + d(n) + "\" r=\"3.5\" class=\"dot\" style=\"fill:" + e.c + "\"/>").join("");
    }
  });
  const y = o > 1 ? r / (o - 1) : r;
  e.forEach((e, n) => {
    l += "<rect x=\"" + (p(n) - y / 2) + "\" y=\"14\" width=\"" + y + "\" height=\"" + i + "\" fill=\"transparent\" " + tipAttr("<b>" + esc(e) + "</b><br>" + t.map(e => esc(e.n) + ": " + money(e.v[n])).join("<br>")) + "/>";
  });
  return "<svg viewBox=\"0 0 720 " + a + "\" class=\"chart\" role=\"img\" aria-label=\"" + esc(n.label || "Line chart") + "\">" + l + "</svg>";
}
function donut(e) {
  const n = sum(e, e => e.v) || 1;
  const s = Math.PI * 2 * 62;
  let a = 0;
  let r = "";
  e.forEach(e => {
    const i = e.v / n * s;
    r += "<circle cx=\"90\" cy=\"90\" r=\"62\" fill=\"none\" stroke-width=\"26\" style=\"stroke:" + e.c + "\" stroke-dasharray=\"" + Math.max(0, i - 2) + " " + (s - Math.max(0, i - 2)) + "\" stroke-dashoffset=\"" + -a + "\" transform=\"rotate(-90 90 90)\" " + tipAttr("<b>" + esc(e.n) + "</b><br>" + money(e.v) + " · " + Math.round(e.v / n * 100) + "%") + "/>";
    a += i;
  });
  return "<svg viewBox=\"0 0 180 180\" class=\"donut\" role=\"img\" aria-label=\"Expense split\">" + r + "<text x=\"90\" y=\"86\" text-anchor=\"middle\" class=\"ax\">Total</text><text x=\"90\" y=\"106\" text-anchor=\"middle\" class=\"dn\">" + shortMoney(n) + "</text></svg>";
}
const legend = e => "<div class=\"lgd\">" + e.map(e => "<span><i style=\"background:" + e.c + "\"></i>" + esc(e.n) + "</span>").join("") + "</div>";
const lastMonths = e => {
  const t = [];
  let n = today().slice(0, 7);
  for (let s = 0; s < e; s++) {
    t.unshift(n);
    n = shiftMonth(n, -1);
  }
  return t;
};
function renderCharts() {
  const t = state.chRange || 6;
  const n = lastMonths(t);
  const s = n[n.length - 1];
  const a = shiftMonth(s, -1);
  const r = n.map(mIn);
  const i = n.map(mOut);
  const o = n.map((e, t) => r[t] - i[t]);
  const c = mIn(s) - mOut(s);
  const d = mIn(a) - mOut(a);
  const p = d ? Math.round((c - d) / Math.abs(d) * 100) : null;
  const l = mIn(s) ? Math.round(c / mIn(s) * 100) : 0;
  const u = o.indexOf(Math.max(...o));
  const y = Array.from({
    length: Number(today().slice(8, 10))
  }, (e, t) => s + "-" + pad(t + 1));
  const m = y.map(e => moneyIn(e, e));
  const b = y.map(e => moneyOut(e, e));
  const f = {};
  rows("ledger").filter(t => t.type === "Expense" && (t.date || "").slice(0, 7) === s).forEach(t => {
    const n = t.cat || "Other";
    f[n] = (f[n] || 0) + num(t.amount);
  });
  const g = Object.entries(f).sort((e, t) => t[1] - e[1]);
  const h = ["var(--s1)", "var(--s2)", "var(--s3)", "var(--s4)", "var(--s5)"];
  const _ = g.slice(0, 5).map(([e, t], n) => ({
    n: e,
    v: t,
    c: h[n]
  }));
  const v = sum(g.slice(5), e => e[1]);
  if (v) {
    _.push({
      n: "Other",
      v: v,
      c: "var(--s0)"
    });
  }
  const w = {};
  rows("sales").filter(t => (t.date || "").slice(0, 7) === s).forEach(e => {
    const t = e.item || "—";
    w[t] = (w[t] || 0) + salesNet(e);
  });
  const x = Object.entries(w).sort((e, t) => t[1] - e[1]).slice(0, 6);
  const C = Math.max(1, ...x.map(e => e[1]));
  const D = r.some(Boolean) || i.some(Boolean);
  return "<div class=\"bar\"><h2>📉 Profit & Charts</h2><span class=\"sub\">" + monthLong(s) + "</span><span class=\"grow\"></span>\n   <select id=\"chRange\"><option value=\"6\" " + (t === 6 ? "selected" : "") + ">Last 6 months</option><option value=\"12\" " + (t === 12 ? "selected" : "") + ">Last 12 months</option><option value=\"3\" " + (t === 3 ? "selected" : "") + ">Last 3 months</option></select></div>\n  <div class=\"cards\">" + card("Profit this month", money(c), c >= 0 ? "good" : "bad") + card("Money in", money(mIn(s)), "good") + card("Expenses", money(mOut(s)), "bad") + "\n   " + card("Profit margin", l + "%", l >= 0 ? "good" : "bad") + card("vs last month", p === null ? "—" : (p >= 0 ? "▲ " : "▼ ") + Math.abs(p) + "%", p === null ? "" : p >= 0 ? "good" : "bad") + card("Best month", D ? monthName(n[u]) + " · " + shortMoney(o[u]) : "—") + "</div>\n  " + (D ? "" : "<p class=\"empty\">No money-in or expense entries yet — charts will appear as you add bills, payments and expenses.</p>") + "\n  <section class=\"vizcard\"><h3>Money in vs expenses, with profit</h3>" + legend([{
    n: "Money in",
    c: "var(--s1)"
  }, {
    n: "Expenses",
    c: "var(--s2)"
  }, {
    n: "Profit",
    c: "var(--ink)"
  }]) + "\n   " + barsChart(n.map(monthName), [{
    n: "Money in",
    c: "var(--s1)",
    v: r
  }, {
    n: "Expenses",
    c: "var(--s2)",
    v: i
  }], {
    n: "Profit",
    v: o
  }, {
    label: "Money in, expenses and profit by month"
  }) + "\n   <details><summary>View as table</summary><div class=\"tablewrap\"><table><thead><tr><th>Month</th><th class=\"num\">Sales</th><th class=\"num\">Money in</th><th class=\"num\">Expenses</th><th class=\"num\">Profit</th></tr></thead><tbody>" + n.map((t, n) => "<tr><td>" + monthName(t) + "</td><td class=\"num\">" + money(mSales(t)) + "</td><td class=\"num\">" + money(r[n]) + "</td><td class=\"num\">" + money(i[n]) + "</td><td class=\"num\"><b style=\"color:var(--" + (o[n] >= 0 ? "green" : "red") + ")\">" + money(o[n]) + "</b></td></tr>").join("") + "</tbody></table></div></details></section>\n  <section class=\"vizcard\"><h3>Daily money in & expenses — " + monthLong(s) + "</h3>" + legend([{
    n: "Money in",
    c: "var(--s1)"
  }, {
    n: "Expenses",
    c: "var(--s2)"
  }]) + "\n   " + linesChart(y.map(t => t.slice(8)), [{
    n: "Money in",
    c: "var(--s1)",
    v: m
  }, {
    n: "Expenses",
    c: "var(--s2)",
    v: b
  }], {
    label: "Daily money in and expenses"
  }) + "</section>\n  <div class=\"two\"><section class=\"vizcard\"><h3>Where the money went (this month)</h3>" + (_.length ? "<div class=\"donutRow\">" + donut(_) + "<div class=\"dlist\">" + _.map(t => "<div><i style=\"background:" + t.c + "\"></i><span>" + esc(t.n) + "</span><b>" + money(t.v) + "</b></div>").join("") + "</div></div>" : "<p class=\"empty\">No expenses this month.</p>") + "</section>\n  <section class=\"vizcard\"><h3>Best-selling this month</h3>" + (x.length ? "<div class=\"hbars\">" + x.map(([t, n]) => "<div " + tipAttr(esc(t) + ": " + money(n)) + "><span class=\"hl\">" + esc(t) + "</span><div class=\"bartrack\"><i style=\"width:" + Math.max(3, Math.round(n / C * 100)) + "%;background:var(--s1)\"></i></div><b>" + shortMoney(n) + "</b></div>").join("") + "</div>" : "<p class=\"empty\">No sales this month.</p>") + "</section></div>";
}
const denominations = e => BusinessCurrency.denominations(e && e.currency || biz().currency || "INR");
const closingFor = e => rows("closings").find(t => t.date === e);
const prevClosing = e => rows("closings").filter(t => t.date < e).sort((e, t) => t.date.localeCompare(e.date))[0];
function dayMoves(e) {
  const n = [];
  const s = [];
  rows("sales").forEach(s => (s.pays || []).filter(n => n.date === e).forEach(e => n.push({
    t: (s.kind === "Return" ? "Refund" : "Bill") + " " + (s.no || "") + " · " + (s.customer || ""),
    a: num(e.amt) * (s.kind === "Return" ? -1 : 1)
  })));
  rows("ledger").filter(n => n.date === e).forEach(e => (e.type === "Income" ? n : s).push({
    t: "" + (e.cat || e.type) + (e.note ? " · " + e.note : ""),
    a: num(e.amount)
  }));
  return {
    inn: n,
    out: s
  };
}
function closingNums(e) {
  const n = closingFor(e);
  const s = n ? num(n.opening) : e in state.cOpen ? num(state.cOpen[e]) : prevClosing(e) ? num(prevClosing(e).counted) : 0;
  const a = moneyIn(e, e);
  const r = moneyOut(e, e);
  const i = s + a - r;
  const o = n && n.den || state.cDen[e] || {};
  const c = denominations(n).reduce((e, t) => e + t * num(o[t]), 0);
  const d = n ? "" : state.cManual[e] ?? "";
  const p = n ? num(n.counted) : d !== "" ? num(d) : c;
  return {
    c: n,
    opening: s,
    cin: a,
    cout: r,
    expected: i,
    den: o,
    dsum: c,
    manual: d,
    counted: p,
    diff: p - i
  };
}
state.cOpen = {};
state.cDen = {};
state.cManual = {};
const diffChip = e => e === 0 ? "<span class=\"chip good\">✓ Tally matches</span>" : e > 0 ? "<span class=\"chip warn\">Excess " + money(e) + "</span>" : "<span class=\"chip bad\">Short " + money(-e) + "</span>";
function missedClosings() {
  const t = today();
  const n = new Set();
  rows("sales").forEach(t => (t.pays || []).forEach(t => t.date && n.add(t.date)));
  rows("ledger").forEach(t => t.date && n.add(t.date));
  const s = addDays(t, -7);
  return [...n].filter(e => e >= s && e < t && !closingFor(e)).sort();
}
function renderClosing() {
  const t = state.cDate ||= today();
  const n = closingNums(t);
  const s = dayMoves(t);
  const a = !!n.c;
  const r = rows("closings").slice().sort((t, n) => n.date.localeCompare(t.date)).slice(0, 30);
  const i = (t, n) => t.length ? "<div class=\"list\">" + t.map(e => "<div><span>" + esc(e.t) + "</span><span class=\"grow\"></span><b class=\"" + n + "\">" + money(e.a) + "</b></div>").join("") + "</div>" : "<p class=\"empty\">Nothing recorded.</p>";
  return "<div class=\"bar\"><h2>🏧 Daily Cash Closing</h2><span class=\"grow\"></span><button data-fa=\"cDay\" data-d=\"-1\">‹</button><input type=\"date\" id=\"cDate\" value=\"" + t + "\" style=\"width:auto\"><button data-fa=\"cDay\" data-d=\"1\">›</button><button data-fa=\"cToday\">Today</button></div>\n  <p class=\"sub\">Count the cash in your drawer, compare with the books, and lock the day. Differences are shown at once.</p>\n  <div class=\"cards\">" + card("Opening cash", money(n.opening)) + card("Money in today", money(n.cin), "good") + card("Expenses today", money(n.cout), "bad") + card("Should be in drawer", money(n.expected), "warn") + "\n   <div class=\"card " + (n.diff === 0 ? "good" : "bad") + "\" id=\"cDiffCard\"><div class=\"k\">Counted − expected</div><div class=\"v\" id=\"cDiffV\">" + (n.counted || a ? (n.diff > 0 ? "+" : "") + money(n.diff) : "—") + "</div></div></div>\n  <div class=\"two\"><section class=\"panel nom\"><h3>" + (a ? "🔒 Day closed" : "Count the cash") + "</h3>\n   " + (a ? "<p>Closed on " + esc(n.c.closedAt || "") + ". Counted <b>" + money(n.counted) + "</b> · expected <b>" + money(n.expected) + "</b> " + diffChip(n.diff) + "</p>" + (n.c.note ? "<p><i>" + esc(n.c.note) + "</i></p>" : "") + "\n     <div class=\"inl\"><button class=\"primary\" data-fa=\"cPrint\">🖨 Print</button><button data-fa=\"cReopen\" class=\"danger\">Reopen day</button></div>" : "<label class=\"inl1\">Opening cash <input type=\"number\" step=\"any\" id=\"cOpen\" value=\"" + esc(n.opening) + "\"></label>\n     <div class=\"den\">" + denominations().map(t => "<label><span>" + esc((biz().currency || "INR") + " " + t) + "</span><input type=\"number\" min=\"0\" step=\"any\" inputmode=\"decimal\" data-den=\"" + t + "\" value=\"" + esc(n.den[t] ?? "") + "\" placeholder=\"0\"></label>").join("") + "</div>\n     <div class=\"cnt\">Notes & coins total: <b id=\"cDenSum\">" + money(n.dsum) + "</b></div>\n     <label class=\"inl1\">…or type the total counted <input type=\"number\" step=\"any\" id=\"cManual\" value=\"" + esc(n.manual) + "\"></label>\n     <label class=\"inl1\">Note <input id=\"cNote\" placeholder=\"Reason for any difference\"></label>\n     <div class=\"cnt big\">Counted: <b id=\"cCounted\">" + money(n.counted) + "</b> <span id=\"cDiffChip\">" + (n.counted ? diffChip(n.diff) : "") + "</span></div>\n     <button class=\"primary wide\" data-fa=\"cClose\">✓ Close the day</button>") + "</section>\n   <section><h3>Money in (" + s.inn.length + ")</h3>" + i(s.inn, "g") + "<h3 style=\"margin-top:16px\">Expenses (" + s.out.length + ")</h3>" + i(s.out, "r") + "</section></div>\n  <section><h3>Past closings</h3>" + (r.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Date</th><th class=\"num\">Opening</th><th class=\"num\">In</th><th class=\"num\">Out</th><th class=\"num\">Expected</th><th class=\"num\">Counted</th><th>Result</th><th></th></tr></thead><tbody>" + r.map(t => "<tr data-d=\"" + t.date + "\"><td>" + fmtDate(t.date) + "</td><td class=\"num\">" + money(t.opening) + "</td><td class=\"num\">" + money(t.cin) + "</td><td class=\"num\">" + money(t.cout) + "</td><td class=\"num\">" + money(t.expected) + "</td><td class=\"num\">" + money(t.counted) + "</td><td>" + diffChip(num(t.counted) - num(t.expected)) + "</td><td class=\"acts\"><button data-fa=\"cView\" data-d=\"" + t.date + "\">View</button><button data-fa=\"cPrintD\" data-d=\"" + t.date + "\">Print</button></td></tr>").join("") + "</tbody></table></div>" : "<p class=\"empty\">No days closed yet.</p>") + "</section>";
}
function liveClosing() {
  const t = closingNums(state.cDate);
  const n = (e, t) => {
    const s = document.getElementById(e);
    if (s) {
      s.innerHTML = t;
    }
  };
  n("cDenSum", money(t.dsum));
  n("cCounted", money(t.counted));
  n("cDiffChip", t.counted ? diffChip(t.diff) : "");
  n("cDiffV", t.counted ? (t.diff > 0 ? "+" : "") + money(t.diff) : "—");
  const s = document.getElementById("cDiffCard");
  if (s) {
    s.className = "card " + (t.diff === 0 ? "good" : "bad");
  }
}
function printClosing(e) {
  const n = closingFor(e);
  if (!n) {
    return;
  }
  const s = biz();
  const a = num(n.counted) - num(n.expected);
  openHtml("<!doctype html><html><head><meta charset=\"utf-8\"><title>Cash closing " + e + "</title><style>" + DOC_CSS() + "</style></head><body><button id=\"pbtn\">Print / Save as PDF</button>\n  <div class=\"hd\"><div>" + (s.logo ? "<img src=\"" + s.logo + "\"><br>" : "") + "<h1>" + esc(s.name || "Your Business") + "</h1><div class=\"muted\">" + esc(s.address || "").replace(/\n/g, "<br>") + "</div></div><div><div class=\"t\" style=\"font-size:22px\">DAILY CASH CLOSING</div><div class=\"muted\" style=\"text-align:right\">" + fmtDate(e) + "</div></div></div>\n  <table style=\"margin-top:18px\"><tbody><tr><td>Opening cash</td><td class=\"n\">" + money(n.opening) + "</td></tr><tr><td>+ Money in</td><td class=\"n\">" + money(n.cin) + "</td></tr><tr><td>− Expenses</td><td class=\"n\">" + money(n.cout) + "</td></tr><tr><td><b>Expected in drawer</b></td><td class=\"n\"><b>" + money(n.expected) + "</b></td></tr><tr><td><b>Cash counted</b></td><td class=\"n\"><b>" + money(n.counted) + "</b></td></tr><tr><td><b>Difference</b></td><td class=\"n\"><b style=\"color:" + (a === 0 ? "#16a34a" : "#dc2626") + "\">" + (a === 0 ? "Tally matches" : (a > 0 ? "Excess " : "Short ") + money(Math.abs(a))) + "</b></td></tr></tbody></table>\n  " + (n.den && Object.values(n.den).some(Number) ? "<h3 style=\"margin-top:20px\">Cash count</h3><table><thead><tr><th>Note / coin</th><th class=\"n\">Count</th><th class=\"n\">Amount</th></tr></thead><tbody>" + denominations(n).filter(e => num(n.den[e])).map(e => "<tr><td>" + (n.currency || biz().currency || "INR") + " " + e + "</td><td class=\"n\">" + num(n.den[e]) + "</td><td class=\"n\">" + money(e * num(n.den[e])) + "</td></tr>").join("") + "</tbody></table>" : "") + "\n  " + (n.note ? "<p><b>Note:</b> " + esc(n.note) + "</p>" : "") + "<div style=\"display:flex;justify-content:space-between;margin-top:60px\"><span>Prepared by: ____________</span><span>Owner sign: ____________</span></div></body></html>");
}
const ATT = {
  P: ["Present", "p"],
  A: ["Absent", "a"],
  H: ["Half day", "h"],
  L: ["Paid leave", "l"],
  W: ["Weekly off", "w"]
};
const ATT_ORDER = ["", "P", "A", "H", "L", "W"];
const dim = e => {
  const [t, n] = e.split("-").map(Number);
  return new Date(t, n, 0).getDate();
};
function attRec(e, t, n) {
  let a = rows("attendance").find(n => n.sid === e && n.month === t);
  if (!a && n) {
    a = {
      id: uid(),
      sid: e,
      month: t,
      d: {},
      adv: 0,
      bonus: 0,
      ded: 0,
      paid: ""
    };
    rows("attendance").push(a);
  }
  return a;
}
function attCalc(e, t) {
  const s = attRec(e.id, t) || {
    d: {},
    adv: 0,
    bonus: 0,
    ded: 0
  };
  const a = {
    P: 0,
    A: 0,
    H: 0,
    L: 0,
    W: 0
  };
  Object.values(s.d).forEach(e => {
    if (e in a) {
      a[e]++;
    }
  });
  const r = dim(t);
  const i = a.P + a.H * 0.5 + a.L + a.W;
  const o = Math.round(num(e.salary) / r * i);
  return {
    r: s,
    cnt: a,
    n: r,
    earned: i,
    gross: o,
    net: Math.max(0, o + num(s.bonus) - num(s.adv) - num(s.ded)),
    marked: Object.values(s.d).filter(Boolean).length
  };
}
function syncStaff(e, t) {
  if (t === today().slice(0, 7)) {
    const s = attCalc(e, t).cnt;
    e.present = s.P + s.H * 0.5;
    e.leave = s.A + s.L;
  }
}
function renderAttendance() {
  const t = state.attMonth ||= today().slice(0, 7);
  const n = rows("staff");
  if (!n.length) {
    return "<div class=\"bar\"><h2>🗓️ Attendance & Salary</h2></div><p class=\"empty\">Add your staff first (name and monthly salary) in Staff Management, then come back to mark attendance and make salary slips.</p><button class=\"primary\" data-fa=\"goto\" data-mod=\"staff\">Open Staff Management</button>";
  }
  if (!n.some(e => e.id === state.attSid)) {
    state.attSid = n[0].id;
  }
  const s = n.find(e => e.id === state.attSid);
  const a = attCalc(s, t);
  const [r, i] = t.split("-").map(Number);
  const o = new Date(r, i - 1, 1).getDay();
  const c = today();
  let d = "";
  for (let e = 0; e < o; e++) {
    d += "<span></span>";
  }
  for (let n = 1; n <= a.n; n++) {
    const s = pad(n);
    const r = a.r.d[s] || "";
    d += "<button class=\"day " + (r ? "st-" + r : "") + " " + (t + "-" + s === c ? "today" : "") + "\" data-fa=\"attDay\" data-day=\"" + s + "\" title=\"" + (r ? ATT[r][0] : "Not marked") + "\"><small>" + n + "</small><b>" + (r || "·") + "</b></button>";
  }
  const p = n.map(e => ({
    x: e,
    c: attCalc(e, t)
  }));
  const l = Math.max(0, (t < c.slice(0, 7) ? a.n : t === c.slice(0, 7) ? Number(c.slice(8)) : 0) - a.marked);
  return "<div class=\"bar\"><h2>🗓️ Attendance & Salary</h2><span class=\"grow\"></span><input type=\"month\" id=\"attMonth\" value=\"" + t + "\" style=\"width:auto\"></div>\n  <div class=\"bar\"><select id=\"attSid\" style=\"min-width:200px\">" + n.map(t => "<option value=\"" + t.id + "\" " + (t.id === s.id ? "selected" : "") + ">" + esc(t.name) + (t.role ? " · " + esc(t.role) : "") + "</option>").join("") + "</select>\n   <button data-fa=\"attAll\">✓ Mark all present till today</button><button data-fa=\"attSun\">Sundays = weekly off</button><button data-fa=\"attClear\" class=\"danger\">Clear month</button></div>\n  <div class=\"two\"><section class=\"panel\"><div class=\"calHead\"><b>" + esc(s.name) + "</b><span class=\"sub\">" + monthLong(t) + "</span></div>\n   <div class=\"cal\"><i>Sun</i><i>Mon</i><i>Tue</i><i>Wed</i><i>Thu</i><i>Fri</i><i>Sat</i>" + d + "</div>\n   <div class=\"lgd calLg\">" + Object.entries(ATT).map(([e, [t, n]]) => "<span><em class=\"st-" + e + "\">" + e + "</em>" + t + "</span>").join("") + "</div><p class=\"sub\">Tap a day to change: Present → Absent → Half → Paid leave → Weekly off → clear." + (l ? " <b style=\"color:var(--amber)\">" + l + " past day" + (l > 1 ? "s" : "") + " not marked.</b>" : "") + "</p></section>\n  <section class=\"panel slipBox\"><h3>Salary — " + esc(s.name) + "</h3>\n   <div class=\"srow\"><span>Monthly salary</span><b>" + money(s.salary) + "</b></div><div class=\"srow\"><span>Present " + a.cnt.P + " · Half " + a.cnt.H + " · Leave " + a.cnt.L + " · Off " + a.cnt.W + " · Absent " + a.cnt.A + "</span><b>" + a.earned + " / " + a.n + " days</b></div>\n   <div class=\"srow\"><span>Earned salary</span><b>" + money(a.gross) + "</b></div>\n   <div class=\"grid3\"><label>Bonus / overtime<input type=\"number\" step=\"any\" id=\"attBonus\" value=\"" + esc(a.r.bonus || "") + "\"></label><label>Advance taken<input type=\"number\" step=\"any\" id=\"attAdv\" value=\"" + esc(a.r.adv || "") + "\"></label><label>Other deduction<input type=\"number\" step=\"any\" id=\"attDed\" value=\"" + esc(a.r.ded || "") + "\"></label></div>\n   <div class=\"srow net\"><span>Net pay</span><b>" + money(a.net) + "</b></div>\n   <div class=\"inl\"><button class=\"primary\" data-fa=\"attSlip\" data-sid=\"" + s.id + "\">🧾 Salary slip</button>" + (a.r.paid ? "<button data-fa=\"attPay\" data-sid=\"" + s.id + "\">✓ Paid on " + fmtDate(a.r.paid) + " · undo</button>" : "<button data-fa=\"attPay\" data-sid=\"" + s.id + "\">Mark salary paid</button>") + "</div>\n   <p class=\"sub\">“Mark paid” adds the salary to Income & Expenses automatically.</p></section></div>\n  <section><h3>All staff — " + monthLong(t) + "</h3><div class=\"tablewrap\"><table><thead><tr><th>Name</th><th class=\"num\">Present</th><th class=\"num\">Absent</th><th class=\"num\">Earned days</th><th class=\"num\">Earned</th><th class=\"num\">Net pay</th><th>Status</th><th></th></tr></thead><tbody>" + p.map(({
    x: t,
    c: n
  }) => "<tr><td><b>" + esc(t.name) + "</b> <span class=\"sub\">" + esc(t.role || "") + "</span></td><td class=\"num\">" + (n.cnt.P + n.cnt.H * 0.5) + "</td><td class=\"num\">" + n.cnt.A + "</td><td class=\"num\">" + n.earned + "</td><td class=\"num\">" + money(n.gross) + "</td><td class=\"num\"><b>" + money(n.net) + "</b></td><td>" + (n.r.paid ? "<span class=\"chip good\">Paid</span>" : "<span class=\"chip warn\">Unpaid</span>") + "</td><td class=\"acts\"><button data-fa=\"attOpen\" data-sid=\"" + t.id + "\">Open</button><button data-fa=\"attSlip\" data-sid=\"" + t.id + "\">Slip</button></td></tr>").join("") + "</tbody><tfoot><tr><td colspan=\"5\"><b>Total payable</b></td><td class=\"num\"><b>" + money(sum(p, t => t.c.net)) + "</b></td><td colspan=\"2\"></td></tr></tfoot></table></div></section>";
}
function attSave(e) {
  const t = rows("staff").find(t => t.id === e);
  if (t) {
    syncStaff(t, state.attMonth);
  }
  return persist();
}
function printSlip(e, t) {
  const s = rows("staff").find(t => t.id === e);
  if (!s) {
    return;
  }
  const a = attCalc(s, t);
  const r = biz();
  openHtml("<!doctype html><html><head><meta charset=\"utf-8\"><title>Salary slip " + esc(s.name) + " " + t + "</title><style>" + DOC_CSS() + "</style></head><body><button id=\"pbtn\">Print / Save as PDF</button>\n  <div class=\"hd\"><div>" + (r.logo ? "<img src=\"" + r.logo + "\"><br>" : "") + "<h1>" + esc(r.name || "Your Business") + "</h1><div class=\"muted\">" + esc(r.address || "").replace(/\n/g, "<br>") + (r.phone ? "<br>Phone: " + esc(r.phone) : "") + "</div></div><div><div class=\"t\" style=\"font-size:24px\">SALARY SLIP</div><div class=\"muted\" style=\"text-align:right\">" + monthLong(t) + "</div></div></div>\n  <div class=\"meta\"><div><b>Employee</b><br>" + esc(s.name) + (s.role ? "<br>" + esc(s.role) : "") + (s.phone ? "<br>" + esc(s.phone) : "") + "</div><div style=\"text-align:right\"><b>Days in month:</b> " + a.n + "<br><b>Present:</b> " + a.cnt.P + " · <b>Half:</b> " + a.cnt.H + "<br><b>Paid leave:</b> " + a.cnt.L + " · <b>Weekly off:</b> " + a.cnt.W + "<br><b>Absent:</b> " + a.cnt.A + "</div></div>\n  <table><thead><tr><th>Description</th><th class=\"n\">Amount</th></tr></thead><tbody>\n  <tr><td>Monthly salary</td><td class=\"n\">" + money(s.salary) + "</td></tr><tr><td>Salary for " + a.earned + " paid days (" + money(Math.round(num(s.salary) / a.n)) + " per day)</td><td class=\"n\">" + money(a.gross) + "</td></tr>\n  " + (num(a.r.bonus) ? "<tr><td>Bonus / overtime</td><td class=\"n\">+ " + money(a.r.bonus) + "</td></tr>" : "") + (num(a.r.adv) ? "<tr><td>Advance recovered</td><td class=\"n\">− " + money(a.r.adv) + "</td></tr>" : "") + (num(a.r.ded) ? "<tr><td>Other deduction</td><td class=\"n\">− " + money(a.r.ded) + "</td></tr>" : "") + "</tbody></table>\n  <div class=\"sum\"><div class=\"g\"><span>Net pay</span><span>" + money(a.net) + "</span></div></div>" + (a.r.paid ? "<div class=\"stamp\">PAID " + fmtDate(a.r.paid) + "</div>" : "") + "\n  <div style=\"display:flex;justify-content:space-between;margin-top:70px\"><span>Employee sign: ____________</span><span>Authorised sign: ____________</span></div></body></html>");
}
const sec = () => state.settings.sec || {};
let locked = true;
let lastAct = Date.now();
let pinBuf = "";
let badTries = 0;
let lockUntil = 0;
isLocked = () => locked && !!sec().hash;
const b64 = e => {
  const n = new Uint8Array(e);
  let s = "";
  for (let e = 0; e < n.length; e += 32768) {
    s += String.fromCharCode.apply(null, n.subarray(e, e + 32768));
  }
  return btoa(s);
};
const unb64 = e => Uint8Array.from(atob(e), e => e.charCodeAt(0));
async function deriveBits(e, t) {
  const s = await crypto.subtle.importKey("raw", new TextEncoder().encode(e), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({
    name: "PBKDF2",
    salt: unb64(t),
    iterations: 150000,
    hash: "SHA-256"
  }, s, 256);
}
const pinHash = async (e, t) => b64(await deriveBits(e, t));
const checkPin = async e => !!sec().hash && (await pinHash(e, sec().salt)) === sec().hash;
const mkSalt = () => b64(crypto.getRandomValues(new Uint8Array(16)));
const lockNow = () => {
  if (!sec().hash) {
    return toast("Set a PIN first (Business Profile → PIN lock)", true);
  }
  locked = true;
  pinBuf = "";
  render();
};
function drawLock() {
  const t = document.getElementById("lockscr");
  if (!t.dataset.built) {
    t.dataset.built = 1;
    t.innerHTML = "<div class=\"lockbox\"><div class=\"logo big\">B</div><h2 id=\"lkName\"></h2><p class=\"sub\">Enter your PIN to open</p><div class=\"dots\" id=\"lkDots\"></div><div class=\"lkmsg\" id=\"lkMsg\"></div>\n    <div class=\"keys\">" + [1, 2, 3, 4, 5, 6, 7, 8, 9].map(e => "<button data-fa=\"key\" data-k=\"" + e + "\">" + e + "</button>").join("") + "<button data-fa=\"key\" data-k=\"back\">⌫</button><button data-fa=\"key\" data-k=\"0\">0</button><button data-fa=\"key\" data-k=\"ok\" class=\"ok\">OK</button></div>\n    <button class=\"linkbtn\" data-fa=\"forgot\">Forgot PIN?</button></div>";
  }
  document.getElementById("lkName").textContent = biz().name || "Business Planner";
  document.getElementById("lkDots").innerHTML = Array.from({
    length: Math.max(4, pinBuf.length)
  }, (t, n) => "<i class=\"" + (n < pinBuf.length ? "on" : "") + "\"></i>").join("");
  document.title = "Business Planner 🔒";
}
async function pinKey(e) {
  if (Date.now() < lockUntil) {
    return;
  }
  const n = document.getElementById("lkMsg");
  if (e === "back") {
    pinBuf = pinBuf.slice(0, -1);
  } else if (e === "ok") {
    if (pinBuf.length < 4) {
      return;
    }
    if (await checkPin(pinBuf)) {
      locked = false;
      pinBuf = "";
      badTries = 0;
      lastAct = Date.now();
      render();
      return;
    }
    pinBuf = "";
    badTries++;
    n.textContent = "Wrong PIN";
    if (badTries >= 5) {
      lockUntil = Date.now() + 30000;
      badTries = 0;
      n.textContent = "Too many tries — wait 30 seconds";
      setTimeout(() => {
        n.textContent = "";
      }, 30000);
    }
    const e = document.querySelector(".lockbox");
    e.classList.remove("shake");
    e.offsetWidth;
    e.classList.add("shake");
  } else if (pinBuf.length < 6) {
    pinBuf += e;
    n.textContent = "";
  }
  drawLock();
}
async function pinSave() {
  const t = !!sec().hash;
  const n = $("#pinNew").value.trim();
  const s = $("#pinNew2").value.trim();
  if (t && !(await checkPin(($("#pinCur") || {}).value?.trim() || ""))) {
    return toast("Current PIN is wrong", true);
  }
  if (!/^\d{4,6}$/.test(n)) {
    return toast("PIN must be 4 to 6 digits", true);
  }
  if (n !== s) {
    return toast("The two PINs do not match", true);
  }
  const a = mkSalt();
  state.settings.sec = {
    ...sec(),
    salt: a,
    hash: await pinHash(n, a)
  };
  locked = false;
  await persist();
  toast("PIN saved ✓");
}
async function pinOff() {
  if (!(await checkPin(($("#pinCur") || {}).value?.trim() || ""))) {
    return toast("Enter your current PIN to remove it", true);
  }
  const t = {
    ...sec()
  };
  delete t.hash;
  delete t.salt;
  state.settings.sec = t;
  await persist();
  toast("PIN lock removed");
}
async function forgotPin() {
  if (!confirm("Forgot PIN?\n\nThe only way in is to ERASE all data in this app (you can then restore from a backup file). Continue?")) {
    return;
  }
  if ((prompt("Type ERASE to confirm") || "").trim() !== "ERASE") {
    return;
  }
  state.db = {};
  const t = {
    ...sec()
  };
  delete t.hash;
  delete t.salt;
  state.settings.sec = t;
  locked = false;
  await persist();
  toast("Data erased. Restore your backup from the Backup page.");
}
function settingsExtras() {
  const t = sec();
  const n = !!t.hash;
  return "<div class=\"panel secpanel\"><h3>🔐 PIN lock & privacy</h3><p>" + (n ? "✅ PIN lock is ON — the app asks for your PIN every time it opens and after idle time." : "Set a 4–6 digit PIN so nobody else can open your accounts. Customers’ names and amounts also stay hidden in desktop notifications once a PIN is set.") + "</p>\n  <div class=\"grid\">" + (n ? "<label>Current PIN<input type=\"password\" id=\"pinCur\" inputmode=\"numeric\" maxlength=\"6\" autocomplete=\"off\"></label>" : "") + "\n   <label>" + (n ? "New PIN" : "PIN (4–6 digits)") + "<input type=\"password\" id=\"pinNew\" inputmode=\"numeric\" maxlength=\"6\" autocomplete=\"off\"></label><label>Repeat PIN<input type=\"password\" id=\"pinNew2\" inputmode=\"numeric\" maxlength=\"6\" autocomplete=\"off\"></label>\n   <label>Auto-lock when idle<select data-sec=\"auto\">" + [["0", "Never"], ["1", "1 minute"], ["5", "5 minutes"], ["15", "15 minutes"], ["30", "30 minutes"]].map(([n, s]) => "<option value=\"" + n + "\" " + (String(t.auto ?? 5) === n ? "selected" : "") + ">" + s + "</option>").join("") + "</select></label>\n   <label>Start with amounts hidden<select data-sec=\"hideStart\"><option value=\"\">No</option><option value=\"1\" " + (t.hideStart ? "selected" : "") + ">Yes</option></select></label></div>\n  <div class=\"inl\"><button class=\"primary\" data-fa=\"pinSave\">" + (n ? "Change PIN" : "Set PIN") + "</button>" + (n ? "<button data-fa=\"lockNow\">🔒 Lock now</button><button class=\"danger\" data-fa=\"pinOff\">Remove PIN</button>" : "") + "</div>\n  <p class=\"sub\">👁 on the top bar blurs every currency amount when someone is looking (tap a figure to peek). Your data stays only in this browser — the PIN keeps others out of the app, and for stored files use the <b>password-protected backup</b> on the Backup page.</p></div>";
}
function maskAmounts() {
  ["#view", "#side"].forEach(t => {
    const s = $(t);
    if (!s) {
      return;
    }
    const a = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
    const r = [];
    let i;
    while (i = a.nextNode()) {
      if (!!/\b[A-Z]{3}\s/.test(i.nodeValue) && (!i.parentNode.closest || !i.parentNode.closest(".amt,option,textarea,script,style"))) {
        r.push(i);
      }
    }
    r.forEach(e => {
      const s = e.nodeValue.split(/(\b[A-Z]{3}\s*-?[\d,]+(?:\.\d+)?)/);
      if (s.length < 2) {
        return;
      }
      const a = document.createDocumentFragment();
      s.forEach((e, n) => {
        if (n % 2) {
          const t = document.createElement("span");
          t.className = "amt";
          t.textContent = e;
          a.appendChild(t);
        } else if (e) {
          a.appendChild(document.createTextNode(e));
        }
      });
      e.parentNode.replaceChild(a, e);
    });
  });
}
const sysDark = () => !!window.matchMedia && !!matchMedia("(prefers-color-scheme: dark)").matches;
function applyTheme() {
  const t = state.settings.theme || (sysDark() ? "dark" : "light");
  document.documentElement.dataset.theme = t;
  const n = $("#themeBtn");
  if (n) {
    n.textContent = t === "dark" ? "☀️" : "🌙";
  }
}
let firstRender = true;
let lastPosted = null;
function dashExtras() {
  const t = today();
  const n = biz();
  const s = new Date().getHours();
  const a = closingFor(t);
  const r = missedClosings();
  const i = Array.from({
    length: 7
  }, (e, n) => addDays(t, n - 6));
  return "<div class=\"hero\"><div><div class=\"hello\">" + (s < 12 ? "Good morning" : s < 17 ? "Good afternoon" : "Good evening") + " 👋</div><h2>" + esc(n.name || "Your Business") + "</h2><div class=\"heroSub\">" + fmtDate(t) + "</div></div>\n   <div class=\"heroStats\"><div><span>Cash balance</span><b>" + money(cashBalance()) + "</b></div><div><span>To receive</span><b>" + money(sum(rows("sales").filter(unpaid), balance) + sum(rows("payments").filter(e => unpaid(e) && e.dir !== "To pay"), balance)) + "</b></div></div></div>\n  <div class=\"strip " + (a ? "ok" : "warn") + "\"><span>" + (a ? "✓ Today’s cash is closed — " + (num(a.counted) - num(a.expected) === 0 ? "tally matches" : (num(a.counted) - num(a.expected) > 0 ? "excess " : "short ") + money(Math.abs(num(a.counted) - num(a.expected)))) : "🏧 Today’s cash is not closed yet") + (r.length ? " · <b>" + r.length + " earlier day" + (r.length > 1 ? "s" : "") + " not closed</b>" : "") + "</span><button data-fa=\"goto\" data-mod=\"closing\">" + (a ? "View" : "Close the day") + "</button></div>\n  <section class=\"vizcard mini\"><h3>Last 7 days</h3>" + legend([{
    n: "Money in",
    c: "var(--s1)"
  }, {
    n: "Expenses",
    c: "var(--s2)"
  }]) + barsChart(i.map(e => e.slice(8) + "/" + e.slice(5, 7)), [{
    n: "Money in",
    c: "var(--s1)",
    v: i.map(e => moneyIn(e, e))
  }, {
    n: "Expenses",
    c: "var(--s2)",
    v: i.map(e => moneyOut(e, e))
  }], null, {
    h: 190,
    label: "Last 7 days money in and expenses"
  }) + "</section>";
}
window.addEventListener("message", e => {
  if (e.origin === location.origin && e.data && e.data.type === "bp-lock-now") {
    lockNow();
  }
});
afterRender = () => {
  if (firstRender) {
    firstRender = false;
    if (sec().hideStart) {
      state.settings.hide = true;
    }
  }
  applyTheme();
  const t = isLocked();
  if (t !== lastPosted) {
    lastPosted = t;
    try {
      if (parent !== window) {
        parent.postMessage({
          type: "bp-lock",
          locked: t
        }, location.origin);
      }
    } catch {}
  }
  $("#lockscr").hidden = !t;
  document.body.classList.toggle("locked", t);
  if (t) {
    if (dlg.open) {
      dlg.close();
    }
    $("#view").innerHTML = "";
    $("#side").innerHTML = "";
    drawLock();
    return;
  }
  $("#lockBtn").hidden = !sec().hash;
  document.body.classList.toggle("hide-amt", !!state.settings.hide);
  $("#hideBtn").classList.toggle("on", !!state.settings.hide);
  if (state.settings.hide) {
    maskAmounts();
  }
};
applyTheme();
const nk = e => String(e).toLowerCase().replace(/[^a-z0-9]/g, "");
const AL = {
  name: ["client", "clientname", "customer", "customername", "name", "party", "partyname"],
  phone: ["phone", "phoneno", "phonenumber", "mobile", "mobileno", "mobilenumber", "contact", "whatsapp", "tel"],
  total: ["totalamount", "total", "amount", "price", "charge", "charges", "workamount", "billamount", "bill", "value"],
  recv: ["received", "receivedamount", "amountreceived", "paidamount", "paid", "amountpaid", "advance", "cashreceived"],
  pend: ["pending", "pendingamount", "pendingcash", "balance", "balanceamount", "dueamount", "remaining", "cashpending", "cashdue"],
  cash: ["cash", "cashamount"],
  status: ["status", "paymentstatus", "cashstatus", "workstatus", "state"],
  date: ["finishdate", "workfinishdate", "finisheddate", "completiondate", "completedate", "date", "workdate", "enddate", "finished", "datefinished"],
  due: ["duedate", "cashduedate", "lastcollectiondate", "collectiondate", "lastdate", "due", "collectby", "paydate", "cashlastdate", "lastcollection"],
  paidOn: ["paidon", "paiddate", "receiveddate"],
  work: ["work", "workname", "job", "jobname", "description", "details", "title", "item", "workdetails", "task", "note", "notes", "worktype", "service"],
  type: ["type", "entrytype", "kind", "txntype"],
  cat: ["category", "cat", "head", "expensetype", "expensecategory"]
};
function picker(e) {
  const t = {};
  Object.keys(e).forEach(n => {
    t[nk(n)] = e[n];
  });
  return e => {
    for (const n of AL[e]) {
      if (n in t && t[n] !== "" && t[n] != null && typeof t[n] != "object") {
        return t[n];
      }
    }
  };
}
const amt = e => {
  if (e == null || e === "") {
    return 0;
  }
  const t = parseFloat(String(e).replace(/[^\d.\-]/g, ""));
  if (isFinite(t)) {
    return t;
  } else {
    return 0;
  }
};
function nd(e) {
  if (e == null || e === "") {
    return "";
  }
  if (typeof e === "number") {
    const t = new Date(e > 100000000000 ? e : e * 1000);
    if (isNaN(t)) {
      return "";
    } else {
      return ymd(t);
    }
  }
  const n = String(e).trim();
  let s;
  if (s = n.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/)) {
    return s[1] + "-" + pad(s[2]) + "-" + pad(s[3]);
  }
  if (s = n.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/)) {
    return (s[3].length === 2 ? "20" + s[3] : s[3]) + "-" + pad(s[2]) + "-" + pad(s[1]);
  }
  const a = new Date(n);
  if (isNaN(a)) {
    return "";
  } else {
    return ymd(a);
  }
}
function parseCsv(e) {
  const n = [];
  let s = [];
  let a = "";
  let r = false;
  e = e.replace(/^﻿/, "");
  for (let i = 0; i < e.length; i++) {
    const o = e[i];
    if (r) {
      if (o === "\"") {
        if (e[i + 1] === "\"") {
          a += "\"";
          i++;
        } else {
          r = false;
        }
      } else {
        a += o;
      }
    } else if (o === "\"") {
      r = true;
    } else if (o === ",") {
      s.push(a);
      a = "";
    } else if (o === "\n" || o === "\r") {
      if (o === "\r" && e[i + 1] === "\n") {
        i++;
      }
      s.push(a);
      n.push(s);
      s = [];
      a = "";
    } else {
      a += o;
    }
  }
  if (a || s.length) {
    s.push(a);
    n.push(s);
  }
  const i = (n.shift() || []).map(e => e.trim());
  return n.filter(e => e.some(e => e.trim())).map(e => Object.fromEntries(i.map((t, n) => [t, (e[n] || "").trim()])));
}
function collect(e, t, n, s) {
  if (Array.isArray(e)) {
    const s = e.filter(e => e && typeof e == "object" && !Array.isArray(e));
    if (s.length) {
      n.push({
        key: t,
        rows: s
      });
    }
    return;
  }
  if (e && typeof e == "object" && s < 4) {
    const r = Object.keys(e);
    const i = Object.values(e);
    const o = e => {
      const n = picker(e);
      return n("name") || n("total") || n("work") || n("cash");
    };
    if (i.length && i.every(e => e && typeof e == "object" && !Array.isArray(e)) && i.some(o)) {
      n.push({
        key: t,
        rows: i.map((e, t) => ({
          ...e,
          __k: r[t]
        }))
      });
      return;
    }
    r.forEach(a => collect(e[a], t + "/" + a, n, s + 1));
  }
}
function parseWT(e) {
  const t = [];
  const n = [];
  let s = 0;
  e.forEach(e => {
    const r = nk(e.key);
    const i = /expens|spend|spent|debit|outgo/.test(r) ? "Expense" : /income|credit|receipt|earning/.test(r) ? "Income" : "";
    const o = nd((e.key.match(/\d{4}-\d{2}-\d{2}/) || [])[0]);
    e.rows.forEach(e => {
      const c = picker(e);
      const d = String(c("type") || "").toLowerCase().trim();
      let p = i;
      if (!p && /^(expense|exp|debit|out|spent|spending)/.test(d)) {
        p = "Expense";
      }
      if (!p && /^(income|inc|credit|in|receipt|received)$/.test(d)) {
        p = "Income";
      }
      const l = {
        name: String(c("name") || "").trim(),
        phone: String(c("phone") || "").trim(),
        work: String(c("work") || "").trim(),
        date: nd(c("date")) || o || nd(e.__k),
        due: nd(c("due")),
        paidOn: nd(c("paidOn")),
        total: amt(c("total")),
        recv: c("recv") === undefined ? null : amt(c("recv")),
        pend: c("pend") === undefined ? null : amt(c("pend")),
        cash: c("cash") === undefined ? null : amt(c("cash")),
        status: String(c("status") || "").trim()
      };
      if (p) {
        const e = l.total || l.cash || 0;
        if (e) {
          n.push({
            type: p,
            date: l.date,
            amount: e,
            cat: String(c("cat") || l.work || p).trim(),
            note: [l.name, l.work].filter(Boolean).join(": ")
          });
          return;
        } else {
          s++;
          return;
        }
      }
      if ((l.name || l.work) && (l.total || l.cash || l.recv || l.pend)) {
        l.name ||= l.work;
        t.push(l);
      } else {
        s++;
      }
    });
  });
  return {
    jobs: t,
    led: n,
    skipped: s
  };
}
function finalizeJob(e, t) {
  const s = e.status.toLowerCase();
  const a = /paid|received|settled|complete/.test(s) && !/pend|unpaid|due|not/.test(s);
  const r = /pend|unpaid|due|not paid|balance/.test(s);
  let i = e.total || (e.recv || 0) + (e.pend || 0) || e.cash || 0;
  let o = 0;
  const c = t.cashMeaning === "auto" ? e.recv === null && e.pend === null ? r ? "pending" : "received" : "" : t.cashMeaning;
  if (a) {
    o = i;
  } else if (e.recv !== null) {
    o = e.recv;
  } else if (e.pend !== null) {
    o = i - e.pend;
  } else if (e.cash !== null && c === "received") {
    o = e.cash;
  } else if (e.cash !== null && c === "pending") {
    o = i - e.cash;
  }
  if (e.cash !== null && !e.total && c === "pending") {
    i = e.cash;
  }
  o = Math.max(0, Math.min(i, o));
  const d = e.key || e.name.toLowerCase() + "|" + e.date + "|" + i + "|" + e.work.toLowerCase();
  return {
    ...e,
    total: i,
    rcv: o,
    bal: i - o,
    pay: o >= i && i > 0 ? "Paid" : o > 0 ? "Partial" : "Pending",
    key: d
  };
}
const ledKey = e => "L|" + e.date + "|" + e.type + "|" + e.amount + "|" + (e.note || "").toLowerCase();
async function readImport(e) {
  const n = [];
  for (const s of e) {
    const e = await s.text();
    try {
      if (/\.csv$/i.test(s.name) || !/^[\s﻿]*[\[{]/.test(e)) {
        n.push({
          key: s.name,
          rows: parseCsv(e)
        });
      } else {
        collect(JSON.parse(e), s.name.replace(/\.\w+$/, ""), n, 0);
      }
    } catch (e) {
      return toast("Could not read " + s.name + ": " + e.message, true);
    }
  }
  state.imp = {
    ...parseWT(n),
    opts: {
      cashMeaning: "auto",
      inc: true,
      exp: true
    },
    files: e.map(e => e.name).join(", ")
  };
  if (!state.imp.jobs.length && !state.imp.led.length) {
    state.imp = null;
    return toast("No works or entries found in that file", true);
  }
  render();
}
function impSummary() {
  const t = state.imp;
  const n = t.opts;
  const s = t.jobs.map(e => finalizeJob(e, n));
  const a = new Set(rows("sales").map(t => t.impKey).filter(Boolean));
  const r = new Set();
  let i = 0;
  s.forEach(t => {
    t.dup = a.has(t.key) || r.has(t.key);
    r.add(t.key);
    if (t.dup) {
      i++;
    }
  });
  const o = new Set(rows("ledger").map(e => e.impKey).filter(Boolean));
  const c = new Set();
  const d = t.led.filter(t => t.type === "Income" ? n.inc : n.exp).map(t => {
    const s = ledKey(t);
    const a = o.has(s) || c.has(s);
    c.add(s);
    return {
      ...t,
      k: s,
      dup: a
    };
  });
  return {
    jobs: s,
    led: d,
    dup: i,
    dupL: d.filter(e => e.dup).length
  };
}
async function importFromSuite() {
  if (!hasChrome) {
    return toast("This works inside the extension only", true);
  }
  const t = ((await chrome.storage.local.get("trackerSuiteV4")).trackerSuiteV4 || {}).businesses || [];
  if (!t.length) {
    return toast("No Work Tracker data found in this extension yet", true);
  }
  const n = [];
  const s = [];
  let a = 0;
  const r = (e, t) => e.reduce((e, n) => e + num(t(n)), 0);
  t.forEach(i => {
    const c = i.data || {};
    const d = c.customers || [];
    const p = t.length > 1 ? "[" + c.business + "] " : "";
    (c.orders || []).forEach(e => {
      if (e.status === "cancelled") {
        a++;
        return;
      }
      const s = r(e.items || [], e => e.quantity * e.price);
      const i = s - (e.discountType === "percent" ? s * num(e.discount) / 100 : num(e.discount));
      f = i + i * num(e.taxRate) / 100;
      const c = Math.round((Number(f) + Number.EPSILON) * 100) / 100;
      const l = r(e.returns || [], e => num(e.net) + num(e.tax));
      const u = d.find(t => t.id === e.customerId) || {};
      const y = [...(e.payments || []).map(e => ({
        date: e.date,
        amt: num(e.amount)
      })), ...(e.refunds || []).map(e => ({
        date: e.date,
        amt: -num(e.amount)
      }))];
      const m = Math.max(0, c - l);
      const b = Math.max(0, Math.min(m, r(y, e => e.amt)));
      var f;
      n.push({
        name: (u.name || "Customer").trim(),
        phone: u.phone || "",
        work: p + (e.description || e.items && e.items[0] && e.items[0].description || "Work"),
        date: e.finishDate || e.date,
        due: e.due || "",
        total: m,
        recv: b,
        pend: null,
        cash: null,
        status: "",
        pays: y.filter(e => e.amt),
        key: "wt:" + e.id,
        noInvoiceDate: e.date
      });
    });
    (c.expenses || []).forEach(e => s.push({
      type: "Expense",
      date: e.date,
      amount: num(e.amount),
      cat: e.category || e.title || "Expense",
      note: p + (e.title || "")
    }));
  });
  state.imp = {
    jobs: n,
    led: s,
    skipped: a,
    opts: {
      cashMeaning: "auto",
      inc: true,
      exp: true
    },
    files: "Work Tracker (this extension)"
  };
  render();
}
function importPanel() {
  const t = state.imp;
  if (!t) {
    return "<div class=\"panel\"><h3>📥 Import from Work Tracker</h3>" + (hasChrome ? "<div class=\"inl\" style=\"margin-bottom:10px\"><button class=\"primary\" data-fa=\"impSuite\">⚡ Import from Work Tracker (this extension)</button></div><p>One click: orders become bills with their payments and due dates, customers and expenses come across. Safe to repeat — already imported orders are skipped.</p><p class=\"sub\">Or, from a file:</p>" : "") + "<p>Bring your old Work Tracker data into this app: client name, phone, finish date, total amount, cash status and last collection date become <b>customers and bills</b>; daily income / expense entries go to <b>Income & Expenses</b>. Choose the file exported from Work Tracker (.json or .csv). Importing the same file twice is safe — duplicates are skipped.</p><input type=\"file\" id=\"wtFile\" accept=\".json,.csv,.txt\" multiple></div>";
  }
  const n = impSummary();
  const s = t.opts;
  const a = n.jobs.filter(t => !t.dup).length;
  const r = n.led.filter(t => !t.dup).length;
  return "<div class=\"panel\"><h3>📥 Import preview <span class=\"sub\">· " + esc(t.files) + "</span></h3>\n  <div class=\"cards\"><div class=\"card\"><div class=\"k\">Works → bills</div><div class=\"v\">" + a + "</div></div><div class=\"card\"><div class=\"k\">Income / expense entries</div><div class=\"v\">" + r + "</div></div><div class=\"card " + (n.dup + n.dupL ? "warn" : "") + "\"><div class=\"k\">Already imported (skipped)</div><div class=\"v\">" + (n.dup + n.dupL) + "</div></div><div class=\"card " + (t.skipped ? "warn" : "") + "\"><div class=\"k\">Rows not understood</div><div class=\"v\">" + t.skipped + "</div></div></div>\n  <div class=\"grid\"><label>“Cash” amount in your works means<select id=\"impCash\"><option value=\"auto\" " + (s.cashMeaning === "auto" ? "selected" : "") + ">Automatic (by status)</option><option value=\"pending\" " + (s.cashMeaning === "pending" ? "selected" : "") + ">Cash still pending</option><option value=\"received\" " + (s.cashMeaning === "received" ? "selected" : "") + ">Cash already received</option></select></label>\n   <label>Daily entries<span class=\"inl\"><label class=\"chk\"><input type=\"checkbox\" id=\"impInc\" " + (s.inc ? "checked" : "") + "> Income</label><label class=\"chk\"><input type=\"checkbox\" id=\"impExp\" " + (s.exp ? "checked" : "") + "> Expenses</label></span></label></div>\n  <p class=\"sub\">Untick “Income” if your income entries are just the payments of the same works (they would be counted twice). A work marked only “Finish” with no cash info is imported as unpaid.</p>\n  " + (n.jobs.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Client</th><th>Work</th><th>Finished</th><th class=\"num\">Total</th><th class=\"num\">Received</th><th class=\"num\">Balance</th><th>Last date</th><th>Status</th></tr></thead><tbody>" + n.jobs.slice(0, 10).map(t => "<tr class=\"" + (t.dup ? "soon" : "") + "\"><td>" + esc(t.name) + "<div class=\"sub\">" + esc(t.phone) + "</div></td><td>" + esc(t.work) + "</td><td>" + fmtDate(t.date) + "</td><td class=\"num\">" + money(t.total) + "</td><td class=\"num\">" + money(t.rcv) + "</td><td class=\"num\">" + money(t.bal) + "</td><td>" + fmtDate(t.due) + "</td><td>" + (t.dup ? "<span class=\"chip\">Duplicate</span>" : chip(t.pay)) + "</td></tr>").join("") + "</tbody></table></div>" + (n.jobs.length > 10 ? "<p class=\"sub\">…and " + (n.jobs.length - 10) + " more</p>" : "") : "") + "\n  <div class=\"inl\" style=\"margin-top:12px\"><button class=\"primary\" data-fa=\"impGo\" " + (a + r ? "" : "disabled") + ">Import " + (a + r) + " records</button><button data-fa=\"impCancel\">Cancel</button></div></div>";
}
function doImport() {
  const t = impSummary();
  const n = today();
  const s = biz().prefix || "INV-";
  let a = rows("sales").reduce((t, n) => {
    const a = String(n.no || "").match(/(\d+)\s*$/);
    if (a) {
      return Math.max(t, Number(a[1]));
    } else {
      return t;
    }
  }, rows("sales").length);
  let r = 0;
  let i = 0;
  let o = 0;
  t.jobs.filter(e => !e.dup).forEach(t => {
    let c = rows("customers").find(e => (e.name || "").trim().toLowerCase() === t.name.toLowerCase());
    if (c) {
      if (!c.phone && t.phone) {
        c.phone = t.phone;
      }
    } else {
      c = {
        id: uid(),
        created: n,
        name: t.name,
        phone: t.phone,
        place: "",
        gstin: "",
        needs: "",
        notes: "Imported from Work Tracker"
      };
      rows("customers").push(c);
      r++;
    }
    const d = t.date || n;
    rows("sales").push({
      id: uid(),
      created: n,
      no: s + ++a,
      date: d,
      customer: t.name,
      item: t.work || "Work",
      qty: 1,
      rate: t.total,
      discount: 0,
      gst: 0,
      taxable: t.total,
      gstAmt: 0,
      total: t.total,
      kind: "Sale",
      pay: t.pay,
      rcv: t.rcv,
      pays: t.pays && t.pays.length ? t.pays : t.rcv > 0 ? [{
        date: t.paidOn || (t.pay === "Paid" ? d : t.date) || n,
        amt: t.rcv
      }] : [],
      due: t.pay === "Paid" ? "" : t.due,
      note: "Imported from Work Tracker",
      impKey: t.key
    });
    i++;
  });
  t.led.filter(e => !e.dup).forEach(t => {
    rows("ledger").push({
      id: uid(),
      created: n,
      date: t.date || n,
      type: t.type,
      cat: t.cat,
      amount: t.amount,
      note: t.note,
      impKey: t.k
    });
    o++;
  });
  state.imp = null;
  persist();
  toast("Imported " + i + " bills, " + r + " new customers, " + o + " income/expense entries");
}
async function encExport() {
  const t = ($("#encPw") || {}).value || "";
  if (t.length < 4) {
    return toast("Choose a password of at least 4 characters", true);
  }
  const n = mkSalt();
  const s = crypto.getRandomValues(new Uint8Array(12));
  const a = await crypto.subtle.importKey("raw", await deriveBits(t, n), "AES-GCM", false, ["encrypt"]);
  const r = new TextEncoder().encode(JSON.stringify({
    app: "business-planner",
    savedAt: new Date().toISOString(),
    db: state.db,
    biz: state.settings.biz || {}
  }));
  const i = await crypto.subtle.encrypt({
    name: "AES-GCM",
    iv: s
  }, a, r);
  download("business-planner-protected.bpenc", JSON.stringify({
    app: "business-planner",
    enc: 1,
    salt: n,
    iv: b64(s),
    data: b64(i)
  }), "application/json");
  toast("Protected backup downloaded");
}
async function encRestore(e) {
  try {
    const s = JSON.parse(await e.text());
    if (!s.enc) {
      throw new Error("Not a protected backup");
    }
    const a = ($("#encPw") || {}).value || prompt("Backup password?") || "";
    if (!a) {
      return;
    }
    const r = await crypto.subtle.importKey("raw", await deriveBits(a, s.salt), "AES-GCM", false, ["decrypt"]);
    const i = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({
      name: "AES-GCM",
      iv: unb64(s.iv)
    }, r, unb64(s.data))));
    if (!i.db || !confirm(t("Replace current data with this backup?"))) {
      return;
    }
    state.db = i.db;
    if (i.biz) {
      state.settings.biz = i.biz;
    }
    migrate();
    await persist();
    toast("Restored");
  } catch (e) {
    toast(e.name === "OperationError" ? "Wrong password or damaged file" : "Restore failed: " + e.message, true);
  }
}
async function startFresh() {
  if (confirm("Start Fresh — Business Planner\n\nThis removes ALL Planner records, including demo and real bills, stock, customers, payments, staff and attendance. Your business profile, preferences, PIN and license are kept. Work Tracker is not affected.\n\nClick OK to download a backup first, or Cancel to keep everything.")) {
    try {
      download("business-planner-before-reset-" + Date.now() + ".json", JSON.stringify({
        app: "business-planner",
        savedAt: new Date().toISOString(),
        db: state.db,
        biz: state.settings.biz || {}
      }, null, 2), "application/json");
    } catch (t) {
      return toast("Backup failed. Nothing was cleared: " + t.message, true);
    }
    if (confirm("Check your Downloads folder. Has the backup file finished downloading and been saved?\n\nCancel if it has not.") && prompt("Final confirmation: type RESET to erase all Business Planner records. This cannot be undone without restoring a backup.") === "RESET") {
      try {
        if (hasChrome) {
          await chrome.storage.local.set({
            db: {}
          });
        } else {
          localStorage.setItem("bp", JSON.stringify({
            db: {},
            settings: state.settings
          }));
        }
      } catch (t) {
        return toast("Reset failed. Nothing was cleared: " + t.message, true);
      }
      state.db = {};
      state.rst = null;
      state.imp = null;
      state.q = "";
      state.gq = "";
      state.filter = "";
      state.mod = "dashboard";
      render();
      toast("Fresh start ready. Add your products, opening stock and customers.");
    }
  }
}
function backupExtras() {
  return "<div class=\"panel\"><h3>🔐 Password-protected backup</h3><p>Same backup, but locked with a password — safe to keep in WhatsApp, email or Drive. Keep the password safe: without it the file cannot be opened.</p>\n  <div class=\"inl\"><input type=\"password\" id=\"encPw\" placeholder=\"Password\" autocomplete=\"new-password\" style=\"max-width:240px\"><button class=\"primary\" data-fa=\"encExport\">Download protected backup</button></div>\n  <p class=\"sub\" style=\"margin-top:12px\">To open a protected backup, use the Restore box below and type its password there.</p></div>" + importPanel() + "<div class=\"panel\"><h3>Start Fresh</h3><p>Clear all Business Planner records to start your own business data after a demo. This clears real records too. Your business profile, preferences, PIN and license are kept; Work Tracker is unaffected.</p><button data-fa=\"startFresh\">Start Fresh…</button><p class=\"sub\">A backup download and confirmation are required before clearing data.</p></div>";
}
const NAMEKEY = {
  customers: "name",
  products: "name",
  stock: "item",
  suppliers: "name",
  staff: "name"
};
const trailNo = e => {
  const t = String(e || "").match(/(\d+)\s*$/);
  if (t) {
    return Number(t[1]);
  } else {
    return 0;
  }
};
const sortKey = (e, t) => (t[DATEKEY[e] || "created"] || t.created || "") + (e === "appts" ? " " + (t.time || "") : "");
function mergeInto(e, t, n) {
  const a = {};
  const r = Object.keys(t).filter(e => Array.isArray(t[e]));
  const i = (e, t) => {
    (n.by[e] ||= {
      add: 0,
      dup: 0
    })[t]++;
  };
  r.filter(e => e !== "attendance").forEach(r => {
    const c = e[r] ||= [];
    const d = new Set(c.map(e => e.id));
    const p = NAMEKEY[r];
    const l = r === "ledger" ? e => [e.date, e.type, e.cat, e.amount, e.note].join("|") : null;
    const u = new Set(l ? c.map(l) : []);
    let y = r === "sales" || r === "quotes" ? Math.max(c.length, ...c.map(e => trailNo(e.no)), ...t[r].map(e => trailNo(e && e.no))) : 0;
    const m = new Set(c.map(e => e.no).filter(Boolean));
    t[r].forEach(e => {
      if (!e || typeof e !== "object") {
        return;
      }
      if (e.id && d.has(e.id)) {
        a[e.id] = e.id;
        return i(r, "dup");
      }
      if (p && e[p]) {
        const n = c.find(n => String(n[p] || "").trim().toLowerCase() === String(e[p]).trim().toLowerCase());
        if (n) {
          a[e.id] = n.id;
          return i(r, "dup");
        }
      }
      if (r === "closings" && c.some(n => n.date === e.date)) {
        return i(r, "dup");
      }
      if (l && u.has(l(e))) {
        return i(r, "dup");
      }
      const s = JSON.parse(JSON.stringify(e));
      if (!s.id || !!d.has(s.id)) {
        s.id = uid();
      }
      d.add(s.id);
      if ((r === "sales" || r === "quotes") && s.no && m.has(s.no)) {
        const e = s.no;
        s.no = String(s.no).replace(/\d+\s*$/, "") + ++y;
        n.renum++;
        s.note = ((s.note || "") + " (was " + e + " in the restored file)").trim();
      }
      if (s.no) {
        m.add(s.no);
      }
      if (l) {
        u.add(l(s));
      }
      c.push(s);
      i(r, "add");
    });
  });
  if (Array.isArray(t.attendance)) {
    const n = e.attendance ||= [];
    t.attendance.forEach(e => {
      const r = a[e.sid] || e.sid;
      const o = n.find(n => n.sid === r && n.month === e.month);
      if (o) {
        let n = 0;
        Object.entries(e.d || {}).forEach(([e, t]) => {
          if (!(e in o.d)) {
            o.d[e] = t;
            n++;
          }
        });
        return i("attendance", n ? "add" : "dup");
      }
      n.push({
        ...JSON.parse(JSON.stringify(e)),
        sid: r,
        id: n.some(t => t.id === e.id) ? uid() : e.id
      });
      i("attendance", "add");
    });
  }
}
function sortAllByDate(e) {
  Object.keys(e).forEach(n => {
    if (Array.isArray(e[n])) {
      e[n] = e[n].map((e, t) => [e, t]).sort((e, t) => sortKey(n, e[0]).localeCompare(sortKey(n, t[0])) || e[1] - t[1]).map(e => e[0]);
    }
  });
}
function planRestore() {
  const t = state.rst;
  const n = {
    by: {},
    renum: 0
  };
  const s = t.mode === "replace" ? {} : JSON.parse(JSON.stringify(state.db));
  t.files.forEach(e => mergeInto(s, e.db, n));
  sortAllByDate(s);
  return {
    base: s,
    st: n
  };
}
async function readRestore(e) {
  const n = [];
  const s = [];
  for (const a of e) {
    try {
      let e = JSON.parse(await a.text());
      if (e.enc) {
        const n = ($("#rstPw") || {}).value || prompt("Password for " + a.name + "?") || "";
        if (!n) {
          throw new Error("password needed");
        }
        const s = await crypto.subtle.importKey("raw", await deriveBits(n, e.salt), "AES-GCM", false, ["decrypt"]);
        e = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({
          name: "AES-GCM",
          iv: unb64(e.iv)
        }, s, unb64(e.data))));
      }
      if (!e.db || typeof e.db != "object") {
        throw new Error("not a Business Planner backup");
      }
      n.push({
        name: a.name,
        db: e.db,
        biz: e.biz || null,
        savedAt: e.savedAt || ""
      });
    } catch (e) {
      s.push(a.name + (e.name === "OperationError" ? " (wrong password)" : ""));
    }
  }
  if (s.length) {
    toast("Could not read: " + s.join(", "), true);
  }
  if (n.length) {
    n.sort((e, n) => (e.savedAt || "").localeCompare(n.savedAt || ""));
    state.rst = {
      files: n,
      mode: "merge"
    };
    render();
  }
}
async function applyRestore() {
  const n = state.rst;
  if (!n) {
    return;
  }
  const {
    base: s,
    st: a
  } = planRestore();
  const r = Object.values(a.by).reduce((e, t) => e + t.add, 0);
  if (n.mode === "replace" && !confirm(t("Replace current data with this backup?"))) {
    return;
  }
  state.db = s;
  const i = n.files.map(e => e.biz).filter(Boolean).pop();
  if (i) {
    if (n.mode === "replace") {
      state.settings.biz = i;
    } else {
      const t = {
        ...i
      };
      Object.entries(biz()).forEach(([e, n]) => {
        if (n !== "" && n != null) {
          t[e] = n;
        }
      });
      state.settings.biz = t;
    }
  }
  state.rst = null;
  migrate();
  await persist();
  toast(n.mode === "replace" ? "Restored — " + r + " records" : "Added " + r + " new records, sorted by date");
}
function restorePanel() {
  const t = state.rst;
  if (!t) {
    return "<div class=\"panel\"><h3>Restore / merge backups</h3><p>Choose <b>one or more</b> backup files (.json, or password-protected .bpenc). Next you pick: <b>add</b> them to your current data (nothing is lost, duplicates are skipped, everything is kept in date order) or <b>replace</b> your data.</p>\n   <div class=\"inl\"><input type=\"password\" id=\"rstPw\" placeholder=\"Password (only for .bpenc files)\" autocomplete=\"new-password\" style=\"max-width:260px\"></div><input type=\"file\" id=\"restoreFile\" accept=\".json,.bpenc\" multiple style=\"margin-top:8px\"></div>";
  }
  const {
    st: n
  } = planRestore();
  const s = Object.entries(n.by).filter(([, e]) => e.add || e.dup);
  const a = Object.values(n.by).reduce((t, n) => ({
    add: t.add + n.add,
    dup: t.dup + n.dup
  }), {
    add: 0,
    dup: 0
  });
  return "<div class=\"panel\"><h3>Restore preview</h3><p class=\"sub\">" + t.files.length + " file" + (t.files.length > 1 ? "s" : "") + ": " + t.files.map(e => esc(e.name)).join(", ") + "</p>\n   <label class=\"chk\" style=\"display:flex;gap:8px;margin:8px 0\"><input type=\"radio\" name=\"rstMode\" value=\"merge\" " + (t.mode === "merge" ? "checked" : "") + "><span><b>➕ Add to my current data</b> (recommended) — keeps everything you have, skips records already present, new bills/quotes with a clashing number get a new number, all lists stay in date order.</span></label>\n   <label class=\"chk\" style=\"display:flex;gap:8px;margin:8px 0\"><input type=\"radio\" name=\"rstMode\" value=\"replace\" " + (t.mode === "replace" ? "checked" : "") + "><span><b>♻ Replace everything</b> — current data is erased and only these files are kept (Business Profile also comes from the file). Download a backup first if unsure.</span></label>\n   <div class=\"cards\"><div class=\"card good\"><div class=\"k\">" + (t.mode === "replace" ? "Records kept" : "New records added") + "</div><div class=\"v\">" + a.add + "</div></div><div class=\"card " + (a.dup ? "warn" : "") + "\"><div class=\"k\">Already present (skipped)</div><div class=\"v\">" + a.dup + "</div></div>" + (n.renum ? "<div class=\"card warn\"><div class=\"k\">Bills/quotes renumbered</div><div class=\"v\">" + n.renum + "</div></div>" : "") + "</div>\n   " + (s.length ? "<div class=\"tablewrap\"><table><thead><tr><th>Module</th><th class=\"num\">" + (t.mode === "replace" ? "Records" : "Added") + "</th><th class=\"num\">Skipped</th></tr></thead><tbody>" + s.map(([t, n]) => "<tr><td>" + esc({
    closings: "🏧 Daily Cash Closing",
    attendance: "🗓️ Attendance"
  }[t] || ((modById[t] || {}).i || "") + " " + ((modById[t] || {}).n || t)) + "</td><td class=\"num\">" + n.add + "</td><td class=\"num\">" + n.dup + "</td></tr>").join("") + "</tbody></table></div>" : "") + "\n   <div class=\"inl\" style=\"margin-top:12px\"><button class=\"primary\" data-fa=\"rstApply\" " + (a.add || t.mode === "replace" ? "" : "disabled") + ">" + (t.mode === "replace" ? "Replace my data" : "Add to my data") + "</button><button data-fa=\"rstCancel\">Cancel</button></div></div>";
}
const tipEl = document.createElement("div");
tipEl.id = "tip";
tipEl.hidden = true;
document.body.appendChild(tipEl);
document.addEventListener("mousemove", e => {
  lastAct = Date.now();
  const n = e.target.closest && e.target.closest("[data-tip]");
  if (!n) {
    tipEl.hidden = true;
    return;
  }
  tipEl.innerHTML = n.dataset.tip;
  tipEl.hidden = false;
  const s = tipEl.offsetWidth;
  tipEl.style.left = Math.min(innerWidth - s - 8, e.clientX + 14) + "px";
  tipEl.style.top = e.clientY + 16 + "px";
});
["keydown", "click", "touchstart"].forEach(e => document.addEventListener(e, () => {
  lastAct = Date.now();
}, true));
setInterval(() => {
  const t = Number(sec().auto ?? 5);
  if (sec().hash && !locked && t > 0 && Date.now() - lastAct > t * 60000) {
    lockNow();
  }
}, 15000);
document.addEventListener("keydown", e => {
  if (isLocked()) {
    if (/^\d$/.test(e.key)) {
      pinKey(e.key);
    } else if (e.key === "Backspace") {
      pinKey("back");
    } else if (e.key === "Enter") {
      pinKey("ok");
    }
  }
});
document.addEventListener("click", async e => {
  const n = e.target.closest(".amt");
  if (n) {
    n.classList.add("show");
    setTimeout(() => n.classList.remove("show"), 5000);
    return;
  }
  if (e.target.closest("#hideBtn")) {
    state.settings.hide = !state.settings.hide;
    return persist();
  }
  if (e.target.closest("#themeBtn")) {
    state.settings.theme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    return persist();
  }
  if (e.target.closest("#lockBtn")) {
    return lockNow();
  }
  const s = e.target.closest("[data-fa]");
  if (!s) {
    return;
  }
  const a = s.dataset.fa;
  const r = s.dataset;
  switch (a) {
    case "key":
      return pinKey(r.k);
    case "forgot":
      return forgotPin();
    case "pinSave":
      return pinSave();
    case "pinOff":
      return pinOff();
    case "lockNow":
      return lockNow();
    case "goto":
      return gotoMod(r.mod);
    case "cDay":
      state.cDate = addDays(state.cDate || today(), Number(r.d));
      return render();
    case "cToday":
      state.cDate = today();
      return render();
    case "cView":
      state.cDate = r.d;
      render();
      return window.scrollTo(0, 0);
    case "cPrint":
      return printClosing(state.cDate);
    case "cPrintD":
      return printClosing(r.d);
    case "cReopen":
      if (confirm("Reopen this day for editing?")) {
        state.db.closings = rows("closings").filter(e => e.date !== state.cDate);
        await persist();
      }
      return;
    case "cClose":
      {
        const e = state.cDate;
        const n = closingNums(e);
        if (!n.counted) {
          return toast("Count the cash first (or type the total counted)", true);
        }
        if (n.diff !== 0 && !confirm((n.diff > 0 ? "Excess" : "Short") + " " + money(Math.abs(n.diff)) + ". Close the day anyway?")) {
          return;
        }
        rows("closings").push({
          id: uid(),
          date: e,
          opening: n.opening,
          cin: n.cin,
          cout: n.cout,
          expected: n.expected,
          counted: n.counted,
          den: n.den,
          currency: biz().currency || "INR",
          note: ($("#cNote") || {}).value || "",
          closedAt: new Date().toLocaleString("en-IN")
        });
        await persist();
        return toast("Day closed ✓");
      }
    case "attDay":
      {
        const e = attRec(state.attSid, state.attMonth, true);
        const n = e.d[r.day] || "";
        const s = ATT_ORDER[(ATT_ORDER.indexOf(n) + 1) % ATT_ORDER.length];
        if (s) {
          e.d[r.day] = s;
        } else {
          delete e.d[r.day];
        }
        return attSave(state.attSid);
      }
    case "attAll":
      {
        const e = attRec(state.attSid, state.attMonth, true);
        const n = state.attMonth;
        const s = today();
        const a = n < s.slice(0, 7) ? dim(n) : n === s.slice(0, 7) ? Number(s.slice(8)) : 0;
        for (let s = 1; s <= a; s++) {
          const a = pad(s);
          e.d[a] ||= new Date(Number(n.slice(0, 4)), Number(n.slice(5)) - 1, s).getDay() === 0 ? "W" : "P";
        }
        return attSave(state.attSid);
      }
    case "attSun":
      {
        const e = attRec(state.attSid, state.attMonth, true);
        const n = state.attMonth;
        for (let t = 1; t <= dim(n); t++) {
          if (new Date(Number(n.slice(0, 4)), Number(n.slice(5)) - 1, t).getDay() === 0) {
            e.d[pad(t)] = "W";
          }
        }
        return attSave(state.attSid);
      }
    case "attClear":
      if (confirm("Clear all marks for this month?")) {
        const e = attRec(state.attSid, state.attMonth);
        if (e) {
          e.d = {};
        }
        return attSave(state.attSid);
      }
      return;
    case "attOpen":
      state.attSid = r.sid;
      return render();
    case "attSlip":
      return printSlip(r.sid, state.attMonth);
    case "attPay":
      {
        const e = rows("staff").find(e => e.id === r.sid);
        const n = attRec(r.sid, state.attMonth, true);
        const s = attCalc(e, state.attMonth);
        if (n.paid) {
          state.db.ledger = rows("ledger").filter(e => e.id !== n.ledgerId);
          n.paid = "";
          n.ledgerId = "";
        } else {
          if (!s.net) {
            return toast("Net pay is 0 — nothing to pay", true);
          }
          const a = {
            id: uid(),
            created: today(),
            date: today(),
            type: "Expense",
            cat: "Salary",
            amount: s.net,
            note: "Salary " + state.attMonth + ": " + e.name
          };
          rows("ledger").push(a);
          n.paid = today();
          n.ledgerId = a.id;
        }
        return persist();
      }
    case "rstApply":
      return applyRestore();
    case "rstCancel":
      state.rst = null;
      return render();
    case "impGo":
      return doImport();
    case "impSuite":
      return importFromSuite();
    case "impCancel":
      state.imp = null;
      return render();
    case "encExport":
      return encExport();
    case "startFresh":
      return startFresh();
  }
});
document.addEventListener("input", e => {
  const n = e.target;
  if (n.dataset && n.dataset.den) {
    (state.cDen[state.cDate] = state.cDen[state.cDate] || {})[n.dataset.den] = n.value;
    liveClosing();
  } else if (n.id === "cManual") {
    state.cManual[state.cDate] = n.value;
    liveClosing();
  } else if (n.id === "cOpen") {
    state.cOpen[state.cDate] = n.value;
    liveClosing();
    const e = document.querySelector(".cards .card:first-child .v");
    if (e) {
      e.textContent = money(n.value);
    }
  }
});
document.addEventListener("change", async e => {
  const n = e.target;
  if (n.id === "cDate" && n.value) {
    state.cDate = n.value;
    return render();
  }
  if (n.id === "chRange") {
    state.chRange = Number(n.value);
    return render();
  }
  if (n.id === "attMonth" && n.value) {
    state.attMonth = n.value;
    return render();
  }
  if (n.id === "attSid") {
    state.attSid = n.value;
    return render();
  }
  if (["attBonus", "attAdv", "attDed"].includes(n.id)) {
    attRec(state.attSid, state.attMonth, true)[{
      attBonus: "bonus",
      attAdv: "adv",
      attDed: "ded"
    }[n.id]] = num(n.value);
    return attSave(state.attSid);
  }
  if (n.dataset && n.dataset.sec) {
    const e = n.value;
    state.settings.sec = {
      ...sec(),
      [n.dataset.sec]: n.dataset.sec === "hideStart" ? !!e : e
    };
    await persist();
    return toast("Saved");
  }
  if (n.id === "wtFile" && n.files.length) {
    return readImport([...n.files]);
  } else if (n.id === "restoreFile" && n.files.length) {
    return readRestore([...n.files]);
  } else if (n.name === "rstMode" && state.rst) {
    state.rst.mode = n.value;
    return render();
  } else if (n.id === "impCash") {
    state.imp.opts.cashMeaning = n.value;
    return render();
  } else if (n.id === "impInc") {
    state.imp.opts.inc = n.checked;
    return render();
  } else if (n.id === "impExp") {
    state.imp.opts.exp = n.checked;
    return render();
  } else {
    return undefined;
  }
});
