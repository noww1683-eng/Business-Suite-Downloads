"use strict";

const LIC = (() => {
  const t = typeof LICENSE_CONFIG != "undefined" && LICENSE_CONFIG || {};
  const i = chrome.storage.local;
  const n = !!t.SERVER && !!t.PUBLIC_KEY;
  const a = (t.SERVER || "").replace(/\/+$/, "");
  const s = t => Uint8Array.from(atob(t), t => t.charCodeAt(0));
  const c = (e, t = document) => t.querySelector(e);
  const l = e => String(e ?? "").replace(/[&<>"']/g, e => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;"
  })[e]);
  let o;
  let r;
  let d = "";
  let k = null;
  let G = false;
  let y = () => {};
  const p = () => {
    const i = navigator.userAgentData;
    const n = /Chrome\/(\d+)/.exec(navigator.userAgent);
    return (i && i.platform || navigator.platform) + " · Chrome " + (n ? n[1] : "?") + " · " + screen.width + "×" + screen.height;
  };
  async function g(i) {
    if (!i || !i.lease || !i.sig) {
      throw Error("bad answer");
    }
    const a = await crypto.subtle.importKey("raw", s(t.PUBLIC_KEY), {
      name: "Ed25519"
    }, false, ["verify"]);
    if (!(await crypto.subtle.verify({
      name: "Ed25519"
    }, a, s(i.sig), new TextEncoder().encode(i.lease)))) {
      throw Error("bad signature");
    }
    const c = JSON.parse(i.lease);
    if (c.fp !== d) {
      throw Error("wrong device");
    }
    return c;
  }
  async function x(t, n) {
    const c = await async function () {
      const n = {
        bytes: 0,
        counts: {}
      };
      try {
        n.bytes = await i.getBytesInUse(null);
        const e = await i.get(["db", "trackerSuiteV4"]);
        const a = e.db || {};
        n.counts = {
          sales: (a.sales || []).length,
          customers: (a.customers || []).length
        };
        const s = (e.trackerSuiteV4 || {}).businesses || [];
        n.counts.orders = s.reduce((e, i) => e + ((i.data || {}).orders || []).length, 0);
      } catch {}
      return n;
    }();
    const l = await fetch(a + "/api/" + t, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        fp: d,
        label: p(),
        ...c,
        ...n
      })
    });
    const o = await l.json().catch(() => ({}));
    if (!l.ok) {
      throw Object.assign(Error(o.error || "Server error " + l.status), {
        server: true
      });
    }
    return o;
  }
  const P = async e => {
    k = await g(e);
    await i.set({
      licLease: e,
      licClock: Date.now()
    });
    return k;
  };
  const f = (t, i = Date.now()) => Math.max(0, Number(t && t.trialEnds) - i) || 0;
  function u(e) {
    const t = Math.ceil(f(e) / 60000);
    const i = Math.floor(t / 1440);
    const n = Math.floor(t % 1440 / 60);
    const a = t % 60;
    if (z === "hi") {
      return i + " दिन " + n + " घंटे " + a + " मिनट शेष";
    } else if (z === "ar") {
      return i + " يوم " + n + " ساعة " + a + " دقيقة متبقية";
    } else {
      return i + "d " + n + "h " + a + "m left";
    }
  }
  const b = e => e && Date.now() < Number(e.validUntil) && Number(e.t) > 0 && Date.now() - Number(e.t) < 86400000 && (e.status === "licensed" || e.status === "trial" && f(e) > 0);
  function h() {
    if (!k || k.status !== "trial") {
      return;
    }
    R();
    const i = c("#trialCountdown");
    if (i) {
      i.textContent = u(k);
    }
    if (f(k) === 0 && G) {
      G = false;
      N();
      y(false);
    }
  }
  async function I(t = "heartbeat") {
    try {
      await P(await x(t));
    } catch (e) {
      if (e.server) {
        throw e;
      }
      const t = await i.get(["licLease", "licClock"]);
      let a = null;
      try {
        a = t.licLease && (await g(t.licLease));
      } catch {}
      const s = t.licClock && Date.now() < t.licClock - 600000;
      k = a && !s && Date.now() < a.validUntil ? Object.assign({}, a, {
        offline: true
      }) : {
        status: "offline",
        message: a && s ? "Your computer clock looks wrong. Fix the date/time and connect to the internet." : "Connect to the internet once to verify your license."
      };
    }
    G = b(k);
    return k;
  }
  const w = "#licGate{position:fixed;inset:0;z-index:9999;background:linear-gradient(135deg,#0b1220,#1e1b4b 60%,#0f766e);display:flex;align-items:center;justify-content:center;padding:16px;font:14px/1.45 system-ui,Segoe UI,sans-serif}\n  #licGate .lc{background:#fff;color:#14211f;border-radius:22px;max-width:440px;width:100%;padding:26px 26px 22px;box-shadow:0 30px 80px rgba(0,0,0,.45)}\n  #licGate h2{margin:0 0 4px;font-size:21px}#licGate p{margin:4px 0 14px;color:#51635f}\n  #licGate label{display:block;font-size:12px;font-weight:600;color:#3d504c;margin:10px 0 3px}\n  #licGate input{width:100%;font:inherit;padding:10px 12px;border:1.5px solid #cbd8d4;border-radius:11px;background:#f7fbfa;color:#14211f}#licGate input:focus{outline:0;border-color:#167768;background:#fff}\n  #licGate button{font:600 15px inherit;border:0;border-radius:11px;padding:11px 16px;cursor:pointer}\n  #licGate .go{width:100%;margin-top:16px;background:linear-gradient(135deg,#167768,#2563eb);color:#fff}#licGate .go:disabled{opacity:.6}\n  #licGate .x{background:#eef3f2;color:#14211f;margin-top:8px;width:100%}\n  #licGate .er{color:#d93a4a;min-height:18px;margin-top:8px;font-weight:600}#licGate .ok{color:#1b8a4b;font-weight:600}\n  #licGate .pill{display:inline-block;padding:3px 11px;border-radius:99px;font-size:12px;font-weight:700;color:#fff;background:#167768}\n  #licGate .helpbtn{display:inline-flex;align-items:center;white-space:nowrap;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:700;color:#fff!important;background:#25d366;text-decoration:none}#licGate .helpbtn:hover{background:#1ebe5a}\n  #licGate .pl{margin:12px 0 0;border:1.5px solid #cbd8d4;border-radius:12px;overflow:hidden}#licGate .pl div{display:flex;justify-content:space-between;padding:8px 12px;border-bottom:1px solid #e3ebe8}#licGate .pl div:last-child{border:0}#licGate .pl b{color:#167768}#licGate .pl h4{margin:0;padding:8px 12px;background:#eef6f4;font-size:12.5px}#licGate .pl label.pr{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:0;padding:9px 12px;border-bottom:1px solid #e3ebe8;cursor:pointer;font-size:14px;font-weight:500;color:#14211f}#licGate .pl label.pr:hover{background:#f1f8f6}#licGate .pl label.pr span{flex:1}#licGate .pl input[type=radio]{width:auto;margin:0;accent-color:#167768}#licGate .buy{width:100%;margin-top:10px;background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff}#licGate .lg{display:flex;gap:4px;flex:none}#licGate .lg button.x{width:auto;margin:0;padding:4px 9px;font-size:12px;border-radius:8px}#licGate .lg button.x.on{background:#167768;color:#fff}#licGate .okmsg{color:#1b8a4b;font-weight:600}#licGate .pl .bc{display:block;background:#f7fbfa;font-size:12px;color:#3d504c}\n  #licGate small{display:block;color:#6a7c78;margin-top:12px;font-size:11.5px}#licGate dl{margin:10px 0;display:grid;grid-template-columns:auto 1fr;gap:5px 12px}#licGate dt{color:#6a7c78}#licGate dd{margin:0;font-weight:600}\n#licGate{overflow-y:auto;-webkit-overflow-scrolling:touch;align-items:flex-start;padding:max(12px,env(safe-area-inset-top)) 12px 12px}\n#licGate .lc{margin:auto;box-sizing:border-box;max-width:460px;border-radius:24px;padding:24px 26px 20px;position:relative;overflow:hidden}\n#licGate .lc::before{content:\"\";position:absolute;left:0;right:0;top:0;height:5px;background:linear-gradient(90deg,#167768,#2563eb,#7c3aed)}\n#licGate .lc>div:first-child{padding-bottom:12px;margin-bottom:6px;border-bottom:1px solid #e3ebe8;gap:10px;flex-wrap:wrap}\n#licGate .lcols{display:block}#licGate .c1>.pill{margin-top:6px}\n#licGate .c1>p:nth-of-type(1){margin:8px 0 10px;padding:10px 12px;border-radius:12px;background:#fff7e8;color:#6b4a0a}\n#licGate .pl{box-shadow:0 4px 14px rgba(20,33,31,.06)}\n#licGate .pl label.pr{transition:background .15s,box-shadow .15s}#licGate .pl label.pr:has(input:checked){background:#e6f4f1;box-shadow:inset 3px 0 0 #167768}\n#licGate input:focus{box-shadow:0 0 0 3px rgba(22,119,104,.18)}\n#licGate .go,#licGate .buy{box-shadow:0 8px 18px rgba(37,99,235,.22);transition:transform .12s,filter .12s}#licGate .go:hover,#licGate .buy:hover{filter:brightness(1.06)}#licGate .go:active,#licGate .buy:active{transform:scale(.985)}\n#licGate .lg button.x{white-space:nowrap}\n@media (min-width:760px) and (min-aspect-ratio:1/1){\n#licGate .lc:has(.c2 input){max-width:900px;padding:26px 32px 20px}\n#licGate .lc:has(.c2 input) .lcols{display:grid;grid-template-columns:1fr 1fr;gap:0 34px;align-items:start}\n#licGate .lc:has(.c2 input) .c2{padding-left:34px;border-left:1px solid #e3ebe8}\n#licGate .lc:has(.c2 input) .c2>label:first-child{margin-top:0}\n#licGate .lc:has(.c2 input) #lclose{display:block;width:auto;min-width:200px;margin:14px auto 0}\n}\n@media (max-height:600px){\n#licGate{padding:8px}#licGate .lc{padding:16px 20px 14px;border-radius:18px}#licGate h2{font-size:18px}#licGate .go{margin-top:12px}#licGate small{margin-top:8px}\n#licGate input{padding:8px 11px}#licGate button{padding:9px 14px}\n}\n@media (max-width:420px){#licGate{padding:8px}#licGate .lc{padding:20px 16px 16px;border-radius:18px}#licGate h2{font-size:18px}#licGate .lg button.x{padding:4px 7px}}\n";
  let z = "en";
  const K = [["en", "English"], ["hi", "हिन्दी"], ["ar", "العربية"]];
  const m = {
    en: 0,
    hi: 1,
    ar: 2
  };
  const L = {
    title: ["Business Suite", "बिज़नेस सुइट", "بيزنس سويت"],
    licensed: ["Licensed", "लाइसेंस सक्रिय", "الترخيص مفعّل"],
    trial: ["Free trial", "निःशुल्क ट्रायल", "تجربة مجانية"],
    client: ["Client", "ग्राहक", "العميل"],
    key: ["Key", "कुंजी", "المفتاح"],
    valid: ["Valid", "वैधता", "الصلاحية"],
    reg: ["Registered to", "पंजीकृत", "مسجّل باسم"],
    until: ["until ", "तक: ", "حتى "],
    life: ["Lifetime", "आजीवन", "مدى الحياة"],
    offline: ["Offline — last verified answer in use.", "ऑफ़लाइन — पिछली सत्यापित जानकारी उपयोग में है।", "غير متصل — يتم استخدام آخر تحقق ناجح."],
    ends: ["ends", "समाप्ति", "ينتهي"],
    haveKey: ["Have a key? Activate below.", "कुंजी है? नीचे सक्रिय करें।", "لديك مفتاح؟ فعّله أدناه."],
    ln: ["Name", "नाम", "الاسم"],
    lk: ["License key", "लाइसेंस कुंजी", "مفتاح الترخيص"],
    le: ["Gmail / email", "जीमेल / ईमेल", "جيميل / البريد الإلكتروني"],
    lp: ["Phone number", "फ़ोन नंबर", "رقم الهاتف"],
    go: ["Activate", "सक्रिय करें", "تفعيل"],
    retry: ["Try again", "फिर से प्रयास करें", "حاول مرة أخرى"],
    close: ["Close", "बंद करें", "إغلاق"],
    checking: ["Checking…", "जाँच हो रही है…", "جارٍ التحقق…"],
    plans: ["⭐ Premium plans", "⭐ प्रीमियम प्लान", "⭐ باقات بريميوم"],
    buy: ["To buy a key: ", "कुंजी खरीदने के लिए: ", "لشراء مفتاح: "],
    need: ["License required.", "लाइसेंस आवश्यक है।", "الترخيص مطلوب."],
    noNet: ["Cannot reach the license server. Check your internet.", "लाइसेंस सर्वर से संपर्क नहीं हो पा रहा। इंटरनेट जाँचें।", "تعذّر الاتصال بخادم الترخيص. تحقق من اتصال الإنترنت."],
    note: ["Use the same Gmail and phone each time for this key. This device is recognised by an anonymous fingerprint, so reinstalling the extension or changing Gmail does not give a new trial. Only license details and data size numbers are sent to the license server — never your business data.", "इस कुंजी के लिए हर बार वही जीमेल और फ़ोन नंबर इस्तेमाल करें। यह डिवाइस एक गुमनाम फ़िंगरप्रिंट से पहचाना जाता है, इसलिए एक्सटेंशन दोबारा इंस्टॉल करने या जीमेल बदलने से नया ट्रायल नहीं मिलता। लाइसेंस सर्वर को केवल लाइसेंस विवरण और डेटा का आकार भेजा जाता है — आपका बिज़नेस डेटा कभी नहीं।", "استخدم نفس جيميل ورقم الهاتف في كل مرة مع هذا المفتاح. يتم التعرّف على هذا الجهاز ببصمة مجهولة، لذلك لا تمنحك إعادة تثبيت الإضافة أو تغيير جيميل تجربة جديدة. يُرسل إلى خادم الترخيص تفاصيل الترخيص وحجم البيانات فقط — وليس بيانات عملك أبدًا."],
    buy2: ["Buy now", "अभी खरीदें", "اشترِ الآن"],
    renew: ["Renew", "नवीनीकरण करें", "تجديد"],
    pick: ["Choose a plan first.", "पहले एक प्लान चुनें।", "اختر باقة أولاً."],
    paying: ["Payment page opened in a new tab. Complete the payment — this activates automatically.", "भुगतान पेज नए टैब में खुल गया है। भुगतान पूरा करें — यह अपने आप सक्रिय हो जाएगा।", "تم فتح صفحة الدفع في تبويب جديد. أكمل الدفع — سيتم التفعيل تلقائيًا."],
    renewHint: ["Renew your plan (time is added after your current end date):", "अपना प्लान नवीनीकृत करें (समय मौजूदा समाप्ति तिथि के बाद जुड़ेगा):", "جدّد باقتك (تُضاف المدة بعد تاريخ الانتهاء الحالي):"],
    badgeTrial: ["Trial ", "ट्रायल ", "تجربة "],
    badgeLic: ["Licensed", "लाइसेंस", "مرخّص"],
    badgeKey: ["License", "लाइसेंस", "ترخيص"]
  };
  const v = e => L[e][m[z]];
  const M = {
    hi: {
      m1: "1 महीना",
      m3: "3 महीने",
      m6: "6 महीने",
      y1: "1 साल"
    },
    ar: {
      m1: "شهر واحد",
      m3: "3 أشهر",
      m6: "6 أشهر",
      y1: "سنة واحدة"
    }
  };
  const D = {
    hi: "प्रीमियम ",
    ar: "بريميوم · "
  };
  const C = t => z === "en" ? t.label : D[z] + (M[z][t.id] || t.label);
  const U = (t, i) => {
    const a = (t.plans || []).find(e => e.label === i);
    if (a) {
      return C(a);
    } else {
      return i;
    }
  };
  const B = [[/device (has been )?blocked|is blocked/i, "यह डिवाइस ब्लॉक कर दिया गया है। अपने प्रदाता से संपर्क करें।", "تم حظر هذا الجهاز. تواصل مع المزوّد."], [/deactivated/i, "यह लाइसेंस निष्क्रिय कर दिया गया है। अपने प्रदाता से संपर्क करें।", "تم إيقاف هذا الترخيص. تواصل مع مزوّد الخدمة."], [/trial has ended/i, "आपका निःशुल्क ट्रायल समाप्त हो गया है। जारी रखने के लिए लाइसेंस कुंजी दर्ज करें।", "انتهت تجربتك المجانية. أدخل مفتاح ترخيص للمتابعة."], [/has expired/i, "लाइसेंस की अवधि समाप्त हो गई है। नई कुंजी दर्ज करें।", "انتهت صلاحية الترخيص. أدخل مفتاحًا جديدًا."], [/not found/i, "लाइसेंस कुंजी नहीं मिली।", "لم يتم العثور على مفتاح الترخيص."], [/different Gmail/i, "यह कुंजी किसी अन्य जीमेल / फ़ोन नंबर से पंजीकृत है। पहली बार वाली जानकारी ही इस्तेमाल करें।", "هذا المفتاح مسجّل بجيميل / هاتف مختلف. استخدم نفس البيانات التي فعّلت بها أول مرة."], [/Device limit/i, "डिवाइस की सीमा पूरी हो गई। प्रदाता से एक स्लॉट खाली करने को कहें।", "تم بلوغ حد الأجهزة. اطلب من المزوّد تحرير مكان."], [/already registered with another/i, "यह डिवाइस किसी अन्य लाइसेंस से पंजीकृत है। प्रदाता से संपर्क करें।", "هذا الجهاز مسجّل بترخيص آخر. تواصل مع المزوّد."], [/valid Gmail/i, "सही जीमेल / ईमेल दर्ज करें।", "أدخل عنوان جيميل / بريد إلكتروني صحيحًا."], [/valid phone/i, "सही फ़ोन नंबर दर्ज करें।", "أدخل رقم هاتف صحيحًا."], [/Too many/i, "बहुत अधिक प्रयास। कुछ देर बाद फिर कोशिश करें।", "محاولات كثيرة جدًا. حاول لاحقًا."], [/clock looks wrong/i, "आपके कंप्यूटर की घड़ी गलत लग रही है। दिनांक/समय ठीक करें और इंटरनेट से जुड़ें।", "يبدو أن ساعة الحاسوب غير صحيحة. صحّح التاريخ والوقت واتصل بالإنترنت."], [/Connect to the internet/i, "लाइसेंस सत्यापित करने के लिए एक बार इंटरनेट से जुड़ें।", "اتصل بالإنترنت مرة واحدة للتحقق من الترخيص."], [/not set up/i, "ऑनलाइन भुगतान अभी सेट नहीं है। प्रदाता से संपर्क करें।", "الدفع الإلكتروني غير مفعّل بعد. تواصل مع المزوّد."], [/already has a license/i, "इस डिवाइस पर लाइसेंस है। नवीनीकरण के लिए \"नवीनीकरण करें\" का उपयोग करें।", "هذا الجهاز لديه ترخيص بالفعل. استخدم زر التجديد."], [/gateway error/i, "भुगतान गेटवे में त्रुटि। फिर कोशिश करें।", "خطأ في بوابة الدفع. حاول مرة أخرى."]];
  const H = t => z === "en" ? t : (B.find(([e]) => e.test(t)) || [])[m[z]] || t;
  function N(t) {
    let s = c("#licGate");
    if (!s) {
      const e = document.createElement("style");
      e.textContent = w;
      document.head.appendChild(e);
      s = document.createElement("div");
      s.id = "licGate";
      document.body.appendChild(s);
    }
    const o = k || {};
    const r = !G;
    const d = e => e ? new Date(e).toLocaleDateString(z === "hi" ? "hi-IN" : z === "ar" ? "ar" : [], {
      dateStyle: "medium"
    }) : "";
    let y = "";
    y = o.status === "licensed" ? "<span class=\"pill\">" + v("licensed") + "</span><dl><dt>" + v("client") + "</dt><dd>" + l(o.client || "—") + "</dd><dt>" + v("key") + "</dt><dd>" + l(o.key || "") + "</dd><dt>" + v("valid") + "</dt><dd>" + ((o.plan ? l(U(o, o.plan)) + " · " : "") + (o.expiresAt ? v("until") + d(o.expiresAt) : v("life"))) + "</dd><dt>" + v("reg") + "</dt><dd>" + l(o.email || "") + "</dd></dl>" + (o.offline ? "<p>" + v("offline") + "</p>" : "") : o.status === "trial" ? "<span class=\"pill\" style=\"background:#b86e00\">" + v("trial") + "</span><p><b id=\"trialCountdown\">" + u(o) + "</b> (" + v("ends") + " " + d(o.trialEnds) + "). " + v("haveKey") + "</p>" : "<p class=\"er\" style=\"margin-top:0\">" + l(o.message ? H(o.message) : v("need")) + "</p>";
    const p = !!o.canBuy && (o.status !== "licensed" || !!o.expiresAt) && o.status !== "offline";
    const g = Array.isArray(o.plans) && o.plans.length && (o.status !== "licensed" || p) ? (o.status === "licensed" ? "<p style=\"margin:12px 0 0\">" + v("renewHint") + "</p>" : "") + "<div class=\"pl\"><h4>" + v("plans") + "</h4>" + o.plans.map(e => p ? "<label class=\"pr\"><input type=\"radio\" name=\"lpp\" value=\"" + l(e.id) + "\"><span>" + l(C(e)) + "</span><b>₹" + l(e.price) + "</b></label>" : "<div><span>" + l(C(e)) + "</span><b>₹" + l(e.price) + "</b></div>").join("") + (o.contact && o.status !== "licensed" ? "<div class=\"bc\"><span>" + v("buy") + l(o.contact) + "</span></div>" : "") + "</div>" + (p ? "<button class=\"go buy\" id=\"lbuy\">" + (o.status === "licensed" ? v("renew") : v("buy2")) + "</button>" : "") : "";
    const f = o.status === "licensed" ? "" : "<label>" + v("ln") + "</label><input id=\"ln\" placeholder=\"Your name\" autocomplete=\"name\" maxlength=\"80\"><label>" + v("lk") + "</label><input id=\"lk\" placeholder=\"BS-XXXX-XXXX-XXXX-XXXX\" autocomplete=\"off\" spellcheck=\"false\">\n      <label>" + v("le") + "</label><input id=\"le\" type=\"email\" placeholder=\"you@gmail.com\" autocomplete=\"email\"><label>" + v("lp") + "</label><input id=\"lp\" type=\"tel\" placeholder=\"+91 98765 43210\" autocomplete=\"tel\">\n      <button class=\"go\" id=\"lgo\">" + v("go") + "</button>";
    s.innerHTML = "<div class=\"lc\"><div style=\"display:flex;justify-content:space-between;align-items:center\"><h2 style=\"display:flex;align-items:center;gap:10px\"><img src=\"logo.png\" alt=\"\" style=\"width:36px;height:36px\">" + v("title") + "</h2><div class=\"lg\">" + K.map(([e, t]) => "<button class=\"x" + (e === z ? " on" : "") + "\" data-l=\"" + e + "\">" + t + "</button>").join("") + "<a class=\"helpbtn\" href=\"https://wa.me/917736882381?text=Hi%2C%20I%20need%20help%20with%20Business%20Suite\" target=\"_blank\" rel=\"noopener\">💬 Help</a></div></div><div class=\"lcols\"><div class=\"c1\">" + (r || o.status ? y + g : "") + "</div><div class=\"c2\">" + (o.status === "offline" ? "<button class=\"go\" id=\"lretry\">" + v("retry") + "</button>" : f) + "<div class=\"er\" id=\"lerr\"></div>\n      </div></div>" + (!r || t ? "<button class=\"x\" id=\"lclose\">" + v("close") + "</button>" : "") + "\n      <small>" + v("note") + "</small></div>";
    const h = e => c("#lerr", s).textContent = e;
    s.querySelectorAll(".lg button").forEach(e => e.onclick = async () => {
      z = e.dataset.l;
      try {
        await i.set({
          licLang: z
        });
      } catch {}
      const c = s.dataset.info;
      N(t);
      if (c) {
        s.dataset.info = c;
      }
      R();
    });
    if (c("#lclose", s)) {
      c("#lclose", s).onclick = () => {
        clearInterval(S);
        s.remove();
      };
    }
    if (c("#lbuy", s)) {
      c("#lbuy", s).onclick = async () => {
        const t = (s.querySelector("input[name=lpp]:checked") || {}).value;
        if (!t) {
          return h(v("pick"));
        }
        const i = c("#lbuy", s);
        i.disabled = true;
        h("");
        try {
          const i = await x("order", {
            name: ((c("#ln", s) || {}).value || "").trim(),
            plan: t,
            renew: o.status === "licensed",
            email: c("#le", s) ? c("#le", s).value : "",
            phone: c("#lp", s) ? c("#lp", s).value : ""
          });
          window.open(a + i.payUrl, "_blank");
          const n = c("#lerr", s);
          n.className = "er okmsg";
          n.textContent = v("paying");
          (function (e) {
            clearInterval(S);
            const t = Date.now();
            S = setInterval(async () => {
              if (Date.now() - t > 1800000) {
                return clearInterval(S);
              }
              try {
                const t = await x("orderStatus", {
                  order: e
                });
                if (t && t.lease) {
                  clearInterval(S);
                  await P(t);
                  G = b(k);
                  J();
                } else if (t && t.status === "error") {
                  clearInterval(S);
                }
              } catch (e) {
                if (e.server) {
                  clearInterval(S);
                  const t = c("#lerr");
                  if (t) {
                    t.className = "er";
                    t.textContent = H(e.message);
                  }
                }
              }
            }, 4000);
          })(i.order);
        } catch (t) {
          h(t.server ? H(t.message) : v("noNet"));
        }
        i.disabled = false;
      };
    }
    if (c("#lretry", s)) {
      c("#lretry", s).onclick = async () => {
        h(v("checking"));
        await I("status");
        J();
      };
    }
    if (c("#lgo", s)) {
      c("#lgo", s).onclick = async () => {
        const t = c("#lgo", s);
        t.disabled = true;
        h("");
        try {
          await P(await x("activate", {
            name: ((c("#ln", s) || {}).value || "").trim(),
            key: c("#lk", s).value,
            email: c("#le", s).value,
            phone: c("#lp", s).value
          }));
          G = b(k);
          J();
        } catch (e) {
          h(e.server ? H(e.message) : v("noNet"));
          t.disabled = false;
        }
      };
    }
    s.dir = z === "ar" ? "rtl" : "ltr";
    s.hidden = false;
  }
  let S;
  function J() {
    if (G) {
      const e = c("#licGate");
      if (e) {
        if (e.dataset.info) {
          N(true);
          c("#licGate").dataset.info = "1";
        } else {
          e.remove();
        }
      }
    } else {
      N();
    }
    R();
    y(G);
  }
  function R() {
    const i = c("#licBtn");
    if (!i) {
      return;
    }
    const a = k || {};
    i.hidden = !n;
    c("b", i).textContent = a.status === "trial" ? "" + v("badgeTrial") + u(a) : a.status === "licensed" ? v("badgeLic") : v("badgeKey");
    i.classList.toggle("warn", a.status === "trial");
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      h();
    }
  });
  window.addEventListener("focus", h);
  return {
    start: async function (t) {
      y = t || y;
      if (!n) {
        k = {
          status: "offline",
          message: "License server is not configured."
        };
        G = false;
        N();
        R();
        y(false);
        return false;
      }
      d = await BS_FP();
      try {
        const e = await i.get("licLang");
        if (m[e.licLang] !== undefined) {
          z = e.licLang;
        }
      } catch {}
      const s = await i.get("licLease");
      k = null;
      await I(s.licLease ? "heartbeat" : "status");
      R();
      if (!G) {
        N();
      }
      y(G);
      clearInterval(r);
      r = setInterval(h, 30000);
      clearInterval(o);
      o = setInterval(async () => {
        try {
          await I();
          h();
          R();
          if (!G) {
            N();
          }
          y(G);
        } catch {
          h();
        }
      }, 300000);
      return G;
    },
    enabled: n,
    get ok() {
      return G;
    },
    has(t) {
      const a = k;
      return !!n && !!G && !!a && Array.isArray(a.modules) && a.modules.includes(t);
    },
    get pkg() {
      return k && k.pkg || "";
    },
    async info() {
      if (!n) {
        return;
      }
      try {
        await I("heartbeat");
      } catch {}
      N(true);
      c("#licGate").dataset.info = "1";
    }
  };
})();
