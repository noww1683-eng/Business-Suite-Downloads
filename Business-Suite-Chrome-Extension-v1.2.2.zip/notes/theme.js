try {
  chrome.storage.local.get("settings").then(e => {
    const s = (e.settings || {}).theme;
    if (s) {
      document.documentElement.dataset.theme = s;
    }
  });
  chrome.storage.onChanged.addListener(e => {
    if (e.settings && e.settings.newValue && e.settings.newValue.theme) {
      document.documentElement.dataset.theme = e.settings.newValue.theme;
    }
  });
} catch (e) {}
