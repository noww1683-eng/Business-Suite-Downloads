"use strict";

const KEY = "bsNotes";
const store = chrome.storage.local;
const $ = t => document.getElementById(t);
let mt;
let notes = [];
const todayStr = () => {
  const e = new Date();
  const s = e => String(e).padStart(2, "0");
  return e.getFullYear() + "-" + s(e.getMonth() + 1) + "-" + s(e.getDate());
};
const esc = t => String(t ?? "").replace(/[&<>"']/g, t => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "\"": "&quot;",
  "'": "&#39;"
})[t]);
const fmt = t => {
  try {
    return new Date(t + "T00:00:00").toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  } catch {
    return t;
  }
};
const say = t => {
  const e = $("msg");
  e.textContent = t;
  clearTimeout(mt);
  mt = setTimeout(() => {
    e.textContent = "";
  }, 3500);
};
const persist = () => store.set({
  [KEY]: notes
});
function categories() {
  return [...new Set(notes.map(e => e.category).filter(Boolean))].sort();
}
function refreshCategories() {
  const e = categories();
  const s = $("filter").value;
  $("cats").innerHTML = e.map(e => "<option value=\"" + esc(e) + "\">").join("");
  $("filter").innerHTML = "<option value=\"\">All categories</option>" + e.map(t => "<option value=\"" + esc(t) + "\">" + esc(t) + "</option>").join("");
  $("filter").value = e.includes(s) ? s : "";
}
function render() {
  refreshCategories();
  $("count").textContent = notes.length + (notes.length === 1 ? " note" : " notes");
  const e = $("search").value.trim().toLowerCase();
  const s = $("filter").value;
  const n = notes.filter(n => (!s || n.category === s) && (!e || (n.title + " " + n.body + " " + n.category).toLowerCase().includes(e))).sort((e, s) => s.date.localeCompare(e.date) || s.id - e.id);
  $("list").innerHTML = n.length ? n.map(e => "\n    <div class=\"card note\">\n      <h3>" + esc(e.title) + "</h3>\n      <div class=\"meta\"><span>" + esc(fmt(e.date)) + "</span>" + (e.category ? "<span class=\"tag\">" + esc(e.category) + "</span>" : "") + "</div>\n      " + (e.body ? "<p class=\"body\">" + esc(e.body) + "</p>" : "") + "\n      <div class=\"actions\">\n        <button data-edit=\"" + e.id + "\">Edit</button>\n        <button class=\"danger\" data-del=\"" + e.id + "\">Delete</button>\n      </div>\n    </div>").join("") : "<div class=\"card empty\">" + (notes.length ? "No matching notes." : "No notes yet. Add your first note above.") + "</div>";
}
function resetForm() {
  $("editId").value = "";
  $("title").value = "";
  $("body").value = "";
  $("category").value = "";
  $("date").value = todayStr();
  $("formTitle").textContent = "New note";
  $("saveBtn").textContent = "Add note";
  $("cancelBtn").hidden = true;
}
async function save() {
  const e = $("title").value.trim();
  if (!e) {
    say("Please enter a title.");
    $("title").focus();
    return;
  }
  const s = {
    title: e,
    date: $("date").value || todayStr(),
    category: $("category").value.trim(),
    body: $("body").value.trim()
  };
  const n = $("editId").value;
  if (n) {
    const e = notes.find(t => String(t.id) === n);
    if (e) {
      Object.assign(e, s);
    }
  } else {
    notes.push({
      id: Date.now(),
      ...s
    });
  }
  await persist();
  resetForm();
  render();
  say("Saved");
}
function edit(t) {
  const s = notes.find(e => e.id === t);
  if (s) {
    $("editId").value = s.id;
    $("title").value = s.title;
    $("date").value = s.date;
    $("category").value = s.category || "";
    $("body").value = s.body || "";
    $("formTitle").textContent = "Edit note";
    $("saveBtn").textContent = "Save changes";
    $("cancelBtn").hidden = false;
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }
}
async function del(t) {
  if (confirm("Delete this note?")) {
    notes = notes.filter(e => e.id !== t);
    await persist();
    render();
    say("Deleted");
  }
}
function clean(t) {
  return t.filter(t => t && typeof t.title == "string").map((t, s) => ({
    id: Number(t.id) || Date.now() + s,
    title: t.title,
    date: /^\d{4}-\d{2}-\d{2}$/.test(t.date || "") ? t.date : todayStr(),
    category: String(t.category || ""),
    body: String(t.body || "")
  }));
}
$("saveBtn").addEventListener("click", save);
$("cancelBtn").addEventListener("click", resetForm);
$("search").addEventListener("input", render);
$("filter").addEventListener("change", render);
$("list").addEventListener("click", t => {
  const s = t.target.closest("button");
  if (s) {
    if (s.dataset.edit) {
      edit(Number(s.dataset.edit));
    } else if (s.dataset.del) {
      del(Number(s.dataset.del));
    }
  }
});
$("exportBtn").addEventListener("click", () => {
  const e = document.createElement("a");
  e.href = URL.createObjectURL(new Blob([JSON.stringify(notes, null, 2)], {
    type: "application/json"
  }));
  e.download = "business-notes-backup-" + todayStr() + ".json";
  e.click();
  setTimeout(() => URL.revokeObjectURL(e.href), 2000);
});
$("importBtn").addEventListener("click", () => $("importFile").click());
$("importFile").addEventListener("change", t => {
  const s = t.target.files[0];
  if (!s) {
    return;
  }
  const n = new FileReader();
  n.onload = async () => {
    try {
      const e = JSON.parse(n.result);
      if (!Array.isArray(e)) {
        throw 0;
      }
      const s = clean(e);
      if (confirm("Replace your current notes with " + s.length + " note(s) from this file?")) {
        notes = s;
        await persist();
        render();
        say("Backup restored");
      }
    } catch {
      say("That is not a valid backup file.");
    }
  };
  n.readAsText(s);
  t.target.value = "";
});
chrome.storage.onChanged.addListener((t, e) => {
  if (e === "local" && t[KEY]) {
    notes = t[KEY].newValue || [];
    render();
  }
});
(async () => {
  const t = await store.get(KEY);
  notes = Array.isArray(t[KEY]) ? t[KEY] : [];
  resetForm();
  render();
})();
