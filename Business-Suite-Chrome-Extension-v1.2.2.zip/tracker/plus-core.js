"use strict";

const Plus = (() => {
  const r = Core.reminders;
  function t(r) {
    (r = structuredClone(r)).schemaVersion = 4;
    for (const e of ["leads", "packages", "invoiceDrafts", "timeLogs", "paymentAudit"]) {
      r[e] ??= [];
    }
    r.runningTimer ??= null;
    for (const e of r.orders) {
      e.tasks ??= [];
    }
    for (const e of r.services) {
      e.autoInvoice ??= false;
      e.nextInvoiceDate ??= e.nextDate;
      e.invoiceAnchor ??= e.anchorDay;
      e.invoiceCycles ??= [];
      e.invoiceDueDays ??= 7;
    }
    return r;
  }
  function o(r) {
    Core.validate(r);
    const o = e => {
      throw Error(e || "Invalid v4 workspace.");
    };
    const n = e => typeof e == "string" && e.length <= 20000;
    const s = e => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1000000000000;
    const i = (e, t) => r[e].some(e => e.id === t);
    const a = ["leads", "packages", "invoiceDrafts", "timeLogs", "paymentAudit"];
    if (r.schemaVersion !== 4) {
      o();
    }
    for (const e of a) {
      if (!Array.isArray(r[e]) || r[e].length > 100000) {
        o();
      }
      const s = new Set();
      for (const i of r[e]) {
        if (!i || !n(i.id) || !i.id || !!s.has(i.id)) {
          o();
        }
        s.add(i.id);
      }
    }
    for (const e of r.leads) {
      if (!["name", "phone", "email", "source", "note", "customerId"].every(r => n(e[r])) || !e.name.trim() || !Core.date(e.date) || e.followup !== "" && !Core.date(e.followup) || !["new", "contacted", "interested", "won", "lost"].includes(e.stage) || !!e.customerId && !i("customers", e.customerId)) {
        o("Invalid lead details.");
      }
    }
    for (const e of r.packages) {
      if (!n(e.name) || !e.name.trim() || !n(e.description) || !n(e.checklist) || ![e.price, e.cost].every(s)) {
        o("Invalid service package.");
      }
    }
    for (const e of r.services) {
      if (typeof e.autoInvoice !== "boolean" || !Core.date(e.nextInvoiceDate) || !Number.isInteger(e.invoiceAnchor) || e.invoiceAnchor < 1 || e.invoiceAnchor > 31 || !Array.isArray(e.invoiceCycles) || new Set(e.invoiceCycles).size !== e.invoiceCycles.length || e.invoiceCycles.some(e => !Core.date(e)) || !Number.isInteger(e.invoiceDueDays) || e.invoiceDueDays < 0 || e.invoiceDueDays > 90) {
        o("Invalid recurring invoice settings.");
      }
    }
    for (const e of r.orders) {
      if (!Array.isArray(e.tasks) || e.tasks.length > 500) {
        o();
      }
      const r = new Set();
      for (const s of e.tasks) {
        if (!n(s.id) || !!r.has(s.id) || !n(s.text) || !s.text.trim() || typeof s.done != "boolean") {
          o();
        }
        r.add(s.id);
      }
    }
    const c = new Set();
    for (const e of r.invoiceDrafts) {
      if (!i("services", e.serviceId) || !i("customers", e.customerId) || !n(e.description) || !Core.date(e.cycle) || !Core.date(e.due) || !s(e.amount) || !["draft", "issued", "discarded"].includes(e.status) || !n(e.orderId) || !!e.orderId && !i("orders", e.orderId)) {
        o("Invalid invoice draft.");
      }
      const r = e.serviceId + ":" + e.cycle;
      if (c.has(r)) {
        o("Duplicate recurring invoice cycle.");
      }
      c.add(r);
    }
    for (const e of r.timeLogs) {
      if (!i("orders", e.orderId) || !Core.date(e.date) || !s(e.seconds) || !!(e.seconds > 31536000) || !n(e.note)) {
        o("Invalid time entry.");
      }
    }
    if (!!r.runningTimer && (!i("orders", r.runningTimer.orderId) || !n(r.runningTimer.id) || !Number.isFinite(r.runningTimer.started) || !!(r.runningTimer.started < 0) || !n(r.runningTimer.note))) {
      o("Invalid running timer.");
    }
    for (const e of r.paymentAudit) {
      if (!i("orders", e.orderId) || !n(e.paymentId) || !n(e.reason) || !e.reason.trim() || !n(e.at) || !!isNaN(Date.parse(e.at)) || !["correct", "void", "undo"].includes(e.action)) {
        o("Invalid payment audit.");
      }
      for (const r of [e.before, e.after]) {
        if (r !== null && (!r || r.id !== e.paymentId || !Core.date(r.date) || !s(r.amount) || !!(r.amount <= 0) || !n(r.method) || !n(r.note))) {
          o("Invalid audit values.");
        }
      }
    }
    return r;
  }
  function n(r) {
    const o = {
      app: "work-tracker-suite",
      version: 4,
      revision: 0,
      activeId: "business-" + Core.id(),
      businesses: []
    };
    o.businesses = [{
      id: o.activeId,
      data: t(r)
    }];
    return s(o);
  }
  function s(r) {
    if (!r || r.app !== "work-tracker-suite" || r.version !== 4 || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.businesses) || !r.businesses.length || r.businesses.length > 30 || !r.businesses.some(e => e.id === r.activeId)) {
      throw Error("Invalid multi-business backup.");
    }
    const n = new Set();
    for (const e of r.businesses) {
      if (typeof e.id !== "string" || !e.id || n.has(e.id)) {
        throw Error("Invalid business identity.");
      }
      n.add(e.id);
      o(e.data);
    }
    return r;
  }
  function i(r, t, n, s, i, a = "correct") {
    if (!i.trim()) {
      throw Error("Enter a reason for the audit history.");
    }
    const d = r.orders.find(e => e.id === t);
    if (!d) {
      throw Error("Order not found.");
    }
    const u = d.payments.findIndex(e => e.id === n);
    const f = u < 0 ? null : structuredClone(d.payments[u]);
    if (u < 0 && a !== "undo") {
      throw Error("Payment no longer exists.");
    }
    if (s) {
      s = {
        ...s,
        id: n
      };
      if (u < 0) {
        d.payments.push(s);
      } else {
        d.payments[u] = s;
      }
    } else if (u >= 0) {
      d.payments.splice(u, 1);
    }
    Core.validate(r);
    r.paymentAudit.push({
      id: Core.id(),
      orderId: t,
      paymentId: n,
      action: a,
      at: new Date().toISOString(),
      before: f,
      after: s ? structuredClone(s) : null,
      reason: i
    });
    o(r);
  }
  return {
    reminders: function (t, o = Core.today()) {
      return r(t, o).concat((t.leads || []).filter(e => e.followup && e.followup <= Core.addDays(o, t.preferences.reminderDays) && !["won", "lost"].includes(e.stage)).map(e => ({
        type: "Follow-up",
        date: e.followup,
        label: e.name,
        id: e.id,
        target: "leads"
      }))).sort((e, r) => e.date.localeCompare(r.date));
    },
    upgrade: t,
    fresh: function () {
      return t(Core.fresh());
    },
    validate: o,
    wrap: n,
    validateSuite: s,
    migrate: function (r) {
      if (r?.app === "work-tracker-suite") {
        return s(structuredClone(r));
      } else {
        return n(Core.migrate(r));
      }
    },
    generate: function (r, t = Core.today()) {
      let n = 0;
      for (const e of r.services) {
        if (!e.active || !e.autoInvoice) {
          continue;
        }
        let s = 0;
        while (e.nextInvoiceDate <= t && s++ < 24) {
          const t = e.nextInvoiceDate;
          if (!e.invoiceCycles.includes(t)) {
            r.invoiceDrafts.push({
              id: Core.id(),
              serviceId: e.id,
              customerId: e.customerId,
              description: e.name + " · " + t,
              cycle: t,
              due: Core.addDays(t, e.invoiceDueDays),
              amount: e.amount,
              status: "draft",
              orderId: ""
            });
            e.invoiceCycles.push(t);
            n++;
          }
          e.nextInvoiceDate = Core.addMonths(t, e.interval, e.invoiceAnchor);
        }
      }
      return n;
    },
    issue: function (r, t) {
      const n = r.invoiceDrafts.find(e => e.id === t);
      if (!n || n.status !== "draft") {
        throw Error("Draft already issued or discarded.");
      }
      const s = {
        id: Core.id(),
        number: Core.number(r, "INV"),
        customerId: n.customerId,
        description: n.description,
        date: n.cycle,
        due: n.due,
        deadline: "",
        finishDate: "",
        status: "new",
        note: "Recurring service billing cycle: " + n.cycle,
        items: [{
          id: Core.id(),
          productId: "",
          description: n.description,
          quantity: 1,
          price: n.amount,
          cost: 0
        }],
        discountType: "fixed",
        discount: 0,
        taxRate: 0,
        payments: [],
        returns: [],
        refunds: [],
        attachments: [],
        sourceQuote: "",
        tasks: []
      };
      Core.saveOrder(r, s);
      n.status = "issued";
      n.orderId = s.id;
      return s.id;
    },
    correctPayment: i,
    undo: function (r, t, o) {
      const s = r.paymentAudit.find(e => e.id === t);
      if (!s) {
        throw Error("Audit event missing.");
      }
      if ([...r.paymentAudit].reverse().find(e => e.paymentId === s.paymentId && e.orderId === s.orderId).id !== t) {
        throw Error("Undo the latest change for this payment first.");
      }
      const a = r.orders.find(e => e.id === s.orderId).payments.find(e => e.id === s.paymentId) || null;
      if (JSON.stringify(a) !== JSON.stringify(s.after)) {
        throw Error("Payment has changed since this audit event.");
      }
      i(r, s.orderId, s.paymentId, s.before, o, "undo");
    },
    stopTimer: function (r, t = Date.now()) {
      const s = r.runningTimer;
      if (!s) {
        throw Error("No timer is running.");
      }
      const i = Math.max(1, Math.round((t - s.started) / 1000));
      r.timeLogs.push({
        id: Core.id(),
        orderId: s.orderId,
        date: new Date(s.started).getFullYear() + "-" + String(new Date(s.started).getMonth() + 1).padStart(2, "0") + "-" + String(new Date(s.started).getDate()).padStart(2, "0"),
        seconds: i,
        note: s.note
      });
      r.runningTimer = null;
      o(r);
    },
    rangeStats: function (r, t = "", o = "9999-12-31") {
      const s = e => e >= t && e <= o;
      const i = structuredClone(r);
      i.orders = i.orders.map(e => ({
        ...e,
        date: s(e.date) ? "2000-01-01" : "9999-01-01",
        payments: e.payments.filter(e => s(e.date)).map(e => ({
          ...e,
          date: "2000-01-01"
        })),
        refunds: e.refunds.filter(e => s(e.date)).map(e => ({
          ...e,
          date: "2000-01-01"
        })),
        returns: e.returns.filter(e => s(e.date)).map(e => ({
          ...e,
          date: "2000-01-01"
        }))
      }));
      i.expenses = i.expenses.filter(e => s(e.date)).map(e => ({
        ...e,
        date: "2000-01-01"
      }));
      i.customers = i.customers.filter(e => s(e.date)).map(e => ({
        ...e,
        date: "2000-01-01"
      }));
      const a = Core.stats(i, "2000");
      a.pending = Core.sum(r.orders.filter(e => s(e.date)), e => Math.max(0, Core.balance(e)));
      a.owed = Core.sum(r.orders.filter(e => s(e.date)), e => Math.max(0, -Core.balance(e)));
      return a;
    },
    parseCSV: function (r) {
      r = r.replace(/^\uFEFF/, "");
      const o = [];
      let n = [];
      let s = "";
      let i = false;
      for (let e = 0; e < r.length; e++) {
        const a = r[e];
        if (a === "\"") {
          if (i && r[e + 1] === "\"") {
            s += "\"";
            e++;
          } else if (i) {
            i = false;
          } else {
            if (s) {
              throw Error("Unexpected quote in CSV.");
            }
            i = true;
          }
        } else if (i || a !== "," && a !== "\n" && a !== "\r") {
          s += a;
        } else {
          n.push(s);
          s = "";
          if (a !== ",") {
            if (a === "\r" && r[e + 1] === "\n") {
              e++;
            }
            if (n.some(e => e.trim())) {
              o.push(n);
            }
            n = [];
          }
        }
      }
      if (i) {
        throw Error("Unclosed quote in CSV.");
      }
      n.push(s);
      if (n.some(e => e.trim())) {
        o.push(n);
      }
      return o;
    },
    importRows: function (r, t, n) {
      if (!["customers", "products"].includes(t) || n.length < 2 || n.length > 5001) {
        throw Error("Use a header row and 1–5000 data rows.");
      }
      const i = {
        customername: "name",
        productname: "name",
        customer: "name",
        product: "name",
        phonenumber: "phone",
        sellingprice: "price",
        unitprice: "price",
        unitcost: "cost",
        reorderlevel: "threshold",
        quantity: "stock",
        addeddate: "date"
      };
      const a = Array.from(n[0], e => {
        const r = String(e).toLowerCase().replace(/[^a-z]/g, "");
        return i[r] || r;
      });
      if (!a.includes("name")) {
        throw Error("A Name column is required.");
      }
      const c = [];
      const d = [];
      const u = [];
      const f = new Set(r[t].map(e => t === "customers" ? e.phone.replace(/\D/g, "") || e.email.toLowerCase() || e.name.toLowerCase() : e.sku.toLowerCase() || e.name.toLowerCase()));
      n.slice(1).forEach((e, n) => {
        try {
          const s = Object.fromEntries(a.map((r, t) => [r, String(e[t] ?? "").trim()]));
          if (!s.name) {
            throw Error("Name missing");
          }
          const u = t === "customers" ? {
            id: Core.id(),
            name: s.name,
            phone: s.phone || "",
            email: s.email || "",
            address: s.address || "",
            date: s.date || Core.today()
          } : {
            id: Core.id(),
            name: s.name,
            sku: s.sku || "",
            stock: Number(s.stock || 0),
            threshold: Number(s.threshold || 0),
            price: Number(s.price || 0),
            cost: Number(s.cost || 0)
          };
          const m = structuredClone(r);
          m[t].push(u);
          o(m);
          const l = t === "customers" ? u.phone.replace(/\D/g, "") || u.email.toLowerCase() || u.name.toLowerCase() : u.sku.toLowerCase() || u.name.toLowerCase();
          if (f.has(l)) {
            d.push({
              row: n + 2,
              name: u.name
            });
            return;
          }
          f.add(l);
          c.push(u);
        } catch (e) {
          u.push({
            row: n + 2,
            message: e.message
          });
        }
      });
      return {
        accepted: c,
        skipped: d,
        errors: u
      };
    }
  };
})();
if (typeof module !== "undefined") {
  module.exports = Plus;
}
Core.reminders = Plus.reminders;
