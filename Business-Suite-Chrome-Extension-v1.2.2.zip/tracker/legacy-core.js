"use strict";

const LegacyCore = (() => {
  const t = () => crypto.randomUUID();
  const r = t => Math.round((Number(t) + Number.EPSILON) * 100) / 100;
  const s = (e, t) => r(e.reduce((e, r) => e + t(r), 0));
  const n = e => s(e.payments || [], e => e.amount);
  const o = e => r(e.amount - n(e));
  const a = () => ({
    app: "work-tracker-business",
    version: 2,
    currency: "INR",
    business: "My Business",
    orders: [],
    expenses: [],
    customers: [],
    products: []
  });
  function c(t) {
    const s = () => {
      throw Error("Invalid backup data. No data was changed.");
    };
    const o = e => typeof e == "string" && e.length <= 10000;
    const a = e => typeof e == "string" && /^\d{4}-\d{2}-\d{2}$/.test(e) && !isNaN(Date.parse(e + "T00:00:00Z")) && new Date(e + "T00:00:00Z").toISOString().slice(0, 10) === e;
    const c = e => typeof e === "number" && Number.isFinite(e) && e >= 0 && e <= 1000000000000;
    if (!t || t.app !== "work-tracker-business" || t.version !== 2 || !["INR", "AED", "USD"].includes(t.currency) || !o(t.business)) {
      s();
    }
    for (const e of ["orders", "expenses", "customers", "products"]) {
      if (!Array.isArray(t[e]) || t[e].length > 100000) {
        s();
      }
      const n = new Set();
      for (const a of t[e]) {
        if (!a || !o(a.id) || !a.id || !!n.has(a.id)) {
          s();
        }
        n.add(a.id);
      }
    }
    for (const e of t.customers) {
      if (!o(e.name) || !e.name.trim() || !o(e.phone) || !o(e.email) || !a(e.date)) {
        s();
      }
    }
    for (const e of t.products) {
      if (!o(e.name) || !e.name.trim() || !o(e.sku) || ![e.stock, e.threshold, e.price, e.cost].every(c) || !Number.isInteger(e.stock) || !Number.isInteger(e.threshold)) {
        s();
      }
    }
    for (const e of t.expenses) {
      if (!o(e.title) || !o(e.category) || !a(e.date) || !c(e.amount)) {
        s();
      }
    }
    const i = new Set();
    for (const e of t.orders) {
      if (!t.customers.some(t => t.id === e.customerId) || !o(e.description) || !o(e.note) || !a(e.date) || e.due !== "" && !a(e.due) || e.finishDate !== "" && !a(e.finishDate) || ![e.amount, e.cost, e.quantity].every(c) || !Number.isInteger(e.quantity) || !["open", "completed", "cancelled"].includes(e.status) || !o(e.productId) || !Array.isArray(e.payments)) {
        s();
      }
      if (e.productId && (!t.products.some(t => t.id === e.productId) || e.quantity < 1)) {
        s();
      }
      for (const t of e.payments) {
        if (!o(t.id) || i.has(t.id) || !a(t.date) || !c(t.amount) || t.date < e.date) {
          s();
        }
        i.add(t.id);
      }
      if (n(e) > e.amount || e.status === "cancelled" && n(e) > 0) {
        s();
      }
    }
    return t;
  }
  return {
    today: () => {
      const t = new Date();
      return t.getFullYear() + "-" + String(t.getMonth() + 1).padStart(2, "0") + "-" + String(t.getDate()).padStart(2, "0");
    },
    id: t,
    round: r,
    sum: s,
    paid: n,
    balance: o,
    fresh: a,
    migrate: function (r) {
      if (r.app === "work-tracker-business") {
        return c(r);
      }
      if (!Array.isArray(r.works)) {
        throw Error("Choose a Work Tracker JSON backup.");
      }
      const n = a();
      const o = new Map();
      n.orders = r.works.map(e => {
        const n = String(e.phone || "").replace(/\D/g, "") || String(e.client || "").trim().toLowerCase();
        let a = o.get(n);
        if (!a) {
          a = {
            id: t(),
            name: String(e.client || "Unknown"),
            phone: String(e.phone || ""),
            email: "",
            date: e.date
          };
          o.set(n, a);
        }
        if (e.date < a.date) {
          a.date = e.date;
        }
        return {
          id: t(),
          customerId: a.id,
          description: String(e.work || "Imported work"),
          date: e.date,
          due: e.dueDate || "",
          finishDate: e.finishDate || "",
          note: String(e.note || ""),
          amount: Number(e.amount),
          cost: 0,
          status: "completed",
          productId: "",
          quantity: 0,
          payments: e.status === "paid" ? [{
            id: t(),
            date: e.paidDate || e.finishDate || e.date,
            amount: Number(e.amount)
          }] : []
        };
      });
      n.customers = [...o.values()];
      n.expenses = (r.expenses || []).map(e => ({
        id: t(),
        date: e.date,
        title: String(e.title || "Expense"),
        category: "General",
        amount: Number(e.amount)
      }));
      return c(n);
    },
    validate: c,
    stats: function (t, n = "") {
      const c = t.orders.filter(e => e.status !== "cancelled" && e.date.startsWith(n));
      const i = s(c, e => e.amount);
      const d = s(c, e => e.cost);
      const u = s(t.expenses.filter(e => e.date.startsWith(n)), e => e.amount);
      return {
        revenue: i,
        cost: d,
        expenses: u,
        profit: r(i - d - u),
        pending: s(c, o),
        orders: c.length,
        customers: t.customers.filter(e => e.date.startsWith(n)).length,
        received: s(t.orders.filter(e => e.status !== "cancelled").flatMap(e => e.payments).filter(e => e.date.startsWith(n)), e => e.amount)
      };
    },
    saveOrder: function (t, r) {
      const n = t.orders.find(e => e.id === r.id);
      const o = new Map();
      if (n?.productId && n.status !== "cancelled") {
        o.set(n.productId, n.quantity);
      }
      if (r.productId && r.status !== "cancelled") {
        o.set(r.productId, (o.get(r.productId) || 0) - r.quantity);
      }
      for (const [e, r] of o) {
        const n = t.products.find(t => t.id === e);
        if (!n || n.stock + r < 0) {
          throw Error("Not enough stock for this order.");
        }
        n.stock += r;
      }
      t.orders = t.orders.filter(e => e.id !== r.id);
      t.orders.push(r);
      return c(t);
    }
  };
})();
if (typeof module !== "undefined") {
  module.exports = LegacyCore;
}
