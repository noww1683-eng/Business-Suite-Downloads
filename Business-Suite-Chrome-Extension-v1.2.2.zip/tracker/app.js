"use strict";

const $ = e => document.querySelector(e);
const esc = e => String(e ?? "").replace(/[&<>"']/g, e => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "\"": "&quot;",
  "'": "&#39;"
})[e]);
let data = Core.fresh();
let tab = "dashboard";
let mode = "advanced";
let query = "";
let filter = "";
let detail = null;
let period = Core.today().slice(0, 7);
let periodType = "month";
let editing = null;
let busy = false;
let draftItems = [];
let draftAttachments = [];
let reportRows = [];
const adv = () => mode === "advanced";
const money = e => new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: data.currency,
  maximumFractionDigits: 2
}).format(e);
const customer = e => data.customers.find(t => t.id === e);
const name = e => customer(e)?.name || "Unknown customer";
const clone = () => structuredClone(data);
const labels = {
  dashboard: "Dashboard",
  orders: "Orders & works",
  quotes: "Quotations",
  expenses: "Expenses",
  customers: "Customers",
  products: "Stock",
  services: "Recurring services",
  reminders: "Reminders",
  reports: "Reports",
  settings: "Settings & backup"
};
const statuses = {
  new: "New",
  in_progress: "In progress",
  waiting: "Waiting for client",
  completed: "Completed",
  cancelled: "Cancelled",
  draft: "Draft",
  sent: "Sent",
  accepted: "Accepted",
  rejected: "Rejected"
};
function toast(e) {
  $("#toast").textContent = e;
  $("#toast").hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("#toast").hidden = true, 6500);
}
async function commit(e, t = data.revision || 0) {
  Core.validate(e);
  await navigator.locks.request("work-tracker-write", async () => {
    const r = await chrome.storage.local.get("businessV3");
    if (r.businessV3 && (r.businessV3.revision || 0) !== t) {
      throw Error("Another tab changed this workspace. Reload before saving.");
    }
    e.revision = t + 1;
    await chrome.storage.local.set({
      businessV3: e
    });
    data = e;
  });
  render();
}
function btn(e, t, s = "", a = "", r = "") {
  return "<button type=\"button\" class=\"" + r + "\" data-action=\"" + e + "\" data-type=\"" + s + "\" data-id=\"" + esc(a) + "\">" + t + "</button>";
}
function card(e, t, s, a = false) {
  return "<div class=\"card " + (a ? "featured" : "") + "\"><div class=\"label\">" + e + "</div><strong>" + t + "</strong><small>" + s + "</small></div>";
}
function table(e, t) {
  if (t.length) {
    return "<div class=\"table-wrap\"><table><thead><tr>" + e.map(e => "<th>" + e + "</th>").join("") + "</tr></thead><tbody>" + t.map(e => "<tr>" + e.map(e => "<td>" + e + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>";
  } else {
    return "<p class=\"empty\">No records to show.</p>";
  }
}
const badge = (e, t = "") => "<span class=\"badge " + t + "\">" + esc(e) + "</span>";
const paymentBadge = e => e.status === "cancelled" ? badge("Cancelled", "bad") : Core.balance(e) < 0 ? badge("Refund due", "warn") : Core.balance(e) === 0 ? badge("Settled") : badge(Core.paid(e) ? "Partial" : "Unpaid", "warn");
const editActions = (e, t) => btn("edit", "Edit", e, t) + btn("delete", "Delete", e, t);
function render() {
  document.body.classList.toggle("document-view", tab === "document");
  $("#mode").value = mode;
  $("#business").textContent = data.business;
  $("#title").textContent = tab === "document" ? "Document preview" : labels[tab] || "Client history";
  const t = Core.reminders(data).length;
  $("#nav").innerHTML = Object.entries(labels).filter(([t]) => adv() || !["quotes", "services"].includes(t)).map(([s, a]) => "<button type=\"button\" data-action=\"tab\" data-type=\"" + s + "\" class=\"" + (tab === s ? "active" : "") + "\">" + a + (s === "reminders" && t ? " · " + t : "") + "</button>").join("");
  if (tab === "dashboard") {
    dashboard();
  } else if (tab === "reports") {
    reports();
  } else if (tab === "settings") {
    settings();
  } else if (tab === "reminders") {
    reminderView();
  } else if (tab === "document") {
    documentView();
  } else if (tab === "history") {
    historyView();
  } else if (detail && ["orders", "quotes", "services"].includes(tab)) {
    detailView();
  } else {
    records();
  }
}
function go(e) {
  tab = e;
  detail = null;
  query = "";
  filter = "";
  render();
}
function orderRows(e) {
  return e.map(e => [btn("detail", esc(e.number), "orders", e.id), esc(e.date), "<b>" + esc(name(e.customerId)) + "</b><div class=\"muted small\">" + esc(e.description) + "</div>", badge(statuses[e.status]), money(Core.totals(e).total), money(Math.max(0, Core.balance(e))), paymentBadge(e), btn("detail", "Open", "orders", e.id)]);
}
function dashboard() {
  const t = Core.stats(data);
  const s = Core.stats(data, Core.today());
  const a = Core.stats(data, Core.today().slice(0, 7));
  const r = data.products.filter(t => t.stock <= t.threshold);
  const n = Core.reminders(data);
  $("#view").innerHTML = "<div class=\"intro\"><div><h2>Your business at a glance</h2><p>From first quotation to final payment.</p></div><span class=\"date-chip\">" + esc(Core.today()) + "</span></div><div class=\"cards\">" + card("Today's Sales", money(s.revenue), "Net sales excluding tax", true) + card("Total Revenue", money(t.revenue), "After discounts & return credits") + card("Expenses", money(t.expenses), "Operating expenses") + card("Profit", money(t.profit), "Revenue − direct costs − expenses") + card("Pending Payments", money(t.pending), "Outstanding across active orders") + card("New Customers", a.customers, "Added this calendar month") + card("Orders", t.orders, "All non-cancelled orders") + card("Low Stock", r.length, "At or below reorder level") + "</div><div class=\"columns\"><section class=\"panel\"><div class=\"panel-head\"><h2>Coming up</h2>" + btn("tab", "All reminders", "reminders") + "</div>" + table(["Type", "Due", "Reminder"], n.slice(0, 5).map(t => [badge(t.type, t.date < Core.today() ? "bad" : "warn"), esc(t.date), btn("reminder", esc(t.label), t.target, t.id)])) + "</section><section class=\"panel\"><div class=\"panel-head\"><h2>Stock watch</h2>" + btn("tab", "View stock", "products") + "</div>" + (r.slice(0, 5).map(t => "<div class=\"stock-row\"><b>" + esc(t.name) + "</b>" + badge(t.stock + " left", "warn") + "</div>").join("") || "<p class=\"muted\">No low-stock alerts.</p>") + "<p class=\"small muted\">Customer refunds due: <b>" + money(t.owed) + "</b></p></section></div><section class=\"panel\"><div class=\"panel-head\"><h2>Recent orders</h2>" + btn("tab", "View all", "orders") + "</div>" + table(["Invoice", "Date", "Customer / work", "Progress", "Total incl. tax", "Due", "Payment", ""], orderRows([...data.orders].sort((t, s) => s.date.localeCompare(t.date)).slice(0, 5))) + "</section><p class=\"help\">Orders include unpaid work. Revenue excludes tax and deducts returns on the return date. Cash received and refunds are separate in Reports. Quotations and renewal tracking do not create sales until you create an order.</p>";
}
function records() {
  const t = query.toLowerCase();
  let s = [];
  let a = [];
  let r = data[tab] || [];
  if (tab === "orders") {
    r = r.filter(s => (s.number + " " + name(s.customerId) + " " + s.description).toLowerCase().includes(t)).filter(t => !filter || (filter === "unpaid" ? t.status !== "cancelled" && Core.balance(t) > 0 : t.status === filter)).sort((t, s) => s.date.localeCompare(t.date));
    a = ["Invoice", "Date", "Customer / work", "Progress", "Total incl. tax", "Due", "Payment", ""];
    s = orderRows(r);
  }
  if (tab === "quotes") {
    r = r.filter(s => (s.number + " " + name(s.customerId) + " " + s.description).toLowerCase().includes(t));
    a = ["Quotation", "Customer", "Work", "Valid until", "Amount", "Status", ""];
    s = r.map(t => [esc(t.number), esc(name(t.customerId)), esc(t.description), esc(t.validUntil || "—"), money(Core.totals(t).total), badge(t.orderId ? "Converted" : statuses[t.status]), btn("detail", "Open", "quotes", t.id)]);
  }
  if (tab === "expenses") {
    r = r.filter(e => (e.title + " " + e.category).toLowerCase().includes(t));
    a = ["Date", "Expense", "Category", "Amount", ""];
    s = r.map(t => [esc(t.date), esc(t.title), esc(t.category), money(t.amount), editActions(tab, t.id)]);
  }
  if (tab === "customers") {
    r = r.filter(s => (s.name + " " + s.phone + " " + s.email).toLowerCase().includes(t));
    a = ["Customer", "Phone / email", "Added", "Due", ""];
    s = r.map(t => [btn("history", esc(t.name), "customers", t.id), esc(t.phone) + "<div class=\"small muted\">" + esc(t.email) + "</div>", esc(t.date), money(Core.sum(data.orders.filter(e => e.customerId === t.id), t => Math.max(0, Core.balance(t)))), btn("history", "History", "customers", t.id) + editActions(tab, t.id)]);
  }
  if (tab === "products") {
    r = r.filter(s => (s.name + " " + s.sku).toLowerCase().includes(t));
    a = ["Product", "SKU", "Stock", "Low at", "Price", "Status", ""];
    s = r.map(t => [esc(t.name), esc(t.sku), t.stock, t.threshold, money(t.price), badge(t.stock <= t.threshold ? "Low stock" : "Healthy", t.stock <= t.threshold ? "warn" : ""), editActions(tab, t.id)]);
  }
  if (tab === "services") {
    r = r.filter(s => (s.name + " " + name(s.customerId)).toLowerCase().includes(t));
    a = ["Service", "Customer", "Renewal", "Interval", "Amount", "Status", ""];
    s = r.map(t => [esc(t.name), esc(name(t.customerId)), esc(t.nextDate), t.interval + " month(s)", money(t.amount), badge(t.active ? "Active" : "Paused", t.active && t.nextDate < Core.today() ? "warn" : ""), btn("detail", "Open", "services", t.id)]);
  }
  $("#view").innerHTML = "<div class=\"toolbar\"><input id=\"search\" type=\"search\" aria-label=\"Search\" placeholder=\"Search…\" value=\"" + esc(query) + "\">" + (tab === "orders" ? "<select id=\"filter\" aria-label=\"Order filter\"><option value=\"\">All orders</option>" + Object.entries({
    ...statuses,
    unpaid: "Payment pending"
  }).filter(([t]) => !["draft", "sent", "accepted", "rejected"].includes(t)).map(([t, s]) => "<option value=\"" + t + "\" " + (filter === t ? "selected" : "") + ">" + s + "</option>").join("") + "</select>" : "") + btn("new", "+ Add " + {
    orders: "order",
    quotes: "quotation",
    expenses: "expense",
    customers: "customer",
    products: "product",
    services: "service"
  }[tab], tab, "", "primary") + (adv() ? btn("export", "Export CSV", tab) : "") + "</div><section class=\"panel\">" + table(a, s) + "</section>" + (tab === "products" ? "<p class=\"help\">Product-linked orders reserve stock immediately, including unfinished work. Quotations do not reserve stock. A return restores stock only when Restock is selected.</p>" : "");
}
function detailView() {
  const t = data[tab].find(e => e.id === detail);
  if (!t) {
    detail = null;
    return records();
  }
  if (tab === "services") {
    const s = customer(t.customerId);
    $("#view").innerHTML = "<div class=\"toolbar\">" + btn("tab", "← Services", "services") + editActions("services", t.id) + (t.active ? btn("renew", "Mark renewed", "services", t.id, "primary") : "") + btn("renewOrder", "Create renewal order", "services", t.id) + btn("whatsapp", "WhatsApp renewal reminder", "services", t.id) + "</div><section class=\"panel\"><h2>" + esc(t.name) + "</h2><p>" + esc(s.name) + " · " + money(t.amount) + " · Every " + t.interval + " month(s)</p><p>Next renewal: <b>" + esc(t.nextDate) + "</b> · " + (t.active ? "Active" : "Paused") + "</p><p>" + esc(t.note) + "</p><h3>Renewal history</h3>" + table(["Recorded", "Previous due", "Amount"], t.history.map(e => [esc(e.renewedOn), esc(e.previousDue), money(e.amount)])) + "</section><p class=\"help\">Mark renewed advances one billing cycle from the current renewal date. It does not record a payment. Create an order separately when billing the customer.</p>";
    return;
  }
  const s = Core.totals(t);
  const a = tab === "quotes";
  $("#view").innerHTML = "<div class=\"toolbar\">" + btn("tab", "← " + (a ? "Quotations" : "Orders"), tab) + btn("edit", "Edit", tab, t.id) + btn("doc", a ? "Quotation PDF" : "Invoice PDF", tab, t.id) + btn("attachments", "Attachments / links", tab, t.id) + btn("whatsapp", "WhatsApp", tab, t.id) + (a ? t.orderId ? btn("detail", "Open converted order", "orders", t.orderId) : btn("convert", "Convert to order", "quotes", t.id, "primary") : t.status !== "cancelled" ? btn("payment", "Record payment", "orders", t.id, "primary") + btn("return", "Return / credit", "orders", t.id) + btn("refund", "Refund cash", "orders", t.id) : "") + btn("delete", "Delete", tab, t.id) + "</div><section class=\"panel\"><div class=\"panel-head\"><div><span class=\"eyebrow\">" + esc(t.number) + "</span><h2>" + esc(t.description) + "</h2></div>" + badge(statuses[t.status]) + "</div><p>" + btn("history", esc(name(t.customerId)), "customers", t.customerId) + " · Date: " + esc(t.date) + (a ? " · Valid until: " + esc(t.validUntil || "—") : " · Delivery: " + esc(t.deadline || "—") + " · Payment due: " + esc(t.due || "—")) + "</p>" + table(["Item", "Quantity", "Unit price", "Total"], t.items.map(t => [esc(t.description), t.quantity, money(t.price), money(t.price * t.quantity)])) + "<div class=\"totals\">" + totalSummary(t) + "</div><p class=\"pre\">" + esc(t.note) + "</p></section>" + (a ? "" : "<div class=\"cards\">" + card("Invoice total", money(s.total), "Includes tax") + card("Return credits", money(Core.credits(t)), "Reduces the invoice value") + card("Net received", money(Core.netPaid(t)), "Payments less refunds") + card(Core.balance(t) < 0 ? "Refund due" : "Payment due", money(Math.abs(Core.balance(t))), "Current balance") + "</div><section class=\"panel\"><h3>Payments & receipts</h3>" + table(["Date", "Method", "Amount", "Note", ""], t.payments.map(s => [esc(s.date), esc(s.method), money(s.amount), esc(s.note), btn("receipt", "Receipt PDF", t.id, s.id)])) + "</section><section class=\"panel\"><h3>Returns / credits</h3>" + table(["Date", "Item", "Qty", "Restocked", "Credit incl. tax", "Reason"], t.returns.map(s => [esc(s.date), esc(t.items.find(t => t.id === s.itemId)?.description), s.quantity, s.restock ? "Yes" : "No", money(s.net + s.tax), esc(s.reason)])) + "<h3>Cash refunds</h3>" + table(["Date", "Amount", "Method", "Reason"], t.refunds.map(t => [esc(t.date), money(t.amount), esc(t.method), esc(t.note)])) + "</section>") + "<section class=\"panel\"><h3>Files & links</h3>" + attachmentList(t.attachments) + "</section>";
}
function totalSummary(e) {
  const s = Core.totals(e);
  return "<p>Subtotal <b>" + money(s.subtotal) + "</b></p><p>Discount <b>− " + money(s.discount) + "</b></p><p>Tax (" + e.taxRate + "%) <b>" + money(s.tax) + "</b></p><p class=\"grand\">Total <b>" + money(s.total) + "</b></p>";
}
function attachmentList(e) {
  if (e.length) {
    return e.map(e => "<div class=\"stock-row\"><span>" + esc(e.name) + " <small class=\"muted\">" + e.kind + "</small></span>" + btn("attachment", e.kind === "file" ? "Download" : "Open link", "", e.id) + "</div>").join("");
  } else {
    return "<p class=\"muted\">No files or links attached.</p>";
  }
}
function historyView() {
  const t = customer(detail);
  if (!t) {
    return go("customers");
  }
  const s = data.orders.filter(e => e.customerId === t.id);
  const a = data.quotes.filter(s => s.customerId === t.id);
  const r = data.services.filter(e => e.customerId === t.id);
  const n = s.flatMap(t => t.payments.map(s => ({
    ...s,
    number: t.number,
    kind: "Received"
  })).concat(t.refunds.map(e => ({
    ...e,
    number: t.number,
    kind: "Refund"
  })))).sort((t, s) => s.date.localeCompare(t.date));
  $("#view").innerHTML = "<div class=\"toolbar\">" + btn("tab", "← Customers", "customers") + btn("edit", "Edit customer", "customers", t.id) + btn("print", "Print history") + "</div><section class=\"panel\"><h2>" + esc(t.name) + "</h2><p>" + esc(t.phone) + " · " + esc(t.email) + "</p><p class=\"pre\">" + esc(t.address) + "</p></section><div class=\"cards\">" + card("Orders", s.length, "Including cancelled") + card("Net received", money(Core.sum(s, Core.netPaid)), "Payments less refunds") + card("Payment due", money(Core.sum(s, t => Math.max(0, Core.balance(t)))), "Outstanding") + card("Refund due", money(Core.sum(s, t => Math.max(0, -Core.balance(t)))), "Customer credit") + "</div><section class=\"panel\"><h3>Work history</h3>" + table(["Invoice", "Date", "Work", "Progress", "Total", "Due", "Payment", ""], orderRows(s)) + "</section><section class=\"panel\"><h3>Payment history</h3>" + table(["Date", "Invoice", "Type", "Amount", "Method"], n.map(t => [esc(t.date), esc(t.number), t.kind, money(t.amount), esc(t.method)])) + "</section><section class=\"panel\"><h3>Quotations</h3>" + table(["Number", "Work", "Status", "Total"], a.map(t => [btn("detail", esc(t.number), "quotes", t.id), esc(t.description), badge(statuses[t.status]), money(Core.totals(t).total)])) + "<h3>Recurring services</h3>" + table(["Service", "Next renewal", "Amount"], r.map(e => [btn("detail", esc(e.name), "services", e.id), esc(e.nextDate), money(e.amount)])) + "</section>";
}
function reminderView() {
  $("#view").innerHTML = "<section class=\"panel\"><div class=\"panel-head\"><h2>Deadlines, payments & renewals</h2>" + btn("testNotify", "Test desktop notification") + "</div>" + table(["Type", "Date", "Status", "Action"], Core.reminders(data).map(t => [badge(t.type), esc(t.date), t.date < Core.today() ? badge("Overdue", "bad") : t.date === Core.today() ? badge("Today", "warn") : badge("Upcoming"), btn("reminder", esc(t.label), t.target, t.id)])) + "</section><p class=\"help\">Checks run approximately every hour while Chrome is running, with at most one summary notification per day. Sleeping/closed devices cannot deliver on-time alerts. Configure lead time and backup interval in Settings. No WhatsApp messages are sent automatically.</p>";
}
function reportData() {
  const t = periodType === "year" ? period.slice(0, 4) : period;
  const s = periodType === "year" ? Array.from({
    length: 12
  }, (s, a) => t + "-" + String(a + 1).padStart(2, "0")) : Array.from({
    length: new Date(Number(t.slice(0, 4)), Number(t.slice(5, 7)), 0).getDate()
  }, (s, a) => t + "-" + String(a + 1).padStart(2, "0"));
  return {
    prefix: t,
    units: s
  };
}
function reports() {
  const {
    prefix: t,
    units: s
  } = reportData();
  const a = Core.stats(data, t);
  reportRows = s.map(e => {
    const s = Core.stats(data, e);
    return [e, s.orders, s.revenue, s.tax, s.cost, s.expenses, s.profit, s.received, s.refunds, s.netCash];
  });
  $("#view").innerHTML = "<div class=\"toolbar\"><select id=\"periodType\" aria-label=\"Report type\"><option value=\"month\" " + (periodType === "month" ? "selected" : "") + ">Monthly report</option><option value=\"year\" " + (periodType === "year" ? "selected" : "") + ">Yearly report</option></select><input id=\"period\" aria-label=\"Report period\" type=\"" + (periodType === "month" ? "month" : "number") + "\" value=\"" + esc(t) + "\" " + (periodType === "year" ? "min=\"1900\" max=\"9999\"" : "") + ">" + btn("print", "Print / Save PDF") + btn("reportExport", "Export CSV") + "</div><div class=\"cards\">" + card("Revenue", money(a.revenue), "Excludes tax, after returns", true) + card("Profit", money(a.profit), "After costs & expenses") + card("Cash received", money(a.received), "Payment dates in period") + card("Refunds paid", money(a.refunds), "Refund dates in period") + "</div><section class=\"panel\"><h3>" + esc(t) + " breakdown</h3>" + table(["Period", "Orders", "Sales ex. tax", "Tax", "Cost", "Expenses", "Profit", "Received", "Refunded", "Net cash"], reportRows.map(e => e.map((e, t) => t < 2 ? esc(e) : money(e)))) + "</section><p class=\"help\">Revenue and costs use order dates; returns reduce revenue/tax on their recorded date. Cost is reversed only for restocked products. Refunds reduce cash, not revenue a second time. Expenses use expense dates. Tax is a user-entered percentage, not a tax-compliance engine.</p>";
}
function settings() {
  const t = data.profile;
  const s = data.preferences;
  $("#view").innerHTML = "<section class=\"panel\"><h2>Business details & document branding</h2><form id=\"settingsForm\"><div class=\"fields\">" + field("Business name *", "business", data.business, "text", "required maxlength=\"150\"") + select("Currency", "currency", BusinessCurrency.options, data.currency) + field("Business phone", "phone", t.phone, "tel") + field("Email", "email", t.email, "email") + field("Tax / registration ID (optional)", "taxId", t.taxId) + "<label>Business address<textarea name=\"address\">" + esc(t.address) + "</textarea></label><label class=\"wide\">Document footer / terms<textarea name=\"terms\">" + esc(t.terms) + "</textarea></label>" + select("Desktop notifications", "notifications", [["yes", "Enabled"], ["no", "Disabled"]], s.notifications ? "yes" : "no") + field("Remind before due date (days)", "reminderDays", s.reminderDays, "number", "required min=\"0\" max=\"30\" step=\"1\"") + field("Backup reminder interval (days)", "backupDays", s.backupDays, "number", "required min=\"1\" max=\"90\" step=\"1\"") + "</div><p class=\"small muted\">Changing currency relabels existing amounts; it does not convert them.</p><button class=\"primary\" type=\"submit\">Save preferences</button></form><div class=\"toolbar logo-area\">" + (t.logo ? "<img src=\"" + t.logo + "\" alt=\"Business logo\" class=\"business-logo\">" : "") + btn("logo", "Upload logo") + (t.logo ? btn("removeLogo", "Remove logo") : "") + "</div><p class=\"small muted\">PNG, JPEG or WebP, up to 500 KB.</p></section><section class=\"panel\"><h2>Backup & restore</h2><p>Last completed backup: <b>" + esc(data.lastBackup || "Not yet") + "</b></p><div class=\"toolbar\">" + btn("backup", "Download JSON backup") + btn("import", "Import JSON backup") + "</div><p class=\"help\">Supports original Work Tracker, v2 Basic/Advanced and v3/v4 single-business JSON backups. Import replaces this workspace only after validation, confirmation and a completed pre-import backup. Use Businesses → Backup ALL businesses for a full v4 backup; importing it replaces all businesses.</p></section><section class=\"panel\"><h2>Using this upgrade</h2><p>Advanced mode shows quotations and recurring services. Basic mode keeps the main navigation simpler; all existing records and detailed order tools remain available.</p><p>Data stays on this browser profile. No cloud account, bank sync or automatic message sending. Export backups before uninstalling. Uploaded files are stored locally with records.</p></section>";
}
let documentRef = null;
function documentView() {
  const t = documentRef;
  const s = data[t.kind].find(e => e.id === t.id);
  if (!s) {
    return go(t.kind);
  }
  const a = customer(s.customerId);
  const r = data.profile;
  Core.totals(s);
  const n = t.paymentId ? s.payments.find(e => e.id === t.paymentId) : null;
  const i = n ? "PAYMENT RECEIPT" : t.kind === "quotes" ? "QUOTATION" : "INVOICE";
  const o = n ? s.number + " / R" + (s.payments.indexOf(n) + 1) : s.number;
  document.title = i + " " + o;
  $("#view").innerHTML = "<div class=\"toolbar no-print\">" + btn("detail", "← Back", t.kind, s.id) + btn("print", "Print / Save as PDF", "", "", "primary") + "<span class=\"small muted\">Choose “Save as PDF” · A4 · Disable browser headers/footers</span></div><article class=\"paper\"><div class=\"paper-head\"><div>" + (r.logo ? "<img src=\"" + r.logo + "\" class=\"business-logo\" alt=\"Business logo\">" : "") + "<h2>" + esc(data.business) + "</h2><div class=\"pre\">" + esc(r.address) + "</div><div>" + esc(r.phone) + (r.email ? " · " + esc(r.email) : "") + "</div>" + (r.taxId ? "<div>Registration / Tax ID: " + esc(r.taxId) + "</div>" : "") + "</div><div class=\"document-meta\"><span>" + i + "</span><h3>" + esc(o) + "</h3><div>Date: " + esc(n ? n.date : s.date) + "</div>" + (t.kind === "quotes" ? "<div>Valid until: " + esc(s.validUntil || "—") + "</div>" : n ? "" : "<div>Payment due: " + esc(s.due || "—") + "</div>") + "</div></div><div class=\"bill-to\"><span class=\"eyebrow\">" + (n ? "Received from" : "Prepared for") + "</span><h3>" + esc(a.name) + "</h3><div class=\"pre\">" + esc(a.address) + "</div><div>" + esc(a.phone) + (a.email ? " · " + esc(a.email) : "") + "</div></div><h3>" + esc(s.description) + "</h3>" + (n ? "<div class=\"receipt-amount\"><span>Amount received</span><strong>" + money(n.amount) + "</strong><p>Method: " + esc(n.method || "—") + "</p><p>For invoice: " + esc(s.number) + "</p><p>" + esc(n.note) + "</p></div><p>Current invoice balance: " + money(Core.balance(s)) + "</p><p class=\"small muted\">This receipt records the selected payment. It is not a confirmation of settlement for other payments or later adjustments.</p>" : table(["Description", "Qty", "Unit price", "Line total"], s.items.map(t => [esc(t.description), t.quantity, money(t.price), money(t.quantity * t.price)])) + "<div class=\"totals\">" + totalSummary(s) + (t.kind === "orders" ? "<p>Return credits <b>− " + money(Core.credits(s)) + "</b></p><p>Payments less refunds <b>" + money(Core.netPaid(s)) + "</b></p><p>" + (Core.balance(s) < 0 ? "Refund due" : "Balance due") + " <b>" + money(Math.abs(Core.balance(s))) + "</b></p>" : "") + "</div>") + "<p class=\"pre\">" + esc(s.note) + "</p><div class=\"paper-footer pre\">" + esc(r.terms) + "</div>" + (t.kind === "quotes" ? "<p class=\"small muted\">This quotation is an estimate, not a payment receipt.</p>" : "") + (s.status === "cancelled" ? "<p class=\"cancelled-mark\">CANCELLED</p>" : "") + "</article>";
}
