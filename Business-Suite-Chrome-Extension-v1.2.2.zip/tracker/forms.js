"use strict";

function field(e, t, r = "", a = "text", n = "") {
  return "<label>" + e + "<input name=\"" + t + "\" type=\"" + a + "\" value=\"" + esc(r) + "\" " + n + "></label>";
}
function select(e, t, r, a, n = "") {
  return "<label>" + e + "<select name=\"" + t + "\" " + n + ">" + r.map(([e, t]) => "<option value=\"" + esc(e) + "\" " + (e === a ? "selected" : "") + ">" + esc(t) + "</option>").join("") + "</select></label>";
}
function emptyItem() {
  return {
    id: Core.id(),
    productId: "",
    description: "",
    quantity: 1,
    price: 0,
    cost: 0
  };
}
const numeric = "required min=\"0\" max=\"1000000000000\" step=\"any\"";
function financialLocked(e) {
  return Boolean(e && (e.payments?.length || e.returns?.length || e.refunds?.length));
}
function itemRows() {
  return "<div class=\"wide item-editor\"><h3>Items / services</h3><div class=\"table-wrap\"><table><thead><tr><th>Product / service</th><th>Description *</th><th>Qty *</th><th>Unit price *</th><th>Unit cost *</th><th></th></tr></thead><tbody id=\"itemRows\">" + draftItems.map(e => itemRow(e)).join("") + "</tbody></table></div>" + btn("addItem", "+ Add item") + "<p class=\"small muted\">Whole quantities. Product choice fills description and unit price/cost; you can override. Order stock is reserved immediately. Quotes do not change stock.</p></div>";
}
function itemRow(e) {
  return "<tr data-item=\"" + esc(e.id) + "\"><td><select data-col=\"productId\" aria-label=\"Product\"><option value=\"\">Service / manual item</option>" + data.products.map(t => "<option value=\"" + esc(t.id) + "\" " + (t.id === e.productId ? "selected" : "") + ">" + esc(t.name) + " (" + t.stock + " available)</option>").join("") + "</select></td><td><input data-col=\"description\" aria-label=\"Item description\" required maxlength=\"300\" value=\"" + esc(e.description) + "\"></td><td><input data-col=\"quantity\" aria-label=\"Quantity\" type=\"number\" required min=\"1\" max=\"1000000\" step=\"1\" value=\"" + e.quantity + "\"></td><td><input data-col=\"price\" aria-label=\"Unit price\" type=\"number\" " + numeric + " value=\"" + e.price + "\"></td><td><input data-col=\"cost\" aria-label=\"Unit cost\" type=\"number\" " + numeric + " value=\"" + e.cost + "\"></td><td>" + btn("removeItem", "×", "", e.id) + "</td></tr>";
}
function readItems() {
  draftItems = [...document.querySelectorAll("#itemRows tr")].map(e => {
    const r = {
      id: e.dataset.item
    };
    for (const a of ["productId", "description", "quantity", "price", "cost"]) {
      const n = e.querySelector("[data-col=\"" + a + "\"]").value;
      r[a] = ["quantity", "price", "cost"].includes(a) ? Number(n) : n;
    }
    return r;
  });
  return draftItems;
}
function liveTotal() {
  if ($("#liveTotal")) {
    try {
      const t = $("#form");
      const r = {
        items: readItems(),
        discountType: t.elements.discountType.value,
        discount: Number(t.elements.discount.value),
        taxRate: Number(t.elements.taxRate.value)
      };
      $("#liveTotal").innerHTML = totalSummary(r);
    } catch {}
  }
}
function openForm(e, t = "") {
  if (["orders", "quotes", "services"].includes(e) && !data.customers.length) {
    toast("Add a customer first.");
    return openForm("customers");
  }
  const a = data[e]?.find(e => e.id === t) || {};
  editing = {
    type: e,
    id: t
  };
  $("#formError").textContent = "";
  $("#saveButton").textContent = e === "whatsapp" ? "Open WhatsApp" : e === "attachments" ? "Save attachments" : "Save";
  $("#formTitle").textContent = {
    payment: "Record payment",
    return: "Return / credit",
    refund: "Refund cash",
    attachments: "Files & links",
    whatsapp: "Review WhatsApp message"
  }[e] || (t ? "Edit" : "New") + " " + {
    orders: "order / work",
    quotes: "quotation",
    customers: "customer",
    expenses: "expense",
    products: "product",
    services: "recurring service"
  }[e];
  let n = "";
  if (["orders", "quotes"].includes(e)) {
    const t = e === "quotes";
    draftItems = structuredClone(a.items || [emptyItem()]);
    draftAttachments = structuredClone(a.attachments || []);
    n = select("Customer *", "customerId", data.customers.map(e => [e.id, e.name]), a.customerId) + field("Work / order title *", "description", a.description || "", "text", "required maxlength=\"300\"") + field("Document date *", "date", a.date || Core.today(), "date", "required") + select("Progress / status", "status", Object.entries(statuses).filter(([e]) => t ? ["draft", "sent", "accepted", "rejected"].includes(e) : ["new", "in_progress", "waiting", "completed", "cancelled"].includes(e)), a.status || (t ? "draft" : "new")) + (t ? field("Valid until", "validUntil", a.validUntil || Core.addDays(Core.today(), 14), "date") : field("Delivery deadline", "deadline", a.deadline || "", "date") + field("Payment due date", "due", a.due || "", "date") + field("Completed date", "finishDate", a.finishDate || "", "date")) + itemRows() + select("Discount type", "discountType", [["fixed", "Fixed amount"], ["percent", "Percentage"]], a.discountType || "fixed") + field("Discount", "discount", a.discount || 0, "number", numeric) + field("Tax rate (%) — exclusive", "taxRate", a.taxRate || 0, "number", "required min=\"0\" max=\"100\" step=\"any\"") + "<div id=\"liveTotal\" class=\"totals wide\"></div><label class=\"wide\">Notes / scope<textarea name=\"note\" maxlength=\"20000\">" + esc(a.note || "") + "</textarea></label>" + (financialLocked(a) ? "<p class=\"wide help\">Financial history exists. Customer, date, items, discount and tax are locked on save. You can update progress, deadline, notes and attachments. Use Return / credit for adjustments.</p>" : "") + (t && a.orderId ? "<p class=\"wide help\">Converted quotations are read-only. Open the linked order to continue.</p>" : "");
  }
  if (e === "customers") {
    n = field("Customer name *", "name", a.name || "", "text", "required maxlength=\"200\"") + field("Phone (include country code for WhatsApp)", "phone", a.phone || "", "tel", "maxlength=\"50\"") + field("Email", "email", a.email || "", "email") + field("Added date *", "date", a.date || Core.today(), "date", "required") + "<label class=\"wide\">Address<textarea name=\"address\">" + esc(a.address || "") + "</textarea></label>";
  }
  if (e === "products") {
    n = field("Product name *", "name", a.name || "", "text", "required maxlength=\"200\"") + field("SKU", "sku", a.sku || "") + field("Current stock *", "stock", a.stock ?? 0, "number", "required min=\"0\" max=\"1000000\" step=\"1\"") + field("Reorder level *", "threshold", a.threshold ?? 5, "number", "required min=\"0\" max=\"1000000\" step=\"1\"") + field("Unit selling price", "price", a.price ?? 0, "number", numeric) + field("Unit cost", "cost", a.cost ?? 0, "number", numeric);
  }
  if (e === "expenses") {
    n = field("Expense title *", "title", a.title || "", "text", "required maxlength=\"200\"") + field("Category *", "category", a.category || "General", "text", "required") + field("Date *", "date", a.date || Core.today(), "date", "required") + field("Amount *", "amount", a.amount ?? "", "number", "required min=\"0.01\" max=\"1000000000000\" step=\"0.01\"");
  }
  if (e === "services") {
    n = select("Customer *", "customerId", data.customers.map(e => [e.id, e.name]), a.customerId) + field("Service name *", "name", a.name || "", "text", "required maxlength=\"200\"") + field("Renewal amount", "amount", a.amount || 0, "number", numeric) + field("Next renewal *", "nextDate", a.nextDate || Core.today(), "date", "required") + select("Repeat interval", "interval", [[1, "Monthly"], [3, "Quarterly"], [6, "Every 6 months"], [12, "Yearly"]].map(([e, t]) => [String(e), t]), String(a.interval || 12)) + select("Status", "active", [["yes", "Active"], ["no", "Paused"]], a.active === false ? "no" : "yes") + "<label class=\"wide\">Notes<textarea name=\"note\">" + esc(a.note || "") + "</textarea></label>";
  }
  if (["payment", "return", "refund"].includes(e)) {
    const a = data.orders.find(e => e.id === t);
    if (!a || a.status === "cancelled") {
      return toast("Choose an active order.");
    }
    n = "<div class=\"wide help\">" + esc(a.number) + " · " + esc(name(a.customerId)) + "<br>Invoice " + money(Core.totals(a).total) + " · " + (Core.balance(a) < 0 ? "Refund due" : "Payment due") + " " + money(Math.abs(Core.balance(a))) + "</div>";
    if (e === "payment") {
      if (Core.balance(a) <= 0) {
        return toast("No payment is due on this order.");
      }
      n += field("Amount received *", "amount", Core.balance(a), "number", "required min=\"0.01\" max=\"" + Core.balance(a) + "\" step=\"0.01\"") + field("Payment date *", "date", Core.today(), "date", "required min=\"" + a.date + "\"") + field("Method", "method", "Cash / bank") + field("Reference / note", "note", "");
    }
    if (e === "refund") {
      if (Core.balance(a) >= 0) {
        return toast("Record a return / credit first. Refunds are limited to customer credit.");
      }
      n += field("Cash refunded *", "amount", -Core.balance(a), "number", "required min=\"0.01\" max=\"" + -Core.balance(a) + "\" step=\"0.01\"") + field("Refund date *", "date", Core.today(), "date", "required min=\"" + a.date + "\"") + field("Method", "method", "Cash / bank") + field("Reason / reference", "note", "", "text", "required") + "<p class=\"wide help\">This records a refund already made. It does not transfer money.</p>";
    }
    if (e === "return") {
      const e = a.items.map(e => ({
        ...e,
        left: e.quantity - Core.sum(a.returns.filter(t => t.itemId === e.id), e => e.quantity)
      })).filter(e => e.left > 0);
      if (!e.length) {
        return toast("All quantities have already been returned/credited.");
      }
      n += select("Item to return / credit", "itemId", e.map(e => [e.id, e.description + " (" + e.left + " remaining)"]), e[0].id) + field("Quantity *", "quantity", 1, "number", "required min=\"1\" step=\"1\"") + field("Return / credit date *", "date", Core.today(), "date", "required min=\"" + a.date + "\"") + select("Return stock to inventory?", "restock", [["no", "No — credit only / damaged / service"], ["yes", "Yes — restock product"]], "no") + field("Reason *", "reason", "", "text", "required") + "<p class=\"wide help\">Credit uses the original item price, proportional discount and tax. A product return restores stock only if selected. Service credits do not restore stock or reverse incurred costs. Refund cash separately when money must be returned.</p>";
    }
  }
  $("#fields").innerHTML = n;
  if (!$("#dialog").open) {
    $("#dialog").showModal();
  }
  if (["orders", "quotes"].includes(e)) {
    liveTotal();
  }
}
function openAttachments(e, t) {
  const a = data[e].find(e => e.id === t);
  editing = {
    type: "attachments",
    id: t,
    kind: e
  };
  draftAttachments = structuredClone(a.attachments);
  $("#formTitle").textContent = "Files & links";
  $("#saveButton").textContent = "Save attachments";
  $("#formError").textContent = "";
  $("#fields").innerHTML = "<div class=\"wide\" id=\"attachmentRows\"></div>" + field("Link name", "linkName", "") + field("Web link (https://…)", "linkUrl", "", "url") + "<div class=\"wide\">" + btn("addLink", "+ Add link") + "</div><label class=\"wide\">Upload files (PDF, PNG, JPEG, WebP, TXT; max 2 MB each)<input id=\"attachmentFiles\" type=\"file\" accept=\"application/pdf,image/png,image/jpeg,image/webp,text/plain\" multiple></label><p class=\"wide help\">Up to 20 attachments per record. Files are included in JSON backups. Links open only when you click them.</p>";
  drawAttachments();
  $("#dialog").showModal();
}
function drawAttachments() {
  $("#attachmentRows").innerHTML = draftAttachments.map(t => "<div class=\"stock-row\"><span>" + esc(t.name) + " (" + t.kind + ")</span>" + btn("removeDraftAttachment", "Remove", "", t.id) + "</div>").join("") || "<p class=\"muted\">No attachments yet.</p>";
}
function openWhatsApp(e, t) {
  const a = data[e].find(e => e.id === t);
  const n = customer(a.customerId);
  editing = {
    type: "whatsapp",
    id: t,
    kind: e
  };
  $("#formTitle").textContent = "Review WhatsApp message";
  $("#saveButton").textContent = "Open WhatsApp";
  $("#formError").textContent = "";
  let i = e === "services" ? "Dear " + n.name + ",\n\nThis is a courteous reminder that your service \"" + a.name + "\" is due for renewal on " + a.nextDate + ".\nRenewal amount: " + money(a.amount) + "\n\nPlease let us know if you would like to proceed with the renewal.\n\nThank you for your continued trust.\n\nBest regards,\n" + data.business : e === "quotes" ? "Dear " + n.name + ",\n\nThank you for your enquiry. Please find the details of your quotation below.\n\nQuotation no.: " + a.number + "\nDescription: " + a.description + "\nTotal amount: " + money(Core.totals(a).total) + (a.validUntil ? "\nValid until: " + a.validUntil : "") + "\n\nPlease let us know if you would like to proceed.\n\nBest regards,\n" + data.business : "Dear " + n.name + ",\n\nHere is an update on your order " + a.number + " (" + a.description + ").\nCurrent status: " + statuses[a.status] + "\n" + (Core.balance(a) > 0 ? "\nOutstanding balance: " + money(Core.balance(a)) + (a.due ? "\nDue date: " + a.due : "") + "\nKindly arrange the payment at your earliest convenience.\n" : "") + "\nThank you for your business.\n\nBest regards,\n" + data.business;
  $("#fields").innerHTML = field("WhatsApp number — country code required", "phone", n.phone, "tel", "required") + "<label class=\"wide\">Message<textarea name=\"message\" rows=\"12\" required>" + esc(i) + "</textarea></label><p class=\"wide help\">Include country code, e.g. 91… or 971…; do not add a local leading zero. The number is saved to the customer if it was missing or changed. Opens WhatsApp Web (re-using the window that is already open); you review and press Send yourself. PDFs/files are not automatically attached.</p>";
  $("#dialog").showModal();
}
const financialSignature = e => JSON.stringify({
  customerId: e.customerId,
  date: e.date,
  items: e.items.map(e => ({
    id: e.id,
    productId: e.productId,
    description: e.description,
    quantity: e.quantity,
    price: e.price,
    cost: e.cost
  })),
  discountType: e.discountType,
  discount: e.discount,
  taxRate: e.taxRate
});
async function submitRecord(e) {
  e.preventDefault();
  if (!busy) {
    busy = true;
    $("#saveButton").disabled = true;
    try {
      const r = Object.fromEntries(new FormData(e.target));
      const {
        type: a,
        id: n,
        kind: i
      } = editing;
      if (a === "whatsapp") {
        const e = r.phone.replace(/[\s()+.-]/g, "");
        if (!/^[1-9]\d{7,14}$/.test(e)) {
          throw Error("Enter country code and number (8–15 digits), without a local leading zero.");
        }
        const a = data.customers.find(e => e.id === (data[i].find(e => e.id === n) || {}).customerId);
        if (a && a.phone !== r.phone.trim()) {
          try {
            const e = clone();
            e.customers.find(e => e.id === a.id).phone = r.phone.trim();
            await commit(e);
          } catch {}
        }
        await chrome.runtime.sendMessage({
          type: "wa-open",
          phone: e,
          text: r.message,
          mode: ((await chrome.storage.local.get("hubSettings")).hubSettings || {}).waMode || "window",
          screen: {
            w: screen.availWidth,
            h: screen.availHeight
          }
        });
        $("#dialog").close();
        return;
      }
      const s = clone();
      const o = s[a]?.find(e => e.id === n);
      let d;
      if (["orders", "quotes"].includes(a)) {
        d = {
          ...o,
          id: n || Core.id(),
          number: o?.number || Core.number(s, a === "quotes" ? "QTN" : "INV"),
          customerId: r.customerId,
          description: r.description.trim(),
          date: r.date,
          status: r.status,
          due: r.due || "",
          deadline: r.deadline || "",
          finishDate: r.finishDate || "",
          note: r.note,
          items: structuredClone(readItems()),
          discountType: r.discountType,
          discount: Number(r.discount),
          taxRate: Number(r.taxRate),
          attachments: draftAttachments,
          tasks: draftTasks
        };
        if (a === "orders") {
          d.payments = o?.payments || [];
          d.refunds = o?.refunds || [];
          d.returns = o?.returns || [];
          d.sourceQuote = o?.sourceQuote || "";
          d.tasks = draftTasks;
          if (financialLocked(o) && financialSignature(o) !== financialSignature(d)) {
            throw Error("Financial fields are locked after payments/returns. Keep the original values and use Return / credit.");
          }
          Core.saveOrder(s, d);
        } else {
          if (o?.orderId) {
            throw Error("Converted quotations are read-only.");
          }
          d.validUntil = r.validUntil;
          d.orderId = "";
          s.quotes = s.quotes.filter(e => e.id !== n);
          s.quotes.push(d);
        }
      } else if (a === "payment" || a === "refund") {
        const e = s.orders.find(e => e.id === n);
        const i = Core.round(r.amount);
        const o = a === "payment" ? Core.balance(e) : -Core.balance(e);
        if (i <= 0 || i > o) {
          throw Error("Amount exceeds the available balance.");
        }
        e[a === "payment" ? "payments" : "refunds"].push({
          id: Core.id(),
          date: r.date,
          amount: i,
          method: r.method,
          note: r.note
        });
      } else if (a === "return") {
        Core.addReturn(s, n, {
          date: r.date,
          itemId: r.itemId,
          quantity: Number(r.quantity),
          restock: r.restock === "yes",
          reason: r.reason
        });
      } else if (a === "attachments") {
        s[i].find(e => e.id === n).attachments = structuredClone(draftAttachments);
      } else {
        d = {
          ...o,
          ...r,
          id: n || Core.id()
        };
        if (a === "expenses") {
          d.amount = Core.round(r.amount);
        }
        if (a === "products") {
          for (const e of ["stock", "threshold", "price", "cost"]) {
            d[e] = Number(r[e]);
          }
        }
        if (a === "services") {
          d.amount = Core.round(r.amount);
          d.interval = Number(r.interval);
          d.active = r.active === "yes";
          d.anchorDay = o && o.nextDate === d.nextDate ? o.anchorDay : Number(d.nextDate.slice(8));
          d.history = o?.history || [];
          d.autoInvoice = r.autoInvoice === "yes";
          d.nextInvoiceDate = r.nextInvoiceDate || d.nextDate;
          d.invoiceAnchor = o && o.nextInvoiceDate === d.nextInvoiceDate ? o.invoiceAnchor : Number(d.nextInvoiceDate.slice(8));
          d.invoiceCycles = o?.invoiceCycles || [];
          d.invoiceDueDays = Number(r.invoiceDueDays ?? 7);
        }
        s[a] = s[a].filter(e => e.id !== n);
        s[a].push(d);
      }
      await commit(s);
      $("#dialog").close();
      toast("Saved successfully.");
    } catch (e) {
      $("#formError").textContent = e.message;
    } finally {
      busy = false;
      $("#saveButton").disabled = false;
    }
  }
}
