"use strict";

async function readXLSX(t) {
  const e = await t.arrayBuffer();
  const n = new DataView(e);
  let s = -1;
  for (let t = e.byteLength - 22; t >= Math.max(0, e.byteLength - 65557); t--) {
    if (n.getUint32(t, true) === 101010256) {
      s = t;
      break;
    }
  }
  if (s < 0) {
    throw Error("Invalid XLSX ZIP.");
  }
  const o = n.getUint16(s + 10, true);
  let i = n.getUint32(s + 16, true);
  let a = 0;
  if (o > 500) {
    throw Error("Workbook has too many files.");
  }
  for (let t = 0; t < o; t++) {
    if (n.getUint32(i, true) !== 33639248) {
      throw Error("Invalid ZIP directory.");
    }
    a += n.getUint32(i + 24, true);
    if (a > 26214400) {
      throw Error("Workbook expands beyond 25 MB.");
    }
    i += 46 + n.getUint16(i + 28, true) + n.getUint16(i + 30, true) + n.getUint16(i + 32, true);
  }
  const c = await JSZip.loadAsync(e);
  const x = async t => {
    const n = c.file(t);
    if (!n) {
      throw Error("Missing workbook part: " + t);
    }
    const s = await n.async("string");
    if (/<!DOCTYPE/i.test(s)) {
      throw Error("Unsupported XML document type.");
    }
    const o = new DOMParser().parseFromString(s, "application/xml");
    if (o.getElementsByTagName("parsererror").length) {
      throw Error("Invalid workbook XML.");
    }
    return o;
  };
  const _ = (t, r) => [...t.getElementsByTagNameNS("*", r)];
  const l = c.file("xl/sharedStrings.xml") ? _(await x("xl/sharedStrings.xml"), "si").map(t => _(t, "t").map(t => t.textContent).join("")) : [];
  const f = await x("xl/workbook.xml");
  const m = _(f, "sheet")[0];
  if (!m) {
    throw Error("No worksheet.");
  }
  const w = m.getAttribute("r:id") || m.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
  const u = await x("xl/_rels/workbook.xml.rels");
  const g = _(u, "Relationship").find(t => t.getAttribute("Id") === w);
  if (!g || g.getAttribute("TargetMode") === "External") {
    throw Error("Unsupported worksheet reference.");
  }
  let h = g.getAttribute("Target");
  h = h.startsWith("/") ? h.slice(1) : "xl/" + h;
  if (h.includes("..")) {
    throw Error("Unsupported worksheet path.");
  }
  const b = await x(h);
  return {
    rows: _(b, "row").map(t => {
      const n = [];
      for (const r of _(t, "c")) {
        if (_(r, "f").length) {
          throw Error("Formula cells are not imported. Paste values in Excel first.");
        }
        const t = r.getAttribute("r") || "";
        const s = t.match(/^[A-Z]+/)?.[0];
        if (!s) {
          continue;
        }
        let o = 0;
        for (const t of s) {
          o = o * 26 + t.charCodeAt(0) - 64;
        }
        if (o > 50) {
          throw Error("Use a simple table with at most 50 columns.");
        }
        const i = r.getAttribute("t");
        const a = _(r, "v")[0]?.textContent || "";
        n[o - 1] = i === "s" ? l[Number(a)] || "" : i === "inlineStr" ? _(r, "t").map(t => t.textContent).join("") : a;
      }
      return n;
    }).filter(t => t.some(t => String(t || "").trim())),
    sheet: m.getAttribute("name")
  };
}
