"use strict";

readCloud().then(initV4).catch(t => toast(t.message));
