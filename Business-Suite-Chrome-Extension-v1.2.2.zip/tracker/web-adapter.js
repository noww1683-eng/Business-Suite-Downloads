"use strict";

const IS_EXTENSION = Boolean(globalThis.chrome?.runtime?.id);
if (!IS_EXTENSION) {
  const e = new Promise((e, r) => {
    const s = indexedDB.open("work-tracker-v4", 1);
    s.onupgradeneeded = () => s.result.createObjectStore("kv");
    s.onsuccess = () => e(s.result);
    s.onerror = () => r(s.error);
  });
  const r = {
    async get(r) {
      const t = await e;
      return new Promise((e, s) => {
        const a = t.transaction("kv");
        const o = a.objectStore("kv");
        const _ = {};
        let c = typeof r == "string" ? [r] : Array.isArray(r) ? r : Object.keys(r || {});
        if (r) {
          for (const e of c) {
            const r = o.get(e);
            r.onsuccess = () => {
              if (r.result !== undefined) {
                _[e] = r.result;
              }
            };
          }
        } else {
          const e = o.openCursor();
          e.onsuccess = () => {
            const t = e.result;
            if (t) {
              _[t.key] = t.value;
              t.continue();
            }
          };
        }
        a.oncomplete = () => e(_);
        a.onerror = () => s(a.error);
      });
    },
    async set(r) {
      const t = await e;
      await new Promise((e, s) => {
        const a = t.transaction("kv", "readwrite");
        for (const [e, t] of Object.entries(r)) {
          a.objectStore("kv").put(t, e);
        }
        a.oncomplete = e;
        a.onerror = () => s(a.error);
        a.onabort = () => s(a.error || Error("Browser storage write failed."));
      });
    }
  };
  const t = {
    async get(e) {
      const t = typeof e == "string" ? [e] : e;
      const s = {};
      for (const e of t) {
        const t = sessionStorage.getItem("tracker-" + e);
        if (t) {
          s[e] = JSON.parse(t);
        }
      }
      return s;
    },
    async set(e) {
      for (const [t, s] of Object.entries(e)) {
        sessionStorage.setItem("tracker-" + t, JSON.stringify(s));
      }
    },
    async remove(e) {
      sessionStorage.removeItem("tracker-" + e);
    }
  };
  let s = 0;
  globalThis.chrome = {
    storage: {
      local: r,
      session: t
    },
    tabs: {
      async create({
        url: e
      }) {
        window.open(e, "_blank", "noopener,noreferrer");
        return {
          id: 0
        };
      }
    },
    notifications: {
      async create(e, {
        title: r,
        message: t
      }) {
        throw Error("Desktop notifications are available in the Chrome extension. Use Reminders on mobile/web.");
      }
    },
    downloads: {
      onChanged: {
        addListener() {},
        removeListener() {}
      },
      search: async () => [{
        state: "complete"
      }],
      async download({
        url: e,
        filename: r
      }) {
        const n = document.createElement("a");
        n.href = e;
        n.download = r.split("/").at(-1);
        n.click();
        return ++s;
      }
    }
  };
}
