"use strict";

async function importV4(t) {
  if (t.size > 104857600) {
    throw Error("Maximum JSON backup: 100 MB.");
  }
  const r = JSON.parse(await t.text());
  if (r.app === "work-tracker-suite") {
    const t = Plus.migrate(r);
    if (!confirm("Replace ALL " + suiteData.businesses.length + " local businesses with " + t.businesses.length + " businesses? An all-business backup must finish first.")) {
      return;
    }
    await allBackup("before-import");
    await persistSuite(t);
  } else {
    const t = Plus.upgrade(Core.migrate(r));
    if (!confirm("Replace only " + data.business + " with this single-business backup? Other businesses remain unchanged.")) {
      return;
    }
    await backup("before-import", false);
    await commit(t);
  }
  detail = null;
  tab = "dashboard";
  render();
  toast("Import complete.");
}
document.addEventListener("click", async t => {
  const r = t.target.closest("button[data-action]");
  if (!r || busy) {
    return;
  }
  const {
    action: s,
    type: i,
    id: a
  } = r.dataset;
  if (["convertLead", "generateDrafts", "issueDraft", "discardDraft", "applyPackage", "stopTimer", "deleteTask", "correctPayment", "voidPayment", "undoPayment", "switchBusiness", "allBackup", "importTemplate", "confirmTableImport"].includes(s)) {
    busy = true;
    try {
      if (s === "convertLead") {
        const t = clone();
        const r = t.leads.find(t => t.id === a);
        if (r.customerId) {
          throw Error("Lead already converted.");
        }
        const s = t => t.replace(/\D/g, "");
        const i = t.customers.find(t => r.phone && s(t.phone) === s(r.phone) || r.email && t.email.toLowerCase() === r.email.toLowerCase());
        if (i) {
          if (!confirm("Link this lead to existing customer " + i.name + "?")) {
            return;
          }
          r.customerId = i.id;
        } else {
          const s = {
            id: Core.id(),
            name: r.name,
            phone: r.phone,
            email: r.email,
            address: "",
            date: Core.today()
          };
          t.customers.push(s);
          r.customerId = s.id;
        }
        r.stage = "won";
        await commit(t);
        toast("Lead linked to customer.");
      }
      if (s === "generateDrafts") {
        const t = clone();
        const r = Plus.generate(t);
        await commit(t);
        toast(r + " draft(s) generated.");
      }
      if (s === "issueDraft") {
        const t = data.invoiceDrafts.find(t => t.id === a);
        if (!confirm("Issue invoice for " + name(t.customerId) + ": " + money(t.amount) + ", dated " + t.cycle + ", due " + t.due + "? It uses 0% tax and zero direct cost. Edit these before recording payment if needed.")) {
          return;
        }
        const r = clone();
        const s = Plus.issue(r, a);
        await commit(r);
        tab = "orders";
        detail = s;
        render();
      }
      if (s === "discardDraft") {
        if (!confirm("Discard this draft? It will not regenerate for this billing cycle.")) {
          return;
        }
        const t = clone();
        const r = t.invoiceDrafts.find(t => t.id === a);
        if (r.status !== "draft") {
          throw Error("Only an unissued draft can be discarded.");
        }
        r.status = "discarded";
        await commit(t);
      }
      if (s === "applyPackage") {
        const t = data.packages.find(t => t.id === $("#packageChoice").value);
        if (!t) {
          throw Error("Choose a service package.");
        }
        readItems();
        if (draftItems.length === 1 && !draftItems[0].description && !draftItems[0].price) {
          draftItems = [];
        }
        if (draftItems.length >= 100) {
          throw Error("Maximum 100 item lines.");
        }
        draftItems.push({
          id: Core.id(),
          productId: "",
          description: t.description || t.name,
          quantity: 1,
          price: t.price,
          cost: t.cost
        });
        draftTasks.push(...t.checklist.split("\n").map(t => t.trim()).filter(Boolean).map(t => ({
          id: Core.id(),
          text: t,
          done: false
        })));
        $("#itemRows").innerHTML = draftItems.map(itemRow).join("");
        liveTotal();
      }
      if (s === "stopTimer") {
        const t = clone();
        Plus.stopTimer(t);
        await commit(t);
      }
      if (s === "deleteTask") {
        const t = clone();
        const r = t.orders.find(t => t.id === i);
        r.tasks = r.tasks.filter(t => t.id !== a);
        await commit(t);
      }
      if (s === "correctPayment" || s === "voidPayment") {
        correctionForm(s === "voidPayment" ? "void" : "correct", i, a);
      }
      if (s === "undoPayment") {
        editing = {
          type: "auditUndo",
          id: a
        };
        $("#formTitle").textContent = "Undo payment change";
        $("#saveButton").textContent = "Undo with audit";
        $("#formError").textContent = "";
        $("#fields").innerHTML = field("Reason for undo *", "reason", "", "text", "required") + "<p class=\"wide help\">Only the latest change for this payment can be undone. Refund constraints are rechecked.</p>";
        $("#dialog").showModal();
      }
      if (s === "switchBusiness") {
        await switchBusiness(a);
      }
      if (s === "allBackup") {
        await allBackup();
      }
      if (s === "importTemplate") {
        const t = $("#importKind").value;
        const r = t === "customers" ? [["name", "phone", "email", "address", "date"], ["Example Client", "919999999999", "client@example.com", "Kerala", Core.today()]] : [["name", "sku", "stock", "threshold", "price", "cost"], ["Example Product", "SKU001", 10, 3, 100, 60]];
        await download(t + "-template.csv", csv(r), "text/csv");
      }
      if (s === "confirmTableImport") {
        if (!importPreview) {
          throw Error("Preview a file first.");
        }
        if (importPreview.businessId !== suiteData.activeId || importPreview.revision !== storeRevision) {
          throw Error("Workspace changed. Preview the import again.");
        }
        const t = clone();
        t[importPreview.kind].push(...importPreview.accepted);
        const r = importPreview.accepted.length;
        await commit(t);
        importPreview = null;
        toast(r + " records imported.");
      }
    } catch (t) {
      if ($("#dialog").open) {
        $("#formError").textContent = t.message;
      } else {
        toast(t.message);
      }
    } finally {
      busy = false;
    }
  }
});
document.addEventListener("change", async t => {
  if (!busy) {
    try {
      if (t.target.id === "businessChooser") {
        busy = true;
        await switchBusiness(t.target.value);
      }
      if (t.target.dataset.task) {
        busy = true;
        const r = clone();
        const s = r.orders.find(r => r.id === t.target.dataset.order);
        s.tasks.find(r => r.id === t.target.dataset.task).done = t.target.checked;
        await commit(r);
      }
      if (t.target.id === "dashRange") {
        dashboardRange = t.target.value;
        dashboard();
      }
      if (["rangeStart", "rangeEnd"].includes(t.target.id)) {
        const r = t.target.value;
        if (!Core.date(r)) {
          return;
        }
        if (t.target.id === "rangeStart") {
          rangeStart = r;
        } else {
          rangeEnd = r;
        }
        if (rangeStart > rangeEnd) {
          toast("Start date must not be after end date.");
          return;
        }
        dashboard();
      }
      if (t.target.id === "importKind") {
        importPreview = null;
        $("#importPreview").innerHTML = "";
      }
      if (t.target.id === "tableFile") {
        busy = true;
        const r = t.target.files[0];
        t.target.value = "";
        if (!r) {
          return;
        }
        if (r.size > 5242880) {
          throw Error("Maximum file size: 5 MB.");
        }
        const s = $("#importKind").value;
        let i;
        let a = "CSV";
        if (/\.xlsx$/i.test(r.name)) {
          const t = await readXLSX(r);
          i = t.rows;
          a = t.sheet;
        } else {
          if (!/\.csv$/i.test(r.name)) {
            throw Error("Choose CSV or XLSX. Old .xls files must be saved as XLSX/CSV.");
          }
          i = Plus.parseCSV(await r.text());
        }
        importPreview = {
          ...Plus.importRows(data, s, i),
          kind: s,
          businessId: suiteData.activeId,
          revision: storeRevision
        };
        const n = importPreview;
        $("#importPreview").innerHTML = "<h3>Preview · " + esc(a) + "</h3><p>" + n.accepted.length + " valid · " + n.skipped.length + " duplicates skipped · " + n.errors.length + " invalid rows</p>" + table(["Name", "Phone / SKU"], n.accepted.slice(0, 20).map(t => [esc(t.name), esc(t.phone || t.sku || "")])) + (n.errors.length ? table(["Row", "Error"], n.errors.slice(0, 20).map(t => [t.row, esc(t.message)])) : "") + (n.accepted.length ? btn("confirmTableImport", "Import " + n.accepted.length + " valid records", "", "", "primary") : "") + "<p class=\"small muted\">Only valid, non-duplicate records are imported. Invalid and duplicate rows remain unchanged.</p>";
      }
    } catch (t) {
      toast(t.message);
    } finally {
      busy = false;
    }
  }
});
