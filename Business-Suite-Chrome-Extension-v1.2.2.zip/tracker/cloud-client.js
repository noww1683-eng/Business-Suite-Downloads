"use strict";

let cloudProfile = null;
let cloudToken = "";
let cloudRemoteInfo = null;
async function readCloud() {
  const o = await chrome.storage.local.get("trackerCloud");
  const t = await chrome.storage.session.get("trackerCloudToken");
  cloudProfile = o.trackerCloud || {
    url: IS_EXTENSION ? "" : location.origin,
    lastVersion: null
  };
  cloudToken = t.trackerCloudToken || "";
}
function cloudView() {
  $("#view").innerHTML = "<section class=\"panel\"><h2>Cloud backup & mobile access</h2><p>Connect to your own Work Tracker server. A deployable server and mobile web app are included in the download.</p><p class=\"help\">No hosted account is preconfigured. After deployment, open the same HTTPS address on your phone and log in. Use Pull latest before editing on another device; Push backup after saving. This is manual snapshot sync, not live merging.</p><form id=\"cloudLogin\"><div class=\"fields\">" + field("Server HTTPS URL", "url", cloudProfile?.url || (IS_EXTENSION ? "" : location.origin), "url", "required") + field("Username", "username", "", "text", "required autocomplete=\"username\"") + field("Password", "password", "", "password", "required autocomplete=\"current-password\"") + "</div><div class=\"actions\"><button class=\"primary\" type=\"submit\">Log in / Connect</button></div></form><div class=\"toolbar\">" + btn("cloudPush", "Push ALL businesses") + btn("cloudPull", "Pull latest snapshot") + btn("cloudLogout", "Log out") + "</div><p>" + (cloudToken ? "Session connected" : "Not logged in") + " · Last synced cloud version: " + (cloudProfile?.lastVersion ?? "None") + "</p><p id=\"cloudStatus\" class=\"muted\">" + (cloudRemoteInfo ? esc(cloudRemoteInfo) : "") + "</p></section>";
}
async function cloudCall(e, o = {}) {
  if (!cloudProfile?.url) {
    throw Error("Connect to your server first.");
  }
  const r = await fetch(cloudProfile.url + e, {
    ...o,
    redirect: "error",
    headers: {
      "Content-Type": "application/json",
      ...(cloudToken ? {
        Authorization: "Bearer " + cloudToken
      } : {}),
      ...o.headers
    }
  });
  let n;
  try {
    n = await r.json();
  } catch {
    throw Error("Server returned an invalid response. Check the URL.");
  }
  if (!r.ok) {
    throw Error(n.error || "Cloud request failed.");
  }
  return n;
}
async function saveCloud() {
  await chrome.storage.local.set({
    trackerCloud: cloudProfile
  });
}
document.addEventListener("submit", async e => {
  if (e.target.id === "cloudLogin" && (e.preventDefault(), !busy)) {
    busy = true;
    try {
      const t = Object.fromEntries(new FormData(e.target));
      const r = new URL(t.url);
      if (r.username || r.password || r.search || r.hash || r.pathname !== "/" && r.pathname !== "") {
        throw Error("Use only the server origin, without a path or embedded credentials.");
      }
      if (r.protocol !== "https:" && (r.protocol !== "http:" || !["localhost", "127.0.0.1"].includes(r.hostname))) {
        throw Error("HTTPS is required except for local testing.");
      }
      if (!IS_EXTENSION && r.origin !== location.origin) {
        throw Error("On mobile/web, connect to this page’s own server address.");
      }
      if (IS_EXTENSION) {
        if (!(await chrome.permissions.request({
          origins: [r.protocol + "//" + r.hostname + "/*"]
        }))) {
          throw Error("Server access permission was not granted.");
        }
      }
      const n = cloudProfile?.url !== r.origin;
      cloudProfile = {
        url: r.origin,
        lastVersion: n ? null : cloudProfile?.lastVersion ?? null
      };
      cloudToken = "";
      const s = await cloudCall("/api/login", {
        method: "POST",
        body: JSON.stringify({
          username: t.username,
          password: t.password
        })
      });
      cloudToken = s.token;
      await chrome.storage.session.set({
        trackerCloudToken: cloudToken
      });
      await saveCloud();
      const l = await cloudCall("/api/state");
      cloudRemoteInfo = "Cloud version " + l.version + ". " + (l.state ? l.state.businesses.length + " businesses stored. Pull before editing on a new device." : "Empty server: push your first backup.");
      render();
      toast("Connected.");
    } catch (e) {
      toast(e.message);
    } finally {
      busy = false;
    }
  }
});
document.addEventListener("click", async e => {
  const t = e.target.closest("button[data-action]");
  if (t && !busy && ["cloudPush", "cloudPull", "cloudLogout"].includes(t.dataset.action)) {
    busy = true;
    try {
      const e = t.dataset.action;
      if (e === "cloudLogout") {
        if (cloudToken) {
          try {
            await cloudCall("/api/logout", {
              method: "POST",
              body: "{}"
            });
          } catch {}
        }
        cloudToken = "";
        await chrome.storage.session.remove("trackerCloudToken");
        render();
        return;
      }
      if (!cloudToken) {
        throw Error("Log in first.");
      }
      if (e === "cloudPush") {
        const e = await cloudCall("/api/state");
        if (e.version !== 0 && cloudProfile.lastVersion === null) {
          throw Error("This server has data. Pull its snapshot first, or use a separate server for this workspace.");
        }
        const t = e.version === 0 ? 0 : cloudProfile.lastVersion ?? 0;
        if (e.version !== t) {
          throw Error("Another device updated the cloud. Export a local backup, then pull the latest snapshot before continuing.");
        }
        if (!confirm("Upload ALL " + suiteData.businesses.length + " businesses to " + cloudProfile.url + "? The server keeps previous snapshots.")) {
          return;
        }
        const r = await cloudCall("/api/state", {
          method: "PUT",
          body: JSON.stringify({
            expectedVersion: t,
            state: suiteData
          })
        });
        cloudProfile.lastVersion = r.version;
        await saveCloud();
        cloudRemoteInfo = "Backup saved · version " + r.version;
        render();
        toast("Cloud backup saved.");
      }
      if (e === "cloudPull") {
        const e = await cloudCall("/api/state");
        if (!e.state) {
          throw Error("Cloud is empty. Push the first backup from your main device.");
        }
        const t = Plus.validateSuite(e.state);
        if (!confirm("Replace all local businesses with cloud version " + e.version + " (" + t.businesses.length + " businesses)? Local unsynced changes will be replaced. A local backup must finish first.")) {
          return;
        }
        await allBackup("before-cloud-pull");
        await persistSuite(t);
        cloudProfile.lastVersion = e.version;
        await saveCloud();
        tab = "cloud";
        detail = null;
        cloudRemoteInfo = "Pulled cloud version " + e.version;
        render();
        toast("Cloud snapshot loaded.");
      }
    } catch (e) {
      toast(e.message);
    } finally {
      busy = false;
    }
  }
});
