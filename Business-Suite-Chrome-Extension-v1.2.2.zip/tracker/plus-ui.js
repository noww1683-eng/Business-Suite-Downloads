"use strict";

let suiteData = null;
let storeRevision = 0;
let draftTasks = [];
let importPreview = null;
let dashboardRange = "all";
let rangeStart = Core.today();
let rangeEnd = Core.today();
Object.assign(labels, {
  leads: "Leads & follow-up",
  packages: "Service packages",
  invoiceDrafts: "Invoice drafts",
  tasks: "Task checklist",
  timeLogs: "Time tracker",
  businesses: "Businesses",
  importer: "Excel / CSV import",
  cloud: "Cloud & mobile"
});
const oldRender = render;
const oldRecords = records;
const oldDashboard = dashboard;
const oldDetail = detailView;
const oldOpenForm = openForm;
const oldSubmitRecord = submitRecord;
const oldFinancialLocked = financialLocked;
async function persistSuite(e, t = storeRevision) {
  Plus.validateSuite(e);
  await navigator.locks.request("work-tracker-write", async () => {
    const r = await chrome.storage.local.get("trackerSuiteV4");
    if (r.trackerSuiteV4 && r.trackerSuiteV4.revision !== t) {
      throw Error("Workspace changed in another tab or background. Reload before saving.");
    }
    e.revision = t + 1;
    await chrome.storage.local.set({
      trackerSuiteV4: e
    });
    suiteData = e;
    storeRevision = e.revision;
    data = e.businesses.find(t => t.id === e.activeId).data;
  });
  render();
}
function plusRows() {
  if (tab === "leads") {
    return table(["Lead", "Contact", "Source", "Stage", "Follow-up", "Actions"], data.leads.map(t => [esc(t.name), esc(t.phone || t.email), esc(t.source), badge(t.stage), esc(t.followup || "—"), editActions("leads", t.id) + (t.customerId ? btn("history", "Client history", "customers", t.customerId) : btn("convertLead", "Make customer", "leads", t.id))]));
  } else if (tab === "packages") {
    return table(["Package", "Price", "Direct cost", "Checklist", "Actions"], data.packages.map(t => [esc(t.name), money(t.price), money(t.cost), t.checklist.split("\n").filter(Boolean).length + " tasks", editActions("packages", t.id)]));
  } else if (tab === "invoiceDrafts") {
    return table(["Cycle", "Customer", "Service", "Amount", "Status", "Actions"], data.invoiceDrafts.map(t => [esc(t.cycle), esc(name(t.customerId)), esc(t.description), money(t.amount), badge(t.status), t.status === "draft" ? btn("issueDraft", "Review & issue", "invoiceDrafts", t.id) + btn("discardDraft", "Discard", "invoiceDrafts", t.id) : t.orderId ? btn("detail", "Open invoice", "orders", t.orderId) : ""]));
  } else {
    return "";
  }
}
function tasksView() {
  const t = data.orders.filter(t => t.status !== "cancelled");
  $("#view").innerHTML = "<div class=\"toolbar\">" + btn("new", "+ Add task", "task", "", "primary") + "</div>" + (t.map(t => "<section class=\"panel\"><div class=\"panel-head\"><h2>" + esc(t.number) + " · " + esc(t.description) + "</h2>" + btn("detail", "Open work", "orders", t.id) + "</div>" + (t.tasks.length ? t.tasks.map(s => "<div class=\"stock-row\"><label><input type=\"checkbox\" data-task=\"" + esc(s.id) + "\" data-order=\"" + esc(t.id) + "\" " + (s.done ? "checked" : "") + "> <span class=\"" + (s.done ? "task-done" : "") + "\">" + esc(s.text) + "</span></label>" + btn("deleteTask", "Remove", t.id, s.id) + "</div>").join("") : "<p class=\"muted\">No tasks yet.</p>") + "</section>").join("") || "<p class=\"empty\">Create an order before adding tasks.</p>");
}
financialLocked = e => oldFinancialLocked(e) || Boolean(e && data.paymentAudit?.some(t => t.orderId === e.id));
commit = async function (e, t = storeRevision) {
  e = Plus.upgrade(e);
  Plus.generate(e);
  Plus.validate(e);
  const i = structuredClone(suiteData);
  i.businesses.find(e => e.id === i.activeId).data = e;
  await persistSuite(i, t);
};
render = function () {
  oldRender();
  let t = $("#businessChooser");
  if (!t) {
    t = document.createElement("select");
    t.id = "businessChooser";
    t.setAttribute("aria-label", "Active business");
    document.querySelector(".header-actions").prepend(t);
  }
  t.innerHTML = suiteData.businesses.map(t => "<option value=\"" + esc(t.id) + "\" " + (t.id === suiteData.activeId ? "selected" : "") + ">" + esc(t.data.business) + "</option>").join("");
};
records = function () {
  if (!["leads", "packages", "invoiceDrafts"].includes(tab)) {
    if (tab === "tasks") {
      return tasksView();
    } else if (tab === "timeLogs") {
      return timeView();
    } else if (tab === "businesses") {
      return businessesView();
    } else if (tab === "importer") {
      return importerView();
    } else if (tab === "cloud") {
      return cloudView();
    } else {
      return oldRecords();
    }
  }
  $("#view").innerHTML = "<div class=\"toolbar\">" + (tab !== "invoiceDrafts" ? btn("new", "+ Add " + (tab === "leads" ? "lead" : "package"), tab, "", "primary") : btn("generateDrafts", "Generate due drafts", "", "", "primary")) + "</div><section class=\"panel\">" + plusRows() + "</section>" + (tab === "invoiceDrafts" ? "<p class=\"help\">Drafts do not affect revenue or stock. Review and issue to create an invoice. Automatic drafts are generated from enabled recurring services while Chrome is running or when you reopen the app. They are never sent automatically.</p>" : "");
};
const duration = e => Math.floor(e / 3600) + "h " + Math.floor(e % 3600 / 60) + "m " + Math.floor(e % 60) + "s";
function timeView() {
  const t = data.runningTimer;
  $("#view").innerHTML = "<div class=\"toolbar\">" + (t ? btn("stopTimer", "Stop timer", "", "", "primary") : btn("new", "Start timer", "timer", "", "primary")) + btn("new", "+ Manual time", "timeLogs") + "</div>" + (t ? "<section class=\"panel\"><h2>Timer running · " + esc(data.orders.find(s => s.id === t.orderId)?.description) + "</h2><strong id=\"elapsed\">" + duration(Math.max(0, (Date.now() - t.started) / 1000)) + "</strong><p class=\"muted\">Includes time while this tab/browser is closed. Stop and review the recorded entry when you return.</p></section>" : "") + "<section class=\"panel\"><h3>Time entries</h3>" + table(["Date", "Order", "Duration", "Note", ""], data.timeLogs.map(t => [esc(t.date), esc(data.orders.find(e => e.id === t.orderId)?.number), duration(t.seconds), esc(t.note), editActions("timeLogs", t.id)])) + "</section><section class=\"panel\"><h3>Revenue per tracked hour</h3>" + table(["Order", "Time", "Net sales excl tax", "Revenue / hour"], data.orders.filter(t => t.status !== "cancelled").map(t => {
    const i = Core.sum(data.timeLogs.filter(e => e.orderId === t.id), e => e.seconds);
    const r = Core.round(Core.totals(t).net - Core.sum(t.returns, e => e.net));
    return [esc(t.number), duration(i), money(r), i ? money(r / (i / 3600)) : "—"];
  })) + "</section>";
}
function businessesView() {
  $("#view").innerHTML = "<div class=\"toolbar\">" + btn("new", "+ Add business", "business", "", "primary") + btn("allBackup", "Backup ALL businesses") + "</div><section class=\"panel\">" + table(["Business", "Currency", "Orders", "Action"], suiteData.businesses.map(t => [esc(t.data.business), t.data.currency, t.data.orders.length, t.id === suiteData.activeId ? badge("Current") : btn("switchBusiness", "Switch", "", t.id)])) + "</section><p class=\"help\">Each business keeps separate customers, branding, stock, invoices and settings. The selector at the top changes business. Single-business backups affect only the active business; all-business backups preserve every business. No business deletion button is provided.</p>";
}
function dashboardDates() {
  const t = Core.today();
  if (dashboardRange === "today") {
    return [t, t];
  }
  if (dashboardRange === "month") {
    return [t.slice(0, 7) + "-01", t];
  }
  if (dashboardRange === "week") {
    const s = new Date(t + "T12:00:00").getDay();
    return [Core.addDays(t, -(s + 6) % 7), t];
  }
  if (dashboardRange === "custom") {
    return [rangeStart, rangeEnd];
  } else {
    return ["", "9999-12-31"];
  }
}
function correctionForm(e, t, s) {
  const r = data.orders.find(e => e.id === t).payments.find(e => e.id === s);
  editing = {
    type: "correction",
    id: s,
    orderId: t,
    operation: e
  };
  $("#formTitle").textContent = e === "void" ? "Void recorded payment" : "Correct recorded payment";
  $("#saveButton").textContent = "Save with audit";
  $("#formError").textContent = "";
  $("#fields").innerHTML = (e === "void" ? "<p class=\"wide help\">Void " + money(r.amount) + " recorded on " + esc(r.date) + "? This reverses the record, not an actual bank transaction.</p>" : field("Amount", "amount", r.amount, "number", "required min=\"0.01\" max=\"1000000000000\" step=\"0.01\"") + field("Date", "date", r.date, "date", "required") + field("Method", "method", r.method) + field("Reference / note", "note", r.note)) + field("Reason for correction *", "reason", "", "text", "required");
  $("#dialog").showModal();
}
setInterval(() => {
  const t = $("#elapsed");
  if (t && data.runningTimer) {
    t.textContent = duration(Math.max(0, (Date.now() - data.runningTimer.started) / 1000));
  }
}, 1000);
dashboard = function () {
  oldDashboard();
  const [t, s] = dashboardDates();
  const i = Plus.rangeStats(data, t, s);
  const r = dashboardRange === "all" ? "All time" : t + " → " + s;
  const a = "<div class=\"cards\">" + card("Sales", money(i.revenue), r, true) + card("Expenses", money(i.expenses), r) + card("Profit", money(i.profit), "Excludes tax") + card("Cash received", money(i.received), r) + card("Pending payments", money(i.pending), "Current balance of selected orders") + card("New customers", i.customers, r) + card("Orders", i.orders, r) + card("Low stock", data.products.filter(t => t.stock <= t.threshold).length, "Current stock · not date-filtered") + "</div>";
  let n = $("#view").innerHTML;
  n = n.replace(/<div class="cards">[\s\S]*?<div class="columns">/, a + "<div class=\"columns\">");
  $("#view").innerHTML = "<div class=\"toolbar\"><select id=\"dashRange\" aria-label=\"Dashboard period\">" + [["all", "All time"], ["today", "Today"], ["week", "This week"], ["month", "This month"], ["custom", "Custom dates"]].map(([t, s]) => "<option value=\"" + t + "\" " + (dashboardRange === t ? "selected" : "") + ">" + s + "</option>").join("") + "</select>" + (dashboardRange === "custom" ? "<label>From <input id=\"rangeStart\" type=\"date\" value=\"" + rangeStart + "\"></label><label>To <input id=\"rangeEnd\" type=\"date\" value=\"" + rangeEnd + "\"></label>" : "") + "</div>" + n;
};
detailView = function () {
  oldDetail();
  if (tab === "orders" && detail) {
    const t = data.orders.find(e => e.id === detail);
    if (!t) {
      return;
    }
    $("#view").insertAdjacentHTML("beforeend", "<section class=\"panel\"><h3>Tasks & time</h3><p>" + t.tasks.filter(e => e.done).length + " / " + t.tasks.length + " tasks complete · " + duration(Core.sum(data.timeLogs.filter(s => s.orderId === t.id), e => e.seconds)) + " tracked</p>" + btn("tab", "Task checklist", "tasks") + btn("tab", "Time tracker", "timeLogs") + "</section><section class=\"panel\"><h3>Payment corrections</h3>" + table(["Date", "Amount", "Action"], t.payments.map(s => [esc(s.date), money(s.amount), btn("correctPayment", "Correct", t.id, s.id) + btn("voidPayment", "Void", t.id, s.id)])) + "<h3>Audit history</h3>" + table(["When", "Change", "Before", "After", "Reason", ""], data.paymentAudit.filter(s => s.orderId === t.id).slice().reverse().map(s => [esc(s.at), esc(s.action), s.before ? money(s.before.amount) + " · " + esc(s.before.date) : "Void", s.after ? money(s.after.amount) + " · " + esc(s.after.date) : "Void", esc(s.reason), btn("undoPayment", "Undo", t.id, s.id)])) + "</section>");
  }
};
openForm = function (e, t = "") {
  if (["orders", "quotes", "services"].includes(e)) {
    oldOpenForm(e, t);
    if (editing.type !== e) {
      return;
    }
    if (e === "services") {
      const e = data.services.find(e => e.id === t) || {};
      $("#fields").insertAdjacentHTML("beforeend", select("Automatic invoice drafts", "autoInvoice", [["no", "Disabled"], ["yes", "Enabled"]], e.autoInvoice ? "yes" : "no") + field("Next invoice cycle date", "nextInvoiceDate", e.nextInvoiceDate || Core.today(), "date", "required") + field("Payment due after (days)", "invoiceDueDays", e.invoiceDueDays ?? 7, "number", "required min=\"0\" max=\"90\" step=\"1\""));
    } else {
      draftTasks = structuredClone(data[e].find(e => e.id === t)?.tasks || []);
      $("#fields").insertAdjacentHTML("afterbegin", "<div class=\"wide toolbar\"><select id=\"packageChoice\" aria-label=\"Service package\"><option value=\"\">Choose a saved service package</option>" + data.packages.map(e => "<option value=\"" + esc(e.id) + "\">" + esc(e.name) + " · " + money(e.price) + "</option>").join("") + "</select>" + btn("applyPackage", "Add package") + "</div>");
    }
    return;
  }
  if (!["leads", "packages", "business", "task", "timer", "timeLogs", "correction", "auditUndo"].includes(e)) {
    return oldOpenForm(e, t);
  }
  let i = data[e]?.find(e => e.id === t) || {};
  let r = "";
  editing = {
    type: e,
    id: t
  };
  $("#formTitle").textContent = (t ? "Edit " : "New ") + e;
  $("#formError").textContent = "";
  $("#saveButton").textContent = "Save";
  const a = data.orders.filter(e => e.status !== "cancelled").map(e => [e.id, e.number + " · " + e.description]);
  if (e === "leads") {
    r = field("Lead name *", "name", i.name || "", "text", "required") + field("Phone", "phone", i.phone || "", "tel") + field("Email", "email", i.email || "", "email") + field("Source", "source", i.source || "") + field("Added date", "date", i.date || Core.today(), "date", "required") + field("Next follow-up", "followup", i.followup || "", "date") + select("Stage", "stage", ["new", "contacted", "interested", "won", "lost"].map(e => [e, e]), i.stage || "new") + "<label class=\"wide\">Notes<textarea name=\"note\">" + esc(i.note || "") + "</textarea></label>";
  }
  if (e === "packages") {
    r = field("Package name *", "name", i.name || "", "text", "required") + field("Description", "description", i.description || "") + field("Price", "price", i.price || 0, "number", numeric) + field("Direct cost", "cost", i.cost || 0, "number", numeric) + "<label class=\"wide\">Default tasks (one per line)<textarea name=\"checklist\">" + esc(i.checklist || "") + "</textarea></label>";
  }
  if (e === "business") {
    r = field("Business name *", "name", "", "text", "required") + select("Currency", "currency", BusinessCurrency.options, "INR");
  }
  if (["task", "timer", "timeLogs"].includes(e)) {
    if (!a.length) {
      return toast("Create an active order first.");
    }
    r = select("Order *", "orderId", a, i.orderId) + (e === "task" ? field("Task *", "text", "", "text", "required") : field("Note", "note", i.note || ""));
    if (e === "timeLogs") {
      r += field("Date", "date", i.date || Core.today(), "date", "required") + field("Minutes worked", "minutes", i.seconds ? i.seconds / 60 : 30, "number", "required min=\"0.0167\" max=\"525600\" step=\"any\"");
    }
  }
  $("#fields").innerHTML = r;
  $("#dialog").showModal();
};
submitRecord = async function (e) {
  if (!["leads", "packages", "business", "task", "timer", "timeLogs", "correction", "auditUndo"].includes(editing.type)) {
    return oldSubmitRecord(e);
  }
  e.preventDefault();
  if (!busy) {
    busy = true;
    try {
      const s = Object.fromEntries(new FormData(e.target));
      const {
        type: i,
        id: r
      } = editing;
      const a = clone();
      if (i === "business") {
        if (suiteData.businesses.length >= 30) {
          throw Error("Maximum 30 businesses.");
        }
        const e = structuredClone(suiteData);
        const i = Plus.fresh();
        i.business = s.name.trim();
        i.currency = s.currency;
        const r = Core.id();
        e.businesses.push({
          id: r,
          data: i
        });
        e.activeId = r;
        await persistSuite(e);
      } else {
        if (["leads", "packages"].includes(i)) {
          const e = a[i].find(e => e.id === r);
          const n = {
            ...e,
            ...s,
            id: r || Core.id()
          };
          if (i === "leads") {
            n.customerId = e?.customerId || "";
          } else {
            n.price = Number(s.price);
            n.cost = Number(s.cost);
          }
          a[i] = a[i].filter(e => e.id !== r);
          a[i].push(n);
        }
        if (i === "task") {
          a.orders.find(e => e.id === s.orderId).tasks.push({
            id: Core.id(),
            text: s.text.trim(),
            done: false
          });
        }
        if (i === "timer") {
          if (a.runningTimer) {
            throw Error("Stop the current timer first.");
          }
          a.runningTimer = {
            id: Core.id(),
            orderId: s.orderId,
            started: Date.now(),
            note: s.note
          };
        }
        if (i === "timeLogs") {
          a.timeLogs = a.timeLogs.filter(e => e.id !== r);
          a.timeLogs.push({
            id: r || Core.id(),
            orderId: s.orderId,
            date: s.date,
            seconds: Math.round(Number(s.minutes) * 60),
            note: s.note
          });
        }
        if (i === "correction") {
          Plus.correctPayment(a, editing.orderId, r, editing.operation === "void" ? null : {
            id: r,
            amount: Core.round(s.amount),
            date: s.date,
            method: s.method,
            note: s.note
          }, s.reason, editing.operation);
        }
        if (i === "auditUndo") {
          Plus.undo(a, r, s.reason);
        }
        await commit(a);
      }
      $("#dialog").close();
      toast("Saved.");
    } catch (e) {
      $("#formError").textContent = e.message;
    } finally {
      busy = false;
    }
  }
};
const baseRemoveRecord = removeRecord;
function importerView() {
  $("#view").innerHTML = "<section class=\"panel\"><h2>Import customers or products</h2><p>CSV or XLSX · first worksheet · values only · up to 5,000 rows / 5 MB</p><div class=\"toolbar\"><select id=\"importKind\"><option value=\"customers\">Customers</option><option value=\"products\">Products</option></select><input id=\"tableFile\" type=\"file\" accept=\".csv,.xlsx\">" + btn("importTemplate", "Download CSV template") + "</div><p class=\"help\">Headers: Customers → name, phone, email, address, date (YYYY-MM-DD). Products → name, sku, stock, threshold, price, cost. Format phone/SKU cells as text in Excel. Duplicate phone/email/name (customers) or SKU/name (products) are skipped.</p><div id=\"importPreview\"></div></section>";
}
async function switchBusiness(e) {
  if (!suiteData.businesses.some(t => t.id === e)) {
    throw Error("Business missing.");
  }
  const s = structuredClone(suiteData);
  s.activeId = e;
  detail = null;
  tab = "dashboard";
  await persistSuite(s);
}
async function allBackup(e = "all-businesses") {
  await download("work-tracker-v4-" + e + "-" + stamp() + ".json", JSON.stringify(suiteData, null, 2));
  if (!IS_EXTENSION && !confirm("Confirm the JSON backup has finished downloading and is saved.")) {
    throw Error("Backup not confirmed.");
  }
  if (e === "all-businesses") {
    const e = structuredClone(suiteData);
    for (const s of e.businesses) {
      s.data.lastBackup = Core.today();
    }
    await persistSuite(e);
  }
  toast("All-business backup downloaded.");
}
async function initV4() {
  try {
    const t = await chrome.storage.local.get(["trackerSuiteV4", "businessV3", "businessV2", "businessMode", "works", "expenses"]);
    suiteData = t.trackerSuiteV4 ? Plus.validateSuite(t.trackerSuiteV4) : Plus.wrap(t.businessV3 || Core.migrate(t.businessV2 || (Array.isArray(t.works) ? t : {
      app: "work-tracker-business",
      ...Core.fresh()
    })));
    storeRevision = suiteData.revision;
    data = suiteData.businesses.find(e => e.id === suiteData.activeId).data;
    mode = t.businessMode === "basic" ? "basic" : "advanced";
    let s = !t.trackerSuiteV4;
    for (const t of suiteData.businesses) {
      if (Plus.generate(t.data)) {
        s = true;
      }
    }
    if (s) {
      await persistSuite(suiteData);
    } else {
      render();
    }
  } catch (t) {
    $("#view").innerHTML = "<section class=\"panel\"><h2>Could not load workspace</h2><p id=\"loadError\"></p></section>";
    $("#loadError").textContent = t.message;
  }
}
removeRecord = async function (e, t) {
  if (e === "orders" && (data.timeLogs.some(e => e.orderId === t) || data.runningTimer?.orderId === t || data.invoiceDrafts.some(e => e.orderId === t))) {
    throw Error("This order has time or recurring-invoice history. Keep the order.");
  }
  if (e === "services" && data.invoiceDrafts.some(e => e.serviceId === t)) {
    throw Error("Pause this service to preserve its invoice history.");
  }
  if (e === "customers" && data.leads.some(e => e.customerId === t)) {
    throw Error("Customer is linked to a converted lead.");
  }
  return baseRemoveRecord(e, t);
};
backup = async function (e = "backup", t = true) {
  const i = clone();
  if (t) {
    i.lastBackup = Core.today();
  }
  await download("work-tracker-v4-" + e + "-" + stamp() + ".json", JSON.stringify(i, null, 2));
  if (!IS_EXTENSION && !confirm("Confirm the JSON backup has finished downloading and is saved.")) {
    throw Error("Backup not confirmed.");
  }
  if (t) {
    const e = clone();
    e.lastBackup = Core.today();
    await commit(e);
  }
  toast("Backup downloaded.");
};
