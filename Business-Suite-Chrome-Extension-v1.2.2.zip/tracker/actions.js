"use strict";

const stamp = () => new Date().toISOString().replace(/[:.]/g, "-");
function csv(e) {
  return "﻿" + e.map(e => e.map(e => {
    let a = String(e ?? "");
    if (typeof e != "number" && /^[\s]*[=+@-]/.test(a)) {
      a = "'" + a;
    }
    return "\"" + a.replace(/"/g, "\"\"") + "\"";
  }).join(",")).join("\r\n");
}
async function download(e, t, r = "application/json") {
  const o = URL.createObjectURL(new Blob([t], {
    type: r
  }));
  try {
    const t = await chrome.downloads.download({
      url: o,
      filename: "WorkTracker/" + e,
      saveAs: true
    });
    await new Promise((e, r) => {
      const a = o => {
        if (o.id === t && (o.state?.current === "complete" || o.state?.current === "interrupted")) {
          chrome.downloads.onChanged.removeListener(a);
          if (o.state.current === "complete") {
            e();
          } else {
            r(Error("Download cancelled or interrupted."));
          }
        }
      };
      chrome.downloads.onChanged.addListener(a);
      chrome.downloads.search({
        id: t
      }).then(e => {
        if (e[0] && ["complete", "interrupted"].includes(e[0].state)) {
          a({
            id: t,
            state: {
              current: e[0].state
            }
          });
        }
      }).catch(e => {
        chrome.downloads.onChanged.removeListener(a);
        r(e);
      });
    });
  } finally {
    setTimeout(() => URL.revokeObjectURL(o), 60000);
  }
}
async function backup(e = "backup", t = true) {
  const a = clone();
  if (t) {
    a.lastBackup = Core.today();
  }
  await download("work-tracker-v3-" + e + "-" + stamp() + ".json", JSON.stringify(a, null, 2));
  if (t) {
    const e = clone();
    e.lastBackup = Core.today();
    await commit(e);
  }
  toast("Backup downloaded.");
}
async function exportSection(e) {
  let r = [];
  let a = [];
  if (["orders", "quotes"].includes(e)) {
    r = ["Number", "Date", "Customer", "Title", "Status", "Subtotal", "Discount", "Tax", "Total", "Received", "Refunded", "Credits", "Balance"];
    a = data[e].map(r => {
      const o = Core.totals(r);
      return [r.number, r.date, name(r.customerId), r.description, r.status, o.subtotal, o.discount, o.tax, o.total, e === "orders" ? Core.paid(r) : "", e === "orders" ? Core.refunded(r) : "", e === "orders" ? Core.credits(r) : "", e === "orders" ? Core.balance(r) : ""];
    });
  } else {
    const o = {
      customers: ["name", "phone", "email", "date", "address"],
      products: ["name", "sku", "stock", "threshold", "price", "cost"],
      expenses: ["date", "title", "category", "amount"],
      services: ["name", "customerId", "nextDate", "interval", "amount", "active", "note"]
    }[e];
    r = o;
    a = data[e].map(e => o.map(t => t === "customerId" ? name(e[t]) : e[t]));
  }
  await download(e + "-" + Core.today() + ".csv", csv([r, ...a]), "text/csv");
}
async function removeRecord(e, t) {
  if (e === "customers" && ["orders", "quotes", "services"].some(e => data[e].some(e => e.customerId === t))) {
    throw Error("This customer has records. Keep the customer to preserve history.");
  }
  if (e === "products" && ["orders", "quotes"].some(e => data[e].some(e => e.items.some(e => e.productId === t)))) {
    throw Error("This product is referenced by a document. Keep it to preserve history.");
  }
  if (e === "orders") {
    const e = data.orders.find(e => e.id === t);
    if (financialLocked(e)) {
      throw Error("Orders with payments/returns cannot be deleted. Use a return and refund where needed.");
    }
    if (data.quotes.some(e => e.orderId === t)) {
      throw Error("This order is linked to a quotation. Cancel the unpaid order instead.");
    }
  }
  if (e === "quotes" && data.quotes.find(e => e.id === t).orderId) {
    throw Error("Converted quotations cannot be deleted.");
  }
  if (e === "services" && data.services.find(e => e.id === t).history.length) {
    throw Error("Pause this service to preserve its renewal history.");
  }
  if (!confirm("Delete this record? This cannot be undone.")) {
    return;
  }
  const a = clone();
  if (e === "orders") {
    const e = a.orders.find(e => e.id === t);
    for (const [t, r] of Core.reserved(e)) {
      a.products.find(e => e.id === t).stock += r;
    }
  }
  a[e] = a[e].filter(e => e.id !== t);
  detail = null;
  await commit(a);
  toast("Record deleted.");
}
function getAttachment(e) {
  for (const t of [...data.orders, ...data.quotes]) {
    const r = t.attachments.find(t => t.id === e);
    if (r) {
      return r;
    }
  }
  throw Error("Attachment not found.");
}
async function readFile(e, t) {
  if (e.size > t) {
    throw Error("File is too large: " + e.name);
  }
  return new Promise((t, a) => {
    const n = new FileReader();
    n.onload = () => t(n.result);
    n.onerror = () => a(Error("Could not read " + e.name));
    n.readAsDataURL(e);
  });
}
async function init() {
  try {
    const t = await chrome.storage.local.get(["businessV3", "businessV2", "businessMode", "works", "expenses"]);
    if (t.businessV3) {
      data = Core.validate(t.businessV3);
    } else if (t.businessV2 || Array.isArray(t.works)) {
      data = Core.migrate(t.businessV2 || t);
      await chrome.storage.local.set({
        businessV3: data
      });
    }
    mode = t.businessMode === "basic" ? "basic" : "advanced";
    render();
  } catch (t) {
    $("#view").innerHTML = "<section class=\"panel\"><h2>Could not open this workspace</h2><p id=\"loadError\"></p><p>Existing data has not been overwritten. Export your previous version’s JSON backup and correct any invalid records before importing.</p></section>";
    $("#loadError").textContent = t.message;
  }
}
document.addEventListener("click", async e => {
  const r = e.target.closest("button[data-action]");
  if (r && !busy) {
    busy = true;
    try {
      const {
        action: e,
        type: a,
        id: o
      } = r.dataset;
      if (e === "tab") {
        go(a.trim());
      }
      if (e === "detail") {
        tab = a;
        detail = o;
        render();
      }
      if (e === "history") {
        tab = "history";
        detail = o;
        render();
      }
      if (e === "new" || e === "edit") {
        openForm(a, o);
      }
      if (e === "close") {
        $("#dialog").close();
      }
      if (e === "delete") {
        await removeRecord(a, o);
      }
      if (["payment", "return", "refund"].includes(e)) {
        openForm(e, o);
      }
      if (e === "attachments") {
        openAttachments(a, o);
      }
      if (e === "whatsapp") {
        openWhatsApp(a, o);
      }
      if (e === "doc") {
        documentRef = {
          kind: a,
          id: o
        };
        tab = "document";
        render();
      }
      if (e === "receipt") {
        documentRef = {
          kind: "orders",
          id: a,
          paymentId: o
        };
        tab = "document";
        render();
      }
      if (e === "print") {
        window.print();
      }
      if (e === "convert") {
        if (!confirm("Convert this quotation to an order? Stock will be reserved, and the quotation will become read-only.")) {
          return;
        }
        const e = clone();
        Core.convertQuote(e, o);
        const r = e.quotes.find(e => e.id === o).orderId;
        await commit(e);
        tab = "orders";
        detail = r;
        render();
        toast("Quotation converted to order.");
      }
      if (e === "renew") {
        if (!confirm("Mark one cycle renewed? This advances the next date but does not record a payment.")) {
          return;
        }
        const e = clone();
        Core.renew(e, o);
        await commit(e);
        toast("Renewal recorded.");
      }
      if (e === "renewOrder") {
        const e = data.services.find(e => e.id === o);
        openForm("orders");
        $("#form [name=customerId]").value = e.customerId;
        $("#form [name=description]").value = e.name + " renewal · " + e.nextDate;
        $("#form [name=due]").value = e.nextDate;
        draftItems = [{
          id: Core.id(),
          productId: "",
          description: e.name,
          quantity: 1,
          price: e.amount,
          cost: 0
        }];
        $("#itemRows").innerHTML = draftItems.map(itemRow).join("");
        liveTotal();
      }
      if (e === "reminder") {
        if (a === "settings") {
          go("settings");
        } else {
          tab = a;
          detail = o;
          render();
        }
      }
      if (e === "testNotify") {
        await chrome.notifications.create("work-tracker-test", {
          type: "basic",
          iconUrl: "icon128.png",
          title: "Work Tracker reminders",
          message: "Desktop reminders are ready. Due items appear in Reminders."
        });
        toast("Notification requested. Check Chrome / system notification settings if it is not visible.");
      }
      if (e === "backup") {
        await backup();
      }
      if (e === "import") {
        $("#importFile").click();
      }
      if (e === "export") {
        await exportSection(a);
      }
      if (e === "reportExport") {
        await download("report-" + reportData().prefix + ".csv", csv([["Period", "Orders", "Sales excl tax", "Tax", "Direct cost", "Expenses", "Profit", "Received", "Refunded", "Net cash"], ...reportRows]), "text/csv");
      }
      if (e === "addItem") {
        readItems();
        if (draftItems.length >= 100) {
          throw Error("Maximum 100 items.");
        }
        draftItems.push(emptyItem());
        $("#itemRows").innerHTML = draftItems.map(itemRow).join("");
        liveTotal();
      }
      if (e === "removeItem") {
        readItems();
        if (draftItems.length === 1) {
          throw Error("Keep at least one item.");
        }
        draftItems = draftItems.filter(e => e.id !== o);
        $("#itemRows").innerHTML = draftItems.map(itemRow).join("");
        liveTotal();
      }
      if (e === "addLink") {
        const e = $("#form");
        const r = e.elements.linkUrl.value.trim();
        const a = e.elements.linkName.value.trim();
        if (!a) {
          throw Error("Enter a link name.");
        }
        let o;
        try {
          o = new URL(r);
        } catch {
          throw Error("Enter a complete https:// or http:// link.");
        }
        if (!["http:", "https:"].includes(o.protocol)) {
          throw Error("Only web links are allowed.");
        }
        if (draftAttachments.length >= 20) {
          throw Error("Maximum 20 attachments.");
        }
        draftAttachments.push({
          id: Core.id(),
          kind: "link",
          name: a,
          url: o.href
        });
        e.elements.linkName.value = "";
        e.elements.linkUrl.value = "";
        drawAttachments();
      }
      if (e === "removeDraftAttachment") {
        draftAttachments = draftAttachments.filter(e => e.id !== o);
        drawAttachments();
      }
      if (e === "attachment") {
        const e = getAttachment(o);
        if (e.kind === "link") {
          await chrome.tabs.create({
            url: e.url
          });
        } else {
          const r = e.data.slice(e.data.indexOf(",") + 1);
          const a = Uint8Array.from(atob(r), e => e.charCodeAt(0));
          const o = e.name.replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").replace(/^\.+/, "_");
          await download("attachments/" + o, a, e.mime);
        }
      }
      if (e === "logo") {
        $("#logoFile").click();
      }
      if (e === "removeLogo") {
        const e = clone();
        e.profile.logo = "";
        await commit(e);
      }
    } catch (e) {
      if ($("#dialog").open) {
        $("#formError").textContent = e.message;
      } else {
        toast(e.message);
      }
    } finally {
      busy = false;
    }
  }
});
document.addEventListener("submit", async e => {
  e.preventDefault();
  if (e.target.id === "form") {
    return submitRecord(e);
  }
  if (e.target.id === "settingsForm") {
    if (busy) {
      return;
    }
    busy = true;
    try {
      const r = Object.fromEntries(new FormData(e.target));
      const a = clone();
      if (r.currency !== data.currency && !confirm("Change currency labels? Existing amounts will NOT be converted.")) {
        return;
      }
      a.business = r.business.trim();
      a.currency = r.currency;
      for (const e of ["phone", "email", "address", "taxId", "terms"]) {
        a.profile[e] = r[e];
      }
      a.preferences = {
        notifications: r.notifications === "yes",
        reminderDays: Number(r.reminderDays),
        backupDays: Number(r.backupDays)
      };
      await commit(a);
      toast("Settings saved.");
    } catch (e) {
      toast(e.message);
    } finally {
      busy = false;
    }
  }
});
document.addEventListener("input", e => {
  if (e.target.id === "search") {
    query = e.target.value;
    const r = e.target.selectionStart;
    records();
    $("#search").focus();
    $("#search").setSelectionRange(r, r);
  }
  if (e.target.closest("#itemRows") || ["discount", "taxRate"].includes(e.target.name)) {
    liveTotal();
  }
});
document.addEventListener("change", async e => {
  try {
    if (e.target.id === "mode") {
      mode = e.target.value;
      await chrome.storage.local.set({
        businessMode: mode
      });
      if (!adv() && ["quotes", "services"].includes(tab)) {
        go("dashboard");
      } else {
        render();
      }
    }
    if (e.target.id === "filter") {
      filter = e.target.value;
      records();
    }
    if (e.target.id === "periodType") {
      periodType = e.target.value;
      reports();
    }
    if (e.target.id === "period") {
      const r = e.target.value;
      if (periodType === "year" && /^\d{4}$/.test(r) && Number(r) >= 1900) {
        period = r + "-01";
        reports();
      } else if (periodType === "month" && /^\d{4}-\d{2}$/.test(r)) {
        period = r;
        reports();
      }
    }
    if (e.target.dataset.col === "productId") {
      const r = e.target.closest("tr");
      const a = data.products.find(r => r.id === e.target.value);
      if (a) {
        for (const e of ["description", "price", "cost"]) {
          r.querySelector("[data-col=\"" + e + "\"]").value = e === "description" ? a.name : a[e];
        }
      }
      liveTotal();
    }
    if (e.target.name === "discountType") {
      liveTotal();
    }
    if (e.target.id === "attachmentFiles") {
      if (busy) {
        return;
      }
      busy = true;
      try {
        const r = [...e.target.files];
        if (r.length + draftAttachments.length > 20) {
          throw Error("Maximum 20 attachments.");
        }
        const a = [];
        for (const e of r) {
          const r = e.type || (/\.txt$/i.test(e.name) ? "text/plain" : "");
          if (!["application/pdf", "image/png", "image/jpeg", "image/webp", "text/plain"].includes(r)) {
            throw Error("Unsupported file: " + e.name);
          }
          const o = await readFile(e, 2097152);
          a.push({
            id: Core.id(),
            kind: "file",
            name: e.name,
            mime: r,
            data: o.replace(/^data:[^;]*;/, "data:" + r + ";")
          });
        }
        draftAttachments.push(...a);
        drawAttachments();
      } finally {
        e.target.value = "";
        busy = false;
      }
    }
    if (e.target.id === "logoFile") {
      if (busy) {
        return;
      }
      busy = true;
      try {
        const r = e.target.files[0];
        e.target.value = "";
        if (!r) {
          return;
        }
        if (!["image/png", "image/jpeg", "image/webp"].includes(r.type)) {
          throw Error("Choose a PNG, JPEG or WebP logo.");
        }
        const a = await readFile(r, 512000);
        (await createImageBitmap(r)).close();
        const o = clone();
        o.profile.logo = a;
        await commit(o);
      } finally {
        busy = false;
      }
    }
    if (e.target.id === "importFile") {
      if (busy) {
        return;
      }
      busy = true;
      try {
        const r = e.target.files[0];
        e.target.value = "";
        if (r) {
          await importV4(r);
        }
      } finally {
        busy = false;
      }
    }
  } catch (e) {
    if ($("#dialog").open) {
      $("#formError").textContent = e.message;
    } else {
      toast(e.message);
    }
  }
});
