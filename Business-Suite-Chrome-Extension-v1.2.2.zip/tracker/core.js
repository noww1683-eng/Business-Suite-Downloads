"use strict";

const Core = (() => {
  const t = () => {
    const t = new Date();
    return t.getFullYear() + "-" + String(t.getMonth() + 1).padStart(2, "0") + "-" + String(t.getDate()).padStart(2, "0");
  };
  const r = () => crypto.randomUUID();
  const s = t => Math.round((Number(t) + Number.EPSILON) * 100) / 100;
  const n = (e, t) => s(e.reduce((e, r) => e + t(r), 0));
  const o = t => typeof t === "string" && /^\d{4}-\d{2}-\d{2}$/.test(t) && !isNaN(Date.parse(t + "T00:00:00Z")) && new Date(t + "T00:00:00Z").toISOString().slice(0, 10) === t;
  const a = (t, r, s = Number(t.slice(8))) => {
    const [o, a] = t.split("-").map(Number);
    const i = new Date(Date.UTC(o, a - 1 + r, 1));
    const c = new Date(Date.UTC(i.getUTCFullYear(), i.getUTCMonth() + 1, 0)).getUTCDate();
    i.setUTCDate(Math.min(s, c));
    return i.toISOString().slice(0, 10);
  };
  const i = (t, r) => {
    const n = new Date(t + "T00:00:00Z");
    n.setUTCDate(n.getUTCDate() + r);
    return n.toISOString().slice(0, 10);
  };
  const c = () => ({
    app: "work-tracker-business",
    version: 3,
    currency: "INR",
    business: "My Business",
    profile: {
      address: "",
      phone: "",
      email: "",
      taxId: "",
      logo: "",
      terms: "Thank you for your business."
    },
    preferences: {
      notifications: true,
      reminderDays: 3,
      backupDays: 7
    },
    lastBackup: "",
    counters: {},
    orders: [],
    quotes: [],
    customers: [],
    products: [],
    expenses: [],
    services: []
  });
  function d(r, s) {
    const o = s + "-" + t().slice(0, 4);
    let a;
    do {
      r.counters[o] = (r.counters[o] || 0) + 1;
      a = o + "-" + String(r.counters[o]).padStart(4, "0");
    } while ([...r.orders, ...r.quotes].some(e => e.number === a));
    return a;
  }
  function u(t, r) {
    const n = Math.round(t * 100);
    const o = r.reduce((e, t) => e + t, 0);
    if (!o) {
      return r.map(() => 0);
    }
    const a = r.map(e => n * e / o);
    const i = a.map(Math.floor);
    let c = n - i.reduce((e, t) => e + t, 0);
    const d = a.map((e, t) => [e - i[t], t]).sort((e, t) => t[0] - e[0]);
    for (let e = 0; e < c; e++) {
      i[d[e % d.length][1]]++;
    }
    return i.map(e => e / 100);
  }
  function f(t) {
    const o = t.items.map(e => s(e.quantity * e.price));
    const a = n(o, e => e);
    const i = s(t.discountType === "percent" ? a * t.discount / 100 : t.discount);
    const c = s(a - i);
    const d = s(c * t.taxRate / 100);
    const f = u(i, o);
    const m = o.map((e, t) => s(e - f[t]));
    const p = u(d, m);
    return {
      subtotal: a,
      discount: i,
      net: c,
      tax: d,
      total: s(c + d),
      cost: n(t.items, e => e.quantity * e.cost),
      lines: t.items.map((e, t) => ({
        ...e,
        gross: o[t],
        net: m[t],
        tax: p[t]
      }))
    };
  }
  const m = e => n(e.payments || [], e => e.amount);
  const p = t => n(t.refunds || [], t => t.amount);
  const l = t => n(t.returns || [], e => e.net + e.tax);
  const y = e => s(m(e) - p(e));
  const g = t => t.status === "cancelled" ? 0 : s(f(t).total - l(t) - y(t));
  const h = t => {
    const s = new Map();
    if (t.status === "cancelled") {
      return s;
    }
    for (const e of t.items) {
      if (e.productId) {
        s.set(e.productId, (s.get(e.productId) || 0) + e.quantity);
      }
    }
    for (const e of t.returns || []) {
      if (e.restock) {
        const n = t.items.find(t => t.id === e.itemId);
        s.set(n.productId, s.get(n.productId) - e.quantity);
      }
    }
    return s;
  };
  function b(t, r) {
    const n = t.orders.find(e => e.id === r.id);
    const o = n ? h(n) : new Map();
    const a = h(r);
    const i = new Map();
    for (const e of new Set([...o.keys(), ...a.keys()])) {
      const r = t.products.find(t => t.id === e);
      const s = (o.get(e) || 0) - (a.get(e) || 0);
      if (!r || r.stock + s < 0) {
        throw Error("Not enough stock for this order. Adjust quantity or stock.");
      }
      i.set(e, s);
    }
    for (const [e, r] of i) {
      t.products.find(t => t.id === e).stock += r;
    }
    t.orders = t.orders.filter(e => e.id !== r.id);
    t.orders.push(r);
    return w(t);
  }
  function v(t, r, o, a) {
    const c = f(t).lines.find(e => e.id === r);
    if (!c) {
      throw Error("Item not found.");
    }
    const d = n((t.returns || []).filter(e => e.itemId === r), e => e.quantity);
    if (!Number.isInteger(o) || o < 1 || d + o > c.quantity) {
      throw Error("Return quantity exceeds the remaining quantity.");
    }
    const u = (e, t) => s(t * e / c.quantity);
    return {
      net: s(u(d + o, c.net) - u(d, c.net)),
      tax: s(u(d + o, c.tax) - u(d, c.tax)),
      cost: a && c.productId ? s(c.cost * o) : 0
    };
  }
  function w(t) {
    const a = e => {
      throw Error(e || "Invalid data. No changes were saved.");
    };
    const i = e => typeof e == "string" && e.length <= 20000;
    const c = e => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1000000000000;
    const d = e => e === "" || o(e);
    const u = e => Array.isArray(e) && e.length <= 100000;
    const y = (e, s) => t[e].some(e => e.id === s);
    if (!t || t.app !== "work-tracker-business" || t.version !== 3 || !BusinessCurrency.codes.includes(t.currency) || !i(t.business) || !t.business.trim()) {
      a("Invalid workspace format.");
    }
    for (const e of ["orders", "quotes", "customers", "expenses", "products", "services"]) {
      if (!u(t[e])) {
        a();
      }
      const s = new Set();
      for (const n of t[e]) {
        if (!n || !i(n.id) || !n.id || !!s.has(n.id)) {
          a();
        }
        s.add(n.id);
      }
    }
    if (!t.profile || !["address", "phone", "email", "taxId", "terms"].every(e => i(t.profile[e])) || typeof t.profile.logo != "string" || t.profile.logo.length > 700000 || t.profile.logo !== "" && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(t.profile.logo)) {
      a("Invalid business profile/logo.");
    }
    if (!t.preferences || typeof t.preferences.notifications != "boolean" || !Number.isInteger(t.preferences.reminderDays) || t.preferences.reminderDays < 0 || t.preferences.reminderDays > 30 || !Number.isInteger(t.preferences.backupDays) || t.preferences.backupDays < 1 || t.preferences.backupDays > 90 || !d(t.lastBackup) || !t.counters || typeof t.counters != "object" || Array.isArray(t.counters) || Object.values(t.counters).some(e => !Number.isSafeInteger(e) || e < 0)) {
      a();
    }
    for (const e of t.customers) {
      if (!i(e.name) || !e.name.trim() || !["phone", "email", "address"].every(t => i(e[t])) || !o(e.date)) {
        a("Check customer details.");
      }
    }
    for (const e of t.products) {
      if (!i(e.name) || !e.name.trim() || !i(e.sku) || ![e.stock, e.threshold, e.price, e.cost].every(c) || !Number.isInteger(e.stock) || !Number.isInteger(e.threshold)) {
        a("Check product quantities and prices.");
      }
    }
    for (const e of t.expenses) {
      if (!i(e.title) || !i(e.category) || !o(e.date) || !c(e.amount)) {
        a("Check expense details.");
      }
    }
    const h = new Set();
    const b = new Set();
    for (const e of ["orders", "quotes"]) {
      for (const w of t[e]) {
        if (!y("customers", w.customerId) || !i(w.description) || !w.description.trim() || !i(w.note) || !i(w.number) || !w.number || !!h.has(w.number) || !o(w.date) || ![w.due, w.deadline, w.finishDate].every(d) || !u(w.items) || !w.items.length || !!(w.items.length > 100) || !["fixed", "percent"].includes(w.discountType) || !c(w.discount) || !c(w.taxRate) || !!(w.taxRate > 100) || !u(w.attachments)) {
          a("Check document details, dates and tax.");
        }
        h.add(w.number);
        const t = new Set();
        for (const e of w.items) {
          if (!i(e.id) || !e.id || !!t.has(e.id) || !i(e.description) || !e.description.trim() || !i(e.productId) || !!e.productId && !y("products", e.productId) || ![e.quantity, e.price, e.cost].every(c) || !Number.isInteger(e.quantity) || !!(e.quantity < 1)) {
            a("Each item needs a description, whole quantity and valid price/cost.");
          }
          t.add(e.id);
        }
        const C = f(w);
        if (!c(C.subtotal) || !c(C.total) || !c(C.cost) || C.discount > C.subtotal || w.discountType === "percent" && w.discount > 100) {
          a("Discount cannot exceed the item subtotal.");
        }
        if (w.attachments.length > 20) {
          a("Maximum 20 links/files per record.");
        }
        for (const e of w.attachments) {
          if (!i(e.id) || !i(e.name) || !e.name.trim() || !["link", "file"].includes(e.kind)) {
            a();
          }
          if (e.kind === "link") {
            try {
              const t = new URL(e.url);
              if (!["http:", "https:"].includes(t.protocol)) {
                a();
              }
            } catch {
              a("Links must start with https:// or http://.");
            }
          } else if (!["application/pdf", "image/png", "image/jpeg", "image/webp", "text/plain"].includes(e.mime) || typeof e.data != "string" || !!(e.data.length > 2800000) || !e.data.startsWith("data:" + e.mime + ";base64,") || !/^data:[^;]+;base64,[A-Za-z0-9+/=]*$/.test(e.data)) {
            a("Unsupported attachment.");
          }
        }
        if (e === "quotes") {
          if (!["draft", "sent", "accepted", "rejected"].includes(w.status) || !d(w.validUntil) || !i(w.orderId) || !!w.orderId && !y("orders", w.orderId)) {
            a("Invalid quotation.");
          }
          continue;
        }
        if (!["new", "in_progress", "waiting", "completed", "cancelled"].includes(w.status) || !["payments", "refunds", "returns"].every(e => u(w[e]))) {
          a("Invalid order status/history.");
        }
        for (const e of ["payments", "refunds"]) {
          for (const t of w[e]) {
            if (!i(t.id) || b.has(t.id) || !o(t.date) || t.date < w.date || !c(t.amount) || t.amount <= 0 || !i(t.method) || !i(t.note)) {
              a("Payment/refund dates must be on or after the order date.");
            }
            b.add(t.id);
          }
        }
        let x = {
          ...w,
          returns: []
        };
        for (const e of w.returns) {
          if (!i(e.id) || b.has(e.id) || !o(e.date) || e.date < w.date || !i(e.reason) || typeof e.restock != "boolean" || e.restock && !w.items.find(t => t.id === e.itemId)?.productId) {
            a("Invalid return record.");
          }
          b.add(e.id);
          const t = v(x, e.itemId, e.quantity, e.restock);
          if (["net", "tax", "cost"].some(r => e[r] !== t[r])) {
            a("Return credit does not match the original item.");
          }
          x.returns.push(e);
        }
        if (m(w) > C.total || p(w) > m(w) || g(w) > s(C.total - l(w)) + 0.001) {
          a("Payments/refunds exceed this order.");
        }
        for (const e of w.refunds) {
          const t = n(w.payments.filter(t => t.date <= e.date), e => e.amount);
          const o = n(w.returns.filter(t => t.date <= e.date), e => e.net + e.tax);
          if (n(w.refunds.filter(t => t.date <= e.date), e => e.amount) > s(Math.max(0, t - (C.total - o)))) {
            a("Refund exceeds customer credit available on its date.");
          }
        }
        if (w.status === "cancelled" && (w.payments.length || w.returns.length || w.refunds.length)) {
          a("Use returns/refunds for orders with financial history; cancellation is only for unpaid orders.");
        }
      }
    }
    for (const e of t.services) {
      if (!y("customers", e.customerId) || !i(e.name) || !e.name.trim() || !c(e.amount) || !o(e.nextDate) || ![1, 3, 6, 12].includes(e.interval) || !Number.isInteger(e.anchorDay) || !!(e.anchorDay < 1) || !!(e.anchorDay > 31) || typeof e.active != "boolean" || !i(e.note) || !u(e.history)) {
        a("Invalid recurring service.");
      }
      for (const t of e.history) {
        if (!i(t.id) || !o(t.renewedOn) || !o(t.previousDue) || !c(t.amount)) {
          a();
        }
      }
    }
    return t;
  }
  return {
    today: t,
    id: r,
    round: s,
    sum: n,
    date: o,
    addMonths: a,
    addDays: i,
    fresh: c,
    number: d,
    totals: f,
    paid: m,
    refunded: p,
    netPaid: y,
    credits: l,
    balance: g,
    saveOrder: b,
    returnValues: v,
    addReturn: function (t, s, n) {
      const a = t.orders.find(e => e.id === s);
      if (!a || a.status === "cancelled") {
        throw Error("Choose an active order.");
      }
      const i = structuredClone(a);
      const c = v(i, n.itemId, n.quantity, n.restock);
      i.returns.push({
        ...n,
        ...c,
        id: r()
      });
      return b(t, i);
    },
    convertQuote: function (s, n) {
      const a = s.quotes.find(e => e.id === n);
      if (!a || a.orderId) {
        throw Error("Quotation already converted or missing.");
      }
      if (a.status === "rejected") {
        throw Error("A rejected quotation cannot be converted.");
      }
      const i = {
        ...structuredClone(a),
        id: r(),
        number: d(s, "INV"),
        date: t(),
        status: "new",
        due: "",
        deadline: "",
        finishDate: "",
        payments: [],
        refunds: [],
        returns: [],
        sourceQuote: a.id
      };
      delete i.orderId;
      delete i.validUntil;
      s.quotes.find(e => e.id === n).orderId = i.id;
      s.quotes.find(e => e.id === n).status = "accepted";
      return b(s, i);
    },
    migrate: function (t) {
      if (t?.app === "work-tracker-business" && t.version === 3) {
        return w(structuredClone(t));
      }
      const n = (typeof LegacyCore != "undefined" ? LegacyCore : require("./legacy-core.js")).migrate(t);
      const o = c();
      o.currency = n.currency;
      o.business = n.business;
      o.customers = n.customers.map(e => ({
        ...e,
        address: ""
      }));
      o.products = n.products;
      o.expenses = n.expenses;
      o.orders = n.orders.map(e => ({
        id: e.id,
        number: d(o, "INV"),
        customerId: e.customerId,
        description: e.description,
        date: e.date,
        due: e.due,
        deadline: "",
        finishDate: e.finishDate,
        note: e.note,
        status: e.status === "open" ? "new" : e.status,
        items: [{
          id: r(),
          productId: e.productId,
          description: e.description || "Imported work",
          quantity: e.productId ? e.quantity : 1,
          price: e.amount / (e.productId ? e.quantity : 1),
          cost: e.cost / (e.productId ? e.quantity : 1)
        }],
        discountType: "fixed",
        discount: 0,
        taxRate: 0,
        payments: e.payments.filter(e => e.amount > 0).map(e => ({
          ...e,
          method: "Imported",
          note: ""
        })),
        refunds: [],
        returns: [],
        attachments: [],
        sourceQuote: ""
      }));
      return w(o);
    },
    stats: function (t, r = "") {
      const a = t.orders.filter(e => e.status !== "cancelled");
      const i = a.filter(e => e.date.startsWith(r));
      const c = a.flatMap(e => e.returns).filter(e => e.date.startsWith(r));
      const d = i.map(f);
      const u = s(n(d, e => e.net) - n(c, e => e.net));
      const m = s(n(d, e => e.tax) - n(c, e => e.tax));
      const p = s(n(d, e => e.cost) - n(c, e => e.cost));
      const l = n(t.expenses.filter(e => e.date.startsWith(r)), e => e.amount);
      const y = n(t.orders.flatMap(e => e.payments).filter(e => e.date.startsWith(r)), e => e.amount);
      const h = n(t.orders.flatMap(e => e.refunds).filter(e => e.date.startsWith(r)), e => e.amount);
      return {
        revenue: u,
        tax: m,
        cost: p,
        expenses: l,
        profit: s(u - p - l),
        received: y,
        refunds: h,
        netCash: s(y - h),
        pending: n(i, e => Math.max(0, g(e))),
        owed: n(i, e => Math.max(0, -g(e))),
        orders: i.length,
        customers: t.customers.filter(e => e.date.startsWith(r)).length
      };
    },
    reminders: function (r, s = t()) {
      const o = [];
      const a = i(s, r.preferences.reminderDays);
      for (const e of r.orders) {
        if (e.status !== "cancelled") {
          if (e.deadline && e.deadline <= a && e.status !== "completed") {
            o.push({
              type: "Delivery",
              date: e.deadline,
              label: e.number + " · " + e.description,
              id: e.id,
              target: "orders"
            });
          }
          if (e.due && e.due <= a && g(e) > 0) {
            o.push({
              type: "Payment",
              date: e.due,
              label: e.number + " · Payment due",
              id: e.id,
              target: "orders"
            });
          }
        }
      }
      for (const e of r.services) {
        if (e.active && e.nextDate <= a) {
          o.push({
            type: "Renewal",
            date: e.nextDate,
            label: e.name,
            id: e.id,
            target: "services"
          });
        }
      }
      if (!r.lastBackup || i(r.lastBackup, r.preferences.backupDays) <= s) {
        o.push({
          type: "Backup",
          date: r.lastBackup ? i(r.lastBackup, r.preferences.backupDays) : s,
          label: "Download a JSON backup",
          id: "",
          target: "settings"
        });
      }
      return o.sort((e, t) => e.date.localeCompare(t.date));
    },
    renew: function (s, n) {
      const i = s.services.find(e => e.id === n);
      if (!i?.active) {
        throw Error("This service is inactive.");
      }
      const c = i.nextDate;
      i.history.push({
        id: r(),
        renewedOn: t(),
        previousDue: c,
        amount: i.amount
      });
      i.nextDate = a(c, i.interval, i.anchorDay);
      return w(s);
    },
    validate: w,
    reserved: h
  };
})();
if (typeof module != "undefined") {
  module.exports = Core;
}
