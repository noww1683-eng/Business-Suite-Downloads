(function (t) {
  "use strict";

  const e = 794;
  const r = 1123;
  const s = 595.28;
  const i = 841.89;
  function a(t) {
    const e = new TextEncoder();
    const r = [];
    const a = [];
    let o = 0;
    const c = t => {
      const n = typeof t == "string" ? e.encode(t) : t;
      r.push(n);
      o += n.length;
    };
    const d = (t, n) => {
      a[t] = o;
      c(t + " 0 obj\n");
      c(n);
      c("\nendobj\n");
    };
    c("%PDF-1.4\n%âãÏÓ\n");
    const f = t.map((t, n) => 3 + n * 3 + " 0 R").join(" ");
    d(1, "<< /Type /Catalog /Pages 2 0 R >>");
    d(2, "<< /Type /Pages /Kids [" + f + "] /Count " + t.length + " >>");
    t.forEach((t, e) => {
      const f = 3 + e * 3;
      const h = f + 1;
      const l = f + 2;
      const g = Math.min(i, s * t.h / t.w).toFixed(2);
      const w = (i - g).toFixed(2);
      d(f, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + s + " " + i + "] /Resources << /XObject << /Im0 " + l + " 0 R >> >> /Contents " + h + " 0 R >>");
      const p = "q " + s + " 0 0 " + g + " 0 " + w + " cm /Im0 Do Q";
      d(h, "<< /Length " + p.length + " >>\nstream\n" + p + "\nendstream");
      a[l] = o;
      c(l + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + t.w + " /Height " + t.h + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + t.jpeg.length + " >>\nstream\n");
      c(t.jpeg);
      c("\nendstream\nendobj\n");
    });
    const h = 3 + t.length * 3;
    const l = o;
    let g = "xref\n0 " + h + "\n0000000000 65535 f \n";
    for (let t = 1; t < h; t++) {
      g += String(a[t]).padStart(10, "0") + " 00000 n \n";
    }
    c(g + "trailer\n<< /Size " + h + " /Root 1 0 R >>\nstartxref\n" + l + "\n%%EOF\n");
    const w = new Uint8Array(o);
    let p = 0;
    for (const t of r) {
      w.set(t, p);
      p += t.length;
    }
    return w;
  }
  const o = (t, e, r) => new Promise((s, i) => t.toBlob(t => t ? s(t) : i(new Error("Could not create image")), e, r));
  t.PdfShare = {
    htmlToPdf: async function (t, s, i) {
      const c = await async function (t, s, i) {
        const c = String(t).replace(/:root\s*\{/g, ".pdfroot{").replace(/(^|[\s}])body\s*\{/g, "$1.pdfroot{");
        const d = document.createElement("div");
        d.style.cssText = "position:fixed;left:-20000px;top:0;width:794px;background:#fff";
        d.innerHTML = "<style>" + c + "\n.pdfroot{box-sizing:border-box;width:" + e + "px;max-width:none;margin:0;background:#fff;color:#111}.pdfroot *{box-sizing:border-box}</style><div class=\"pdfroot\">" + s + "</div>";
        document.body.appendChild(d);
        try {
          if (document.fonts && document.fonts.ready) {
            await document.fonts.ready;
          }
          const t = [...d.querySelectorAll("img")];
          await Promise.all(t.map(t => t.complete ? 0 : new Promise(n => {
            t.onload = t.onerror = n;
          })));
          const n = Math.max(200, Math.ceil(d.querySelector(".pdfroot").getBoundingClientRect().height));
          const s = d.cloneNode(true);
          s.removeAttribute("style");
          const c = new XMLSerializer().serializeToString(s);
          const f = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"794\" height=\"" + n + "\"><foreignObject x=\"0\" y=\"0\" width=\"100%\" height=\"100%\">" + c + "</foreignObject></svg>";
          const h = new Image();
          await new Promise((t, n) => {
            h.onload = t;
            h.onerror = () => n(new Error("Could not draw the invoice"));
            h.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(f);
          });
          const l = document.createElement("canvas");
          l.width = e * i;
          l.height = n * i;
          const g = l.getContext("2d");
          g.fillStyle = "#fff";
          g.fillRect(0, 0, l.width, l.height);
          g.drawImage(h, 0, 0, l.width, l.height);
          const w = [];
          const p = Math.max(1, Math.ceil(n / r));
          for (let t = 0; t < p; t++) {
            const n = t * r * i;
            const e = Math.min(r * i, l.height - n);
            const s = document.createElement("canvas");
            s.width = l.width;
            s.height = e;
            const c = s.getContext("2d");
            c.fillStyle = "#fff";
            c.fillRect(0, 0, s.width, s.height);
            c.drawImage(l, 0, n, l.width, e, 0, 0, l.width, e);
            const d = await o(s, "image/jpeg", 0.92);
            w.push({
              jpeg: new Uint8Array(await d.arrayBuffer()),
              w: s.width,
              h: s.height
            });
          }
          return w;
        } finally {
          d.remove();
        }
      }(t, s, i && i.scale || 2);
      return new Blob([a(c)], {
        type: "application/pdf"
      });
    },
    blobToBase64: async function (t) {
      const r = new Uint8Array(await t.arrayBuffer());
      let s = "";
      for (let t = 0; t < r.length; t += 32768) {
        s += String.fromCharCode.apply(null, r.subarray(t, t + 32768));
      }
      return btoa(s);
    },
    buildPdf: a
  };
  if (typeof module != "undefined" && module.exports) {
    module.exports = t.PdfShare;
  }
})(typeof window != "undefined" ? window : globalThis);
