if(location.protocol==="chrome-extension:"&&!globalThis.__businessSuiteIntegrityReady)throw new Error("Business Suite package integrity module is missing.");
"use strict";

const $ = (e, s = document) => s.querySelector(e);
const esc = e => String(e ?? "").replace(/[&<>"']/g, e => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "\"": "&quot;",
  "'": "&#39;"
})[e]);
const pad = e => String(e).padStart(2, "0");
const todayStr = () => {
  const e = new Date();
  return e.getFullYear() + "-" + pad(e.getMonth() + 1) + "-" + pad(e.getDate());
};
const num = e => Number(e) || 0;
const r2 = e => Math.round((Number(e) + Number.EPSILON) * 100) / 100;
const sumBy = (e, s) => e.reduce((e, t) => e + num(s(t)), 0);
const APPS = {
  planner: "planner/app.html",
  tracker: "tracker/app.html",
  qr: "qr/app.html",
  notes: "notes/app.html"
};
const store = chrome.storage.local;
let tt;
let locked = false;
let current = "planner";
let hasPin = false;
const toast = e => {
  const t = $("#hubToast");
  t.textContent = e;
  t.hidden = false;
  clearTimeout(tt);
  tt = setTimeout(() => t.hidden = true, 2800);
};
const allowed = e => e === "whatsapp" ? LIC.has("whatsapp") : LIC.has(e);
function applyModules() {
  document.querySelectorAll("#rail button[data-app]").forEach(s => {
    s.hidden = !allowed(s.dataset.app);
  });
  if (LIC.ok && !allowed(current)) {
    const s = Object.keys(APPS).concat("whatsapp").find(allowed);
    if (s) {
      show(s);
    }
  }
}
function show(e) {
  if (!LIC.ok) {
    return;
  }
  if (!allowed(e)) {
    return toast("Your license package does not include this app");
  }
  if (locked && e !== "planner") {
    return toast("Locked — unlock Business Planner with your PIN first");
  }
  current = e;
  document.querySelectorAll("#rail button[data-app]").forEach(t => t.classList.toggle("on", t.dataset.app === e));
  for (const t of Object.keys(APPS)) {
    const n = $("#f-" + t);
    n.hidden = t !== e;
    if (t === e && n.dataset.loaded !== "1") {
      n.src = APPS[t];
      n.dataset.loaded = "1";
    }
  }
  $("#p-whatsapp").hidden = e !== "whatsapp";
  if (e === "whatsapp") {
    renderWA();
  }
  store.set({
    hubLast: e
  }).catch(() => {});
}
function wipeApps() {
  for (const s of Object.keys(APPS)) {
    const t = $("#f-" + s);
    t.src = "about:blank";
    t.dataset.loaded = "0";
  }
  $("#p-whatsapp").innerHTML = "";
}
function setLocked(e) {
  locked = e;
  $("#lockedNote").hidden = !e;
  document.querySelectorAll("#rail button[data-app]").forEach(t => t.classList.toggle("dis", e && t.dataset.app !== "planner"));
  if (e) {
    for (const e of ["tracker", "notes"]) {
      const t = $("#f-" + e);
      if (t.dataset.loaded === "1") {
        t.src = "about:blank";
        t.dataset.loaded = "0";
      }
    }
    $("#p-whatsapp").innerHTML = "";
    show("planner");
    setTimeout(() => $("#f-planner").focus(), 50);
  }
}
function pinState(e) {
  hasPin = !!e && !!e.sec && !!e.sec.hash;
  $("#hubLock").hidden = !hasPin;
}
document.querySelectorAll("#rail button[data-app]").forEach(e => e.addEventListener("click", () => show(e.dataset.app)));
$("#f-planner").addEventListener("load", () => {
  if (locked) {
    $("#f-planner").focus();
  }
});
window.addEventListener("message", e => {
  if (e.origin === location.origin && e.data && e.data.type === "bp-lock") {
    setLocked(!!e.data.locked);
  }
});
$("#hubLock").addEventListener("click", () => {
  const e = $("#f-planner");
  if (e.contentWindow) {
    e.contentWindow.postMessage({
      type: "bp-lock-now"
    }, location.origin);
  }
});
const OLD_WA = "Namaskaram {name}, {business}-il ninnu. ₹{amount} baaki und. Avasana date: {date}. Dayavayi adakkane. Nanni.";
const DEFAULT_WA = "Dear {name},\n\nThis is a gentle reminder from {business} regarding the outstanding balance of {amount}{billref}.\nDue date: {date}\n\nKindly arrange the payment at your earliest convenience. If you have already paid, please disregard this message.\n\nThank you for your business.\n\nBest regards,\n{business}";
let WAD = {
  cc: "91",
  biz: {},
  people: [],
  dues: []
};
const waNum = e => {
  let t = String(e || "").replace(/\D/g, "").replace(/^0+/, "");
  if (t) {
    if (t.length <= 10) {
      t = (WAD.cc || "91") + t;
    }
    return t;
  } else {
    return "";
  }
};
async function waOpen(e, s) {
  try {
    await chrome.runtime.sendMessage({
      type: "wa-open",
      phone: e,
      text: s || "",
      mode: WAD.mode || "window",
      screen: {
        w: screen.availWidth,
        h: screen.availHeight
      }
    });
  } catch {
    toast("Could not open WhatsApp — please try again");
  }
}
$("#waQuick").addEventListener("click", () => {
  if (locked) {
    return toast("Locked");
  }
  waOpen("");
});
const wtTotal = e => {
  const t = sumBy(e.items || [], e => e.quantity * e.price);
  const n = t - (e.discountType === "percent" ? t * num(e.discount) / 100 : num(e.discount));
  return r2(n + n * num(e.taxRate) / 100);
};
const wtBalance = e => e.status === "cancelled" ? 0 : r2(wtTotal(e) - sumBy(e.returns || [], e => num(e.net) + num(e.tax)) - (sumBy(e.payments || [], e => e.amount) - sumBy(e.refunds || [], e => e.amount)));
async function loadWAData() {
  const s = await store.get(["db", "settings", "trackerSuiteV4"]);
  const t = s.db || {};
  const n = (s.settings || {}).biz || {};
  const a = todayStr();
  const i = t.customers || [];
  const o = [];
  const c = [];
  const r = s => (i.find(t => (t.name || "").trim().toLowerCase() === (s || "").trim().toLowerCase() && t.phone) || {}).phone || "";
  i.filter(s => s.phone).forEach(s => o.push({
    name: s.name,
    phone: s.phone,
    src: "Planner"
  }));
  (t.sales || []).filter(s => s.kind !== "Return" && s.pay !== "Paid" && s.due && s.due <= a).forEach(s => {
    const a = Math.max(0, num(s.total) - num(s.rcv));
    if (a) {
      c.push({
        name: s.customer || s.no,
        phone: s.phone || r(s.customer),
        amount: a,
        due: s.due,
        bill: s.no,
        src: "Planner",
        biz: n.name
      });
    }
  });
  (t.payments || []).filter(s => s.dir !== "To pay" && s.status !== "Paid" && s.due && s.due <= a).forEach(s => {
    const a = Math.max(0, num(s.amount) - num(s.rcv));
    if (a) {
      c.push({
        name: s.party,
        phone: s.phone || r(s.party),
        amount: a,
        due: s.due,
        bill: "",
        src: "Planner",
        biz: n.name,
        currency: n.currency || "INR"
      });
    }
  });
  const u = new Set((t.sales || []).map(e => e.impKey).filter(Boolean));
  for (const t of (s.trackerSuiteV4 || {}).businesses || []) {
    const s = t.data || {};
    const n = s.customers || [];
    n.filter(s => s.phone).forEach(s => o.push({
      name: s.name,
      phone: s.phone,
      src: "Work Tracker"
    }));
    (s.orders || []).filter(s => s.due && s.due <= a && !u.has("wt:" + s.id)).forEach(t => {
      const i = wtBalance(t);
      if (i > 0) {
        const e = n.find(e => e.id === t.customerId) || {};
        c.push({
          name: e.name || t.number,
          phone: e.phone,
          amount: i,
          due: t.due,
          bill: t.number,
          src: "Work Tracker",
          biz: s.business,
          currency: s.currency || "INR"
        });
      }
    });
  }
  const d = new Set();
  WAD = {
    cc: n.cc || "91",
    mode: (s.hubSettings || {}).waMode,
    biz: n,
    tpl: n.waTpl && n.waTpl !== OLD_WA ? n.waTpl : DEFAULT_WA,
    people: o.filter(s => {
      const n = (s.name + "|" + s.phone).toLowerCase();
      return !d.has(n) && (d.add(n), true);
    }),
    dues: c.sort((s, t) => s.due.localeCompare(t.due))
  };
  const b = await store.get("hubSettings");
  WAD.mode = (b.hubSettings || {}).waMode || "window";
  WAD.auto = false;
  WAD.daily = {
    ...DailySummary.DEF,
    ...((b.hubSettings || {}).daily || {})
  };
}
const fill = (e, s) => e.replace(/\{name\}/g, s.name || "").replace(/\{amount\}/g, BusinessCurrency.format(num(s.amount), s.currency || WAD.biz.currency || "INR")).replace(/\{date\}/g, s.due ? s.due.split("-").reverse().join("-") : "as agreed").replace(/\{business\}/g, s.biz || WAD.biz.name || "our business").replace(/\{billref\}/g, s.bill ? " (Invoice " + s.bill + ")" : "").replace(/\{bill\}/g, s.bill || "");
async function renderWA() {
  const s = $("#p-whatsapp");
  s.innerHTML = "<p class=\"sub\">Loading…</p>";
  await loadWAData();
  if (locked) {
    s.innerHTML = "";
    return;
  }
  const t = [["Payment reminder", WAD.tpl], ["Work ready", "Dear {name},\n\nWe are pleased to inform you that your order is ready for collection. Please visit us at your convenience.\n\nThank you for choosing {business}.\n\nBest regards,\n{business}"], ["Thank you", "Dear {name},\n\nThank you for your order. We truly appreciate your business and look forward to serving you again.\n\nBest regards,\n{business}"]];
  s.innerHTML = "<div class=\"wh\"><span class=\"big\">💬</span><div><h1>WhatsApp</h1><p>Log in to WhatsApp Web once, then send reminders and bills to customers in one click.</p></div></div>\n  <div class=\"cols\"><div>\n   <div class=\"card\"><h2>Login options</h2><p>WhatsApp Web links to your phone — Chrome remembers the login, so you scan only once.</p>\n    <div class=\"opt\"><div class=\"t\"><b>Open in a side window</b><span>Small window on the right — keep working here while chatting</span></div><button class=\"go\" data-w=\"win\">Open &amp; log in</button></div>\n    <div class=\"opt\"><div class=\"t\"><b>Open in a normal tab</b><span>Full browser tab</span></div><button class=\"sec\" data-w=\"tab\">Open tab</button></div>\n    <div class=\"opt\"><div class=\"t\"><b>Where chats open from here</b><span>Reminders and “Send” buttons use this</span></div><select id=\"waMode\" style=\"width:auto\"><option value=\"window\" " + (WAD.mode === "window" ? "selected" : "") + ">Side window</option><option value=\"tab\" " + (WAD.mode === "tab" ? "selected" : "") + ">Browser tab</option></select></div>\n    <p style=\"margin-top:14px\"><b>Log in with QR</b></p><ol class=\"steps\"><li>Open WhatsApp on your phone → <b>Settings</b> → <b>Linked devices</b> → <b>Link a device</b>.</li><li>Scan the QR code shown in the WhatsApp Web window.</li></ol>\n    <p style=\"margin-top:12px\"><b>No camera? Log in with phone number</b></p><ol class=\"steps\"><li>On the WhatsApp Web page click <b>Link with phone number</b>.</li><li>Type your number, then enter the 8-letter code on your phone (Linked devices → Link a device).</li></ol>\n    <div class=\"note\">The same login works for WhatsApp and WhatsApp Business accounts. To log out, remove this computer under <b>Linked devices</b> on your phone. This app never sees your WhatsApp password or chats.</div></div>\n   <div class=\"card\"><h2>Send a message</h2>\n    <label class=\"f\">To (pick a customer or type a number)<input id=\"waTo\" list=\"waPeople\" placeholder=\"Name or phone number\" autocomplete=\"off\"></label><datalist id=\"waPeople\">" + WAD.people.map(s => "<option value=\"" + esc(s.name) + " · " + esc(s.phone) + "\">").join("") + "</datalist>\n    <div class=\"chips\">" + t.map(([s, t], n) => "<button data-chip=\"" + n + "\">" + s + "</button>").join("") + "</div>\n    <label class=\"f\">Message<textarea id=\"waMsg\" placeholder=\"Type a message… ({name} is replaced by the customer’s name)\"></textarea></label>\n    <button class=\"go\" id=\"waSend\">Send on WhatsApp</button></div>\n  </div><div>\n   <div class=\"card\"><h2>📊 Daily summary on WhatsApp</h2><p>Every day at the time below, WhatsApp Web opens and prepares your summary (sales, money received, expenses, pending) for review. Press Send in WhatsApp.</p>\n    <div class=\"opt\"><div class=\"t\"><b>Prepare daily summary</b><span>Chrome must be open (it can be minimised) and WhatsApp Web logged in</span></div><select id=\"dsOn\" style=\"width:auto\"><option value=\"1\" " + (WAD.daily.on ? "selected" : "") + ">On</option><option value=\"0\" " + (WAD.daily.on ? "" : "selected") + ">Off</option></select></div>\n    <div class=\"opt\"><div class=\"t\"><b>Time</b><span>Default 8:45 PM — change it any time</span></div><input type=\"time\" id=\"dsTime\" value=\"" + esc(WAD.daily.time) + "\" style=\"width:auto\"></div>\n    <div class=\"opt\"><div class=\"t\"><b>Owner WhatsApp number</b><span>Where the summary is sent (your own number). Empty = Business Profile phone</span></div><input id=\"dsPhone\" value=\"" + esc(WAD.daily.phone || "") + "\" placeholder=\"" + esc(WAD.biz.phone || "98765 43210") + "\" style=\"width:150px\"></div>\n    <div class=\"opt\"><div class=\"t\"><b>Show customer names in “Top pending”</b></div><select id=\"dsNames\" style=\"width:auto\"><option value=\"1\" " + (WAD.daily.names !== false ? "selected" : "") + ">Yes</option><option value=\"0\" " + (WAD.daily.names !== false ? "" : "selected") + ">No</option></select></div>\n    <div class=\"opt\"><div class=\"t\"><b>Try it</b><span>Preview the message, or prepare it right now</span></div><span><button class=\"sec\" id=\"dsPreview\">Preview</button> <button class=\"go\" id=\"dsTest\">Prepare now</button></span></div>\n    <textarea id=\"dsOut\" rows=\"11\" readonly hidden style=\"margin-top:10px;width:100%\"></textarea>\n    <div class=\"note\">If Chrome was closed at that time, the summary is prepared when Chrome is next opened (the same day). It is prepared once a day.</div></div>\n   <div class=\"card\"><h2>Payments due — remind on WhatsApp</h2><p>Overdue amounts from Business Planner and Work Tracker.</p>\n    " + (WAD.dues.length ? WAD.dues.map((s, t) => "<div class=\"rem\"><div class=\"n\"><b>" + esc(s.name) + "</b><span class=\"sub\"><span class=\"tag\">" + esc(s.src) + "</span>" + esc(s.bill) + " · last date " + esc(s.due.split("-").reverse().join("-")) + "</span></div><span class=\"amt\">" + BusinessCurrency.format(num(s.amount), s.currency || WAD.biz.currency || "INR") + "</span><button class=\"go\" data-due=\"" + t + "\">Remind</button></div>").join("") : "<div class=\"empty\">No overdue payments 🎉</div>") + "\n    <div class=\"note\">“Remind” fills the message box so you can check the number and text before sending.</div></div></div></div>";
}
document.addEventListener("click", async e => {
  const t = e.target.closest("#p-whatsapp button");
  if (t) {
    if (t.id !== "dsPreview" && t.id !== "dsTest") {
      if (t.dataset.w) {
        const e = WAD.mode;
        WAD.mode = t.dataset.w === "win" ? "window" : "tab";
        waOpen("");
        WAD.mode = e;
        return;
      }
      if (t.dataset.chip !== undefined) {
        const e = [WAD.tpl, "Dear {name},\n\nWe are pleased to inform you that your order is ready for collection. Please visit us at your convenience.\n\nThank you for choosing {business}.\n\nBest regards,\n{business}", "Dear {name},\n\nThank you for your order. We truly appreciate your business and look forward to serving you again.\n\nBest regards,\n{business}"][t.dataset.chip];
        $("#waMsg").value = e;
        return;
      }
      if (t.id === "waSend") {
        const e = $("#waTo").value.trim();
        const t = e.match(/·\s*(.+)$/);
        const n = WAD.people.find(s => s.name + " · " + s.phone === e);
        const a = waNum(t ? t[1] : e);
        if (!a) {
          return toast("Pick a customer or type a phone number");
        }
        const i = n ? n.name : "";
        return waOpen(a, fill($("#waMsg").value, {
          name: i
        }));
      }
      if (t.dataset.due !== undefined) {
        const e = WAD.dues[t.dataset.due];
        const n = waNum(e.phone);
        $("#waTo").value = n ? e.name + " · " + n : e.name;
        $("#waMsg").value = fill(WAD.tpl, e);
        $("#waMsg").scrollIntoView({
          block: "center",
          behavior: "smooth"
        });
        if (n) {
          toast("Review the message, then press “Send on WhatsApp”");
        } else {
          toast("No phone saved — type the number in the \"To\" box, then press Send");
          $("#waTo").focus();
          $("#waTo").select();
        }
      }
    } else {
      if (t.id === "dsPreview") {
        const e = await store.get(["db", "settings", "trackerSuiteV4"]);
        $("#dsOut").value = DailySummary.build(e, todayStr(), {
          names: $("#dsNames").value === "1"
        }).text;
        $("#dsOut").hidden = false;
        return;
      }
      try {
        const e = await chrome.runtime.sendMessage({
          type: "daily-now"
        });
        toast(e && e.error === "no-phone" ? "Enter the owner WhatsApp number first" : e && e.error ? "Could not open WhatsApp" : "Opening WhatsApp…");
      } catch {
        toast("Could not open WhatsApp — please try again");
      }
    }
  }
});
document.addEventListener("change", async e => {
  if (/^ds(On|Time|Phone|Names)$/.test(e.target.id)) {
    const t = (await store.get("hubSettings")).hubSettings || {};
    const n = {
      ...DailySummary.DEF,
      ...(t.daily || {})
    };
    const a = e.target.id;
    const i = e.target.value;
    if (a === "dsOn") {
      n.on = i === "1";
    } else if (a === "dsTime") {
      n.time = /^\d{2}:\d{2}$/.test(i) ? i : DailySummary.DEF.time;
    } else if (a === "dsPhone") {
      n.phone = i.trim();
    } else {
      n.names = i === "1";
    }
    await store.set({
      hubSettings: {
        ...t,
        daily: n
      }
    });
    WAD.daily = n;
    return toast(a === "dsTime" ? "Daily summary will be prepared at " + n.time : "Saved");
  }
  const t = {
    waMode: "waMode"
  }[e.target.id];
  if (!t) {
    return;
  }
  const n = await store.get("hubSettings");
  const a = e.target.value;
  await store.set({
    hubSettings: {
      ...(n.hubSettings || {}),
      [t]: a
    }
  });
  if (t === "waMode") {
    WAD.mode = a;
  }
  toast("Saved");
});
chrome.storage.onChanged.addListener((e, s) => {
  if (s === "local") {
    if (e.settings) {
      pinState(e.settings.newValue);
      if (e.settings.newValue && e.settings.newValue.theme) {
        document.documentElement.dataset.theme = e.settings.newValue.theme;
      }
    }
    if (e.hubGo && e.hubGo.newValue && !locked) {
      show(e.hubGo.newValue.app);
    }
  }
});
$("#licBtn").addEventListener("click", () => LIC.info());
(async () => {
  const s = await store.get(["settings", "hubLast", "hubGo"]);
  await LIC.start(e => {
    if (e) {
      applyModules();
      if ($("#f-" + current).dataset.loaded !== "1") {
        show(current);
      }
    } else {
      wipeApps();
    }
  });
  applyModules();
  pinState(s.settings);
  const t = (s.settings || {}).theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.dataset.theme = t;
  if (hasPin) {
    locked = true;
    setLocked(true);
  }
  const n = s.hubGo && Date.now() - s.hubGo.t < 20000 ? s.hubGo.app : s.hubLast;
  const a = Object.keys(APPS).concat("whatsapp").find(allowed) || "planner";
  if ((!locked && APPS[n] || n === "whatsapp" && !locked) && allowed(n)) {
    show(n);
  } else {
    show(locked ? "planner" : a);
  }
})();
