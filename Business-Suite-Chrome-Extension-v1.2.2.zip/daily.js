(function (e) {
  "use strict";

  const t = {
    on: true,
    time: "20:45",
    phone: "",
    names: true
  };
  const s = e => Number(e) || 0;
  const r = e => Math.round((s(e) + Number.EPSILON) * 100) / 100;
  const o = (e, t) => (e || []).reduce((e, n) => e + s(t(n)), 0);
  const a = e => String(e).padStart(2, "0");
  const i = e => e.getFullYear() + "-" + a(e.getMonth() + 1) + "-" + a(e.getDate());
  const c = e => BusinessCurrency.format(Math.round(s(e) * 100) / 100, globalThis.__businessSuiteCurrency || "INR");
  const u = e => (e || "").split("-").reverse().join("-");
  const d = e => {
    const a = o(e.items, e => e.quantity * e.price);
    const i = a - (e.discountType === "percent" ? a * s(e.discount) / 100 : s(e.discount));
    return r(i + i * s(e.taxRate) / 100);
  };
  function f(e, t, a) {
    globalThis.__businessSuiteCurrency = BusinessCurrency.normalize(e?.settings?.biz?.currency);
    const f = e && e.db || {};
    const l = (e && e.settings || {}).biz || {};
    const m = !a || a.names !== false;
    const y = {
      sales: 0,
      bills: 0,
      received: 0,
      expenses: 0,
      pending: 0,
      pendingCount: 0,
      overdue: 0,
      overdueCount: 0
    };
    const h = [];
    const g = [];
    if (["sales", "ledger", "payments"].some(e => (f[e] || []).length) && l.name) {
      g.push(l.name);
    }
    const p = e => e.kind === "Return" ? -1 : 1;
    (f.sales || []).forEach(e => {
      if (e.date === t) {
        y.sales += s(e.total) * p(e);
        if (e.kind !== "Return") {
          y.bills++;
        }
      }
      (e.pays || []).forEach(r => {
        if (r.date === t) {
          y.received += s(r.amt) * p(e);
        }
      });
      if (e.kind !== "Return" && e.pay !== "Paid") {
        const t = Math.max(0, s(e.total) - s(e.rcv));
        if (t > 0) {
          h.push({
            n: e.customer || e.no,
            a: t,
            due: e.due
          });
        }
      }
    });
    (f.payments || []).filter(e => e.dir !== "To pay").forEach(e => {
      (e.pays || []).forEach(e => {
        if (e.date === t) {
          y.received += s(e.amt);
        }
      });
      if (e.status !== "Paid") {
        const t = Math.max(0, s(e.amount) - s(e.rcv));
        if (t > 0) {
          h.push({
            n: e.party,
            a: t,
            due: e.due
          });
        }
      }
    });
    (f.ledger || []).forEach(e => {
      if (e.date === t) {
        if (e.type === "Income") {
          y.received += s(e.amount);
        } else if (e.type === "Expense") {
          y.expenses += s(e.amount);
        }
      }
    });
    const v = new Set((f.sales || []).map(e => e.impKey).filter(Boolean));
    for (const a of ((e || {}).trackerSuiteV4 || {}).businesses || []) {
      const e = a.data || {};
      if (!e.business) {
        continue;
      }
      const c = (e.orders || []).filter(e => e.status !== "cancelled" && !v.has("wt:" + e.id));
      if (c.length || (e.expenses || []).length) {
        g.push(e.business);
      }
      const u = e.customers || [];
      c.forEach(e => {
        if (e.date === t) {
          y.sales += d(e);
          y.bills++;
        }
        const c = (f = e).status === "cancelled" ? 0 : r(d(f) - o(f.returns, e => s(e.net) + s(e.tax)) - (o(f.payments, e => e.amount) - o(f.refunds, e => e.amount)));
        var f;
        if (c > 0) {
          h.push({
            n: (u.find(n => n.id === e.customerId) || {}).name || e.number,
            a: c,
            due: e.due
          });
        }
      });
      (e.orders || []).forEach(e => {
        (e.payments || []).forEach(e => {
          if (e.date === t) {
            y.received += s(e.amount);
          }
        });
        (e.refunds || []).forEach(e => {
          if (e.date === t) {
            y.received -= s(e.amount);
          }
        });
      });
      (e.expenses || []).forEach(e => {
        if (e.date === t) {
          y.expenses += s(e.amount);
        }
      });
    }
    h.forEach(e => {
      y.pending += e.a;
      y.pendingCount++;
      if (e.due && e.due <= t) {
        y.overdue += e.a;
        y.overdueCount++;
      }
    });
    Object.keys(y).forEach(e => {
      if (!/Count$|bills/.test(e)) {
        y[e] = r(y[e]);
      }
    });
    const z = h.sort((e, n) => n.a - e.a).slice(0, 5);
    const w = ["📊 *Daily Summary* — " + ([...new Set(g)].join(" / ") || "Your business"), "📅 " + u(t), "", "🧾 Sales today: *" + c(y.sales) + "*" + (y.bills ? " (" + y.bills + " bill" + (y.bills > 1 ? "s" : "") + ")" : ""), "✅ Money received: *" + c(y.received) + "*", "💸 Expenses: *" + c(y.expenses) + "*", (y.received - y.expenses >= 0 ? "📈" : "📉") + " Net cash today: *" + c(y.received - y.expenses) + "*", "", "⏳ Pending to receive: *" + c(y.pending) + "*" + (y.pendingCount ? " (" + y.pendingCount + ")" : "")];
    if (y.overdueCount) {
      w.push("🔴 Overdue: *" + c(y.overdue) + "* (" + y.overdueCount + ")");
    }
    if (z.length && m) {
      w.push("", "Top pending:");
      z.forEach((e, n) => w.push(n + 1 + ". " + (e.n || "—") + " — " + c(e.a) + (e.due ? " (due " + u(e.due) + ")" : "")));
    }
    return {
      text: w.join("\n"),
      figures: y
    };
  }
  const l = (e, n) => {
    let t = String(e || "").replace(/\D/g, "").replace(/^0+/, "");
    if (t && t.length <= 10) {
      t = (n || "91") + t;
    }
    return t;
  };
  const m = {
    DEF: t,
    build: f,
    waNum: l,
    ymd: i
  };
  e.DailySummary = m;
  if (typeof module != "undefined" && module.exports) {
    module.exports = m;
  }
  if (typeof ServiceWorkerGlobalScope === "undefined" || typeof chrome == "undefined" || !chrome.alarms) {
    return;
  }
  const y = "bs-daily";
  const h = "bs-daily-check";
  const g = async () => {
    const {
      hubSettings: e
    } = await chrome.storage.local.get("hubSettings");
    return {
      ...t,
      ...((e || {}).daily || {})
    };
  };
  const p = (e, t) => {
    const [r, o] = String(e || "20:45").split(":").map(Number);
    const a = new Date(t || Date.now());
    a.setHours(r || 0, o || 0, 0, 0);
    return a;
  };
  async function v() {
    const t = await g();
    await chrome.alarms.clear(y);
    if (!t.on) {
      return;
    }
    let s = p(t.time);
    if (s.getTime() <= Date.now() + 1000) {
      s = p(t.time, Date.now() + 86400000);
    }
    chrome.alarms.create(y, {
      when: s.getTime()
    });
  }
  async function z(e) {
    if (typeof bsLeaseOkSW == "function" && !(await bsLeaseOkSW())) {
      return {
        error: "license"
      };
    }
    const s = await g();
    const r = await chrome.storage.local.get(["db", "settings", "trackerSuiteV4", "hubSettings", "dailyLast"]);
    const o = i(new Date());
    if (!e) {
      if (!s.on || r.dailyLast === o) {
        return {
          skipped: true
        };
      }
      if (Date.now() < p(s.time).getTime()) {
        return {
          skipped: true
        };
      }
    }
    const a = (r.settings || {}).biz || {};
    const c = l(s.phone || a.phone, a.cc);
    if (!/^[1-9]\d{7,14}$/.test(c)) {
      await chrome.notifications.create("bs-daily-nophone", {
        type: "basic",
        iconUrl: "icon128.png",
        title: "Daily summary not sent",
        message: "Enter the owner WhatsApp number in Business Suite → WhatsApp → Daily summary."
      });
      return {
        error: "no-phone"
      };
    }
    const {
      text: u
    } = f(r, o, {
      names: s.names
    });
    if (!e) {
      await chrome.storage.local.set({
        dailyLast: o
      });
    }
    try {
      await waOpen({
        phone: c,
        text: u,
        mode: (r.hubSettings || {}).waMode || "window",
        ttl: 300000
      });
      return {
        ok: true
      };
    } catch (n) {
      if (!e) {
        await chrome.storage.local.remove("dailyLast");
      }
      return {
        error: String(n)
      };
    }
  }
  chrome.alarms.onAlarm.addListener(e => {
    if (e.name === y) {
      z().then(v).catch(console.error);
    } else if (e.name === h) {
      z().catch(console.error);
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    v();
    chrome.alarms.create(h, {
      periodInMinutes: 10,
      delayInMinutes: 1
    });
  });
  chrome.runtime.onStartup.addListener(() => {
    v();
    z().catch(console.error);
  });
  chrome.storage.onChanged.addListener((e, t) => {
    if (t === "local" && e.hubSettings) {
      v();
    }
  });
  chrome.runtime.onMessage.addListener((e, n, t) => {
    if (e && e.type === "daily-now") {
      z(true).then(t, e => t({
        error: String(e)
      }));
      return true;
    }
  });
  chrome.alarms.get(y).then(e => {
    if (!e) {
      v();
    }
  });
  chrome.alarms.get(h).then(e => {
    if (!e) {
      chrome.alarms.create(h, {
        periodInMinutes: 10,
        delayInMinutes: 1
      });
    }
  });
})(typeof window !== "undefined" ? window : globalThis);
