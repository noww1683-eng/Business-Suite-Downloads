"use strict";

const bsGuard = (() => {
  const n = typeof LICENSE_CONFIG != "undefined" && LICENSE_CONFIG || {};
  const e = n => Uint8Array.from(atob(n), t => t.charCodeAt(0));
  const r = {
    mod: "",
    started: false,
    hide: null
  };
  async function s(s) {
    if (r.started) {
      return;
    }
    r.started = true;
    r.mod = s;
    r.hide = document.createElement("style");
    r.hide.textContent = "html{visibility:hidden!important}";
    (document.head || document.documentElement).appendChild(r.hide);
    const c = async () => {
      if (await async function (r) {
        try {
          if (window.top !== window && typeof top.__businessSuiteLicenseCheck === "function") {
            return !!top.__businessSuiteLicenseCheck(r);
          }
          if (window.BSAndroid && !(await BSAndroid.call("licenseState", {
            module: r
          }))) {
            return false;
          }
          if (!n.SERVER || !n.PUBLIC_KEY) {
            return false;
          }
          const t = await chrome.storage.local.get(["licLease", "licClock"]);
          const a = t.licLease;
          if (!a || !a.lease || !a.sig) {
            return false;
          }
          const c = await crypto.subtle.importKey("raw", e(n.PUBLIC_KEY), {
            name: "Ed25519"
          }, false, ["verify"]);
          if (!(await crypto.subtle.verify({
            name: "Ed25519"
          }, c, e(a.sig), new TextEncoder().encode(a.lease)))) {
            return false;
          }
          const o = JSON.parse(a.lease);
          return o.fp === (await BS_FP()) && (o.status === "licensed" || o.status === "trial") && Date.now() < o.validUntil && (!t.licClock || !(Date.now() < t.licClock - 600000)) && Array.isArray(o.modules) && o.modules.includes(r);
        } catch {
          return false;
        }
      }(s)) {
        if (r.hide) {
          r.hide.remove();
          r.hide = null;
        }
      } else {
        (function () {
          try {
            window.stop();
          } catch {}
          try {
            document.documentElement.replaceChildren();
          } catch {}
          if (window.top === window) {
            location.replace(chrome.runtime.getURL("hub.html"));
          } else {
            location.replace("about:blank");
          }
        })();
      }
    };
    await c();
    setInterval(c, 60000);
  }
  const a = document.currentScript;
  if (a && a.dataset && a.dataset.module) {
    s(a.dataset.module);
  }
  return t => s(t);
})();
