if (qrcode.stringToBytesFuncs && qrcode.stringToBytesFuncs["UTF-8"]) {
  qrcode.stringToBytes = qrcode.stringToBytesFuncs["UTF-8"];
}
const $ = e => document.getElementById(e);
const E = encodeURIComponent;
const esc = e => e.replace(/([\\;,":])/g, "\\$1");
const dig = e => e.replace(/[^\d+]/g, "");
const T = {
  text: ["Text / URL", [["text", "Text or link", "area"]], e => e.text],
  wifi: ["Wi-Fi", [["ssid", "Network name"], ["wpass", "Password"], ["sec", "Security", "sel:WPA,WEP,nopass"]], e => e.ssid && "WIFI:T:" + (e.sec || "WPA") + ";S:" + esc(e.ssid) + ";" + (e.sec === "nopass" ? "" : "P:" + esc(e.wpass || "") + ";") + ";"],
  tel: ["Phone", [["num", "Phone number"]], e => e.num && "tel:" + dig(e.num)],
  email: ["Email", [["to", "To"], ["sub", "Subject"], ["body", "Message", "area"]], e => e.to && "mailto:" + e.to + "?subject=" + E(e.sub || "") + "&body=" + E(e.body || "")],
  sms: ["SMS", [["num", "Phone number"], ["msg", "Message", "area"]], e => e.num && "SMSTO:" + dig(e.num) + ":" + (e.msg || "")],
  wa: ["WhatsApp chat", [["num", "Number with country code"], ["msg", "Message", "area"]], e => e.num && "https://wa.me/" + e.num.replace(/\D/g, "") + "?text=" + E(e.msg || "")],
  vcard: ["Contact card", [["name", "Full name"], ["num", "Phone number"], ["mail", "Email"], ["org", "Organisation"]], e => e.name && ["BEGIN:VCARD", "VERSION:3.0", "FN:" + e.name, e.org && "ORG:" + e.org, e.num && "TEL:" + e.num, e.mail && "EMAIL:" + e.mail, "END:VCARD"].filter(Boolean).join("\n")],
  geo: ["Location (Google Maps)", [["lat", "Latitude"], ["lng", "Longitude"]], e => e.lat && e.lng && "https://www.google.com/maps?q=" + E(e.lat.trim()) + "," + E(e.lng.trim())],
  upi: ["UPI payment", [["upi", "UPI ID (name@bank)"], ["pn", "Payee name"], ["am", "Amount in ₹ (optional)"], ["tn", "Note (optional)"]], e => e.upi && "upi://pay?pa=" + E(e.upi.trim()) + "&pn=" + E(e.pn || "") + "&cu=INR" + (e.am ? "&am=" + E(e.am) : "") + (e.tn ? "&tn=" + E(e.tn) : "")],
  event: ["Calendar event", [["title", "Title"], ["st", "Starts", "dt"], ["en", "Ends", "dt"], ["loc", "Place"]], e => e.title && e.st && ["BEGIN:VCALENDAR", "VERSION:2.0", "BEGIN:VEVENT", "SUMMARY:" + e.title, "DTSTART:" + e.st.replace(/[-:]/g, "") + "00", e.en && "DTEND:" + e.en.replace(/[-:]/g, "") + "00", e.loc && "LOCATION:" + e.loc, "END:VEVENT", "END:VCALENDAR"].filter(Boolean).join("\n")],
  bank: ["Bank transfer", [["bkfmt", "Format", "sel:Details as text,SEPA (Europe),UPI via account + IFSC"], ["bkname", "Account holder"], ["bkacc", "Account number / IBAN"], ["bkcode", "IFSC / BIC"], ["bkbank", "Bank name (optional)"], ["am", "Amount (optional)"], ["tn", "Note (optional)"]], e => {
    const s = e.bkfmt || "Details as text";
    const a = (e.bkacc || "").replace(/\s/g, "");
    if (a) {
      if (s.startsWith("SEPA")) {
        return ["BCD", "002", "1", "SCT", e.bkcode || "", e.bkname || "", a, e.am ? "EUR" + e.am : "", "", "", e.tn || ""].join("\n");
      } else if (s.startsWith("UPI")) {
        if (e.bkcode) {
          return "upi://pay?pa=" + E(a + "@" + e.bkcode.trim() + ".ifsc.npci") + "&pn=" + E(e.bkname || "") + "&cu=INR" + (e.am ? "&am=" + E(e.am) : "") + (e.tn ? "&tn=" + E(e.tn) : "");
        } else {
          return "";
        }
      } else {
        return ["Account holder: " + (e.bkname || ""), "Account number: " + a, e.bkcode && "IFSC/BIC: " + e.bkcode, e.bkbank && "Bank: " + e.bkbank, e.am && "Amount: " + e.am, e.tn && "Note: " + e.tn].filter(Boolean).join("\n");
      }
    } else {
      return "";
    }
  }],
  batch: ["Batch (many codes)", [], null]
};
const V = {
  text: "https://example.com"
};
let qr = null;
let logo = null;
let prevEcl = "M";
function fields() {
  $("fields").innerHTML = T[$("type").value][1].map(([e, t, s]) => {
    const n = V[e] || "";
    let _;
    _ = s === "area" ? "<textarea id=\"f_" + e + "\">" + n.replace(/</g, "&lt;") + "</textarea>" : s && s.startsWith("sel:") ? "<select id=\"f_" + e + "\">" + s.slice(4).split(",").map(e => "<option" + (e === n ? " selected" : "") + ">" + e + "</option>").join("") + "</select>" : "<input type=\"" + (s === "dt" ? "datetime-local" : "text") + "\" id=\"f_" + e + "\" value=\"" + n.replace(/"/g, "&quot;") + "\">";
    return "<label>" + t + _ + "</label>";
  }).join("");
  $("p-batch").hidden = $("type").value !== "batch";
}
function items() {
  let t = $("batch").value.replace(/^\uFEFF/, "").split(/\r?\n/).map(e => e.trim()).filter(Boolean);
  const s = $("bnamed").checked;
  if (s && /^(name|peru)\s*,/i.test(t[0] || "")) {
    t = t.slice(1);
  }
  const a = e => e.trim().replace(/^"|"$/g, "");
  return t.map(t => {
    let _ = "";
    let r = t;
    if (s) {
      const e = t.indexOf(",");
      if (e > 0) {
        _ = a(t.slice(0, e));
        r = t.slice(e + 1);
      }
    }
    return {
      name: _,
      text: a(r)
    };
  }).filter(e => e.text);
}
function payload() {
  const t = $("type").value;
  if (t === "batch") {
    return (items()[0] || {}).text || "";
  } else {
    return T[t][2](V) || "";
  }
}
$("type").innerHTML = Object.entries(T).map(([e, t]) => "<option value=\"" + e + "\">" + t[0] + "</option>").join("");
const makeQR = e => {
  const s = qrcode(0, logo ? "H" : $("ecl").value);
  s.addData(e);
  s.make();
  return s;
};
const lay = e => {
  const s = $("frame").value.trim();
  const a = s ? e * 0.05 : 0;
  const n = s ? e * 0.16 : 0;
  return {
    f: s,
    pad: a,
    band: n,
    W: e + a * 2,
    H: e + a * 2 + n,
    fs: s ? Math.min(n * 0.55, e * 0.9 / (s.length * 0.6)) : 0
  };
};
function shapes(e, t) {
  const a = +$("mar").value;
  const n = e.getModuleCount();
  const _ = t / (n + a * 2);
  const r = $("style").value;
  const p = [];
  const o = (e, t) => e < 7 && t < 7 || e < 7 && t >= n - 7 || e >= n - 7 && t < 7;
  for (let t = 0; t < n; t++) {
    for (let i = 0; i < n; i++) {
      if (!e.isDark(t, i) || o(t, i)) {
        continue;
      }
      const n = (i + a) * _;
      const c = (t + a) * _;
      p.push(r === "dot" ? [n + _ * 0.05, c + _ * 0.05, _ * 0.9, _ * 0.9, _ * 0.45, "d"] : r === "round" ? [n, c, _, _, _ * 0.35, "d"] : [Math.floor(n), Math.floor(c), Math.ceil(_), Math.ceil(_), 0, "d"]);
    }
  }
  const i = $("eyes").value;
  const c = i === "square" ? 0 : i === "round" ? 0.3 : 0.5;
  for (const [e, t] of [[0, 0], [0, n - 7], [n - 7, 0]]) {
    const n = (t + a) * _;
    const r = (e + a) * _;
    p.push([n, r, _ * 7, _ * 7, _ * 7 * c, "e"], [n + _, r + _, _ * 5, _ * 5, _ * 5 * c, "b"], [n + _ * 2, r + _ * 2, _ * 3, _ * 3, _ * 3 * c, "e"]);
  }
  return p;
}
function logoBox(e) {
  if (!logo) {
    return null;
  }
  const s = e * $("ls").value / 100;
  const a = $("lround").checked;
  const n = Math.min(s / logo.img.width, s / logo.img.height);
  const _ = a ? s : logo.img.width * n;
  const r = a ? s : logo.img.height * n;
  return {
    x: (e - _) / 2,
    y: (e - r) / 2,
    w: _,
    h: r,
    pad: e * 0.015,
    rd: a
  };
}
function render(e, t, s) {
  const n = lay(s);
  const _ = t.getContext("2d");
  const r = $("bg").value;
  const p = $("fg").value;
  t.width = n.W;
  t.height = n.H;
  _.fillStyle = n.f ? p : r;
  _.beginPath();
  _.roundRect(0, 0, n.W, n.H, n.f ? s * 0.06 : 0);
  _.fill();
  _.save();
  _.translate(n.pad, n.pad);
  _.fillStyle = r;
  _.beginPath();
  _.roundRect(0, 0, s, s, n.f ? s * 0.03 : 0);
  _.fill();
  let o = p;
  if ($("gOn").checked) {
    o = _.createLinearGradient(0, 0, s, s);
    o.addColorStop(0, p);
    o.addColorStop(1, $("fg2").value);
  }
  const i = $("eOn").checked ? $("ec").value : o;
  for (const [t, a, n, p, c, l] of shapes(e, s)) {
    _.fillStyle = l === "d" ? o : l === "e" ? i : r;
    _.beginPath();
    _.roundRect(t, a, n, p, c);
    _.fill();
  }
  const c = logoBox(s);
  if (c) {
    _.fillStyle = r;
    _.beginPath();
    _.roundRect(c.x - c.pad, c.y - c.pad, c.w + c.pad * 2, c.h + c.pad * 2, c.rd ? 9999 : c.pad * 2);
    _.fill();
    _.save();
    const e = logo.img;
    if (c.rd) {
      _.beginPath();
      _.arc(s / 2, s / 2, c.w / 2, 0, 7);
      _.clip();
      const t = Math.min(e.width, e.height);
      _.drawImage(e, (e.width - t) / 2, (e.height - t) / 2, t, t, c.x, c.y, c.w, c.h);
    } else {
      _.drawImage(e, c.x, c.y, c.w, c.h);
    }
    _.restore();
  }
  _.restore();
  if (n.f) {
    _.fillStyle = r;
    _.font = "700 " + n.fs + "px system-ui,sans-serif";
    _.textAlign = "center";
    _.textBaseline = "middle";
    _.fillText(n.f, n.W / 2, n.pad + s + (n.band + n.pad) / 2);
  }
}
function svgOf(e, t) {
  const a = lay(t);
  const n = $("bg").value;
  const _ = $("fg").value;
  const r = e => +e.toFixed(2);
  const p = $("gOn").checked;
  const o = p ? "url(#g)" : _;
  const i = $("eOn").checked ? $("ec").value : o;
  const c = shapes(e, t).map(([e, t, a, _, p, c]) => "<rect x=\"" + r(e) + "\" y=\"" + r(t) + "\" width=\"" + r(a) + "\" height=\"" + r(_) + "\"" + (p ? " rx=\"" + r(p) + "\"" : "") + " fill=\"" + (c === "d" ? o : c === "e" ? i : n) + "\"/>").join("");
  const l = logoBox(t);
  let b = "";
  if (l) {
    b = "<rect x=\"" + r(l.x - l.pad) + "\" y=\"" + r(l.y - l.pad) + "\" width=\"" + r(l.w + l.pad * 2) + "\" height=\"" + r(l.h + l.pad * 2) + "\" rx=\"" + r(l.rd ? (l.w + l.pad * 2) / 2 : l.pad * 2) + "\" fill=\"" + n + "\"/>" + (l.rd ? "<clipPath id=\"lc\"><circle cx=\"" + r(t / 2) + "\" cy=\"" + r(t / 2) + "\" r=\"" + r(l.w / 2) + "\"/></clipPath>" : "") + "<image href=\"" + logo.data + "\" x=\"" + r(l.x) + "\" y=\"" + r(l.y) + "\" width=\"" + r(l.w) + "\" height=\"" + r(l.h) + "\"" + (l.rd ? " clip-path=\"url(#lc)\" preserveAspectRatio=\"xMidYMid slice\"" : "") + "/>";
  }
  const d = a.f.replace(/[&<>]/g, e => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;"
  })[e]);
  return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + r(a.W) + "\" height=\"" + r(a.H) + "\" viewBox=\"0 0 " + r(a.W) + " " + r(a.H) + "\">" + (p ? "<defs><linearGradient id=\"g\" gradientUnits=\"userSpaceOnUse\" x1=\"0\" y1=\"0\" x2=\"" + t + "\" y2=\"" + t + "\"><stop offset=\"0\" stop-color=\"" + _ + "\"/><stop offset=\"1\" stop-color=\"" + $("fg2").value + "\"/></linearGradient></defs>" : "") + (a.f ? "<rect width=\"" + r(a.W) + "\" height=\"" + r(a.H) + "\" rx=\"" + r(t * 0.06) + "\" fill=\"" + _ + "\"/>" : "") + ("<g transform=\"translate(" + r(a.pad)) + " " + r(a.pad) + ")\"><rect width=\"" + t + "\" height=\"" + t + "\" rx=\"" + (a.f ? r(t * 0.03) : 0) + "\" fill=\"" + n + "\"/>" + c + b + "</g>" + (a.f ? "<text x=\"" + r(a.W / 2) + "\" y=\"" + r(a.pad + t + (a.band + a.pad) / 2) + "\" fill=\"" + n + "\" font-family=\"system-ui,sans-serif\" font-weight=\"700\" font-size=\"" + r(a.fs) + "\" text-anchor=\"middle\" dominant-baseline=\"central\">" + d + "</text>" : "") + "</svg>";
}
function grid() {
  const t = $("grid");
  const s = items();
  t.innerHTML = "";
  $("bcount").value = s.length;
  s.slice(0, 60).forEach(s => {
    try {
      const e = document.createElement("canvas");
      render(makeQR(s.text), e, 160);
      e.title = s.name || s.text;
      t.appendChild(e);
    } catch (e) {}
  });
  if (s.length > 60) {
    $("msg").textContent = "Preview shows the first 60 codes. Downloads include all of them.";
  }
}
function draw() {
  const t = $("type").value;
  const s = payload();
  const a = +$("size").value;
  const n = t === "batch";
  qr = null;
  ["dlZip", "prSheet", "grid"].forEach(e => $(e).hidden = !n);
  if (s) {
    try {
      qr = makeQR(s);
      $("msg").textContent = "";
    } catch (t) {
      $("msg").textContent = "Too much data for this error-correction level. Shorten it or lower the level.";
    }
  } else {
    $("msg").textContent = n ? "Add one item per line, or load a CSV file." : "Fill in the details to make a code.";
  }
  if (qr) {
    render(qr, $("cv"), a);
  } else {
    const t = $("cv");
    t.width = t.height = a;
    const s = t.getContext("2d");
    s.fillStyle = $("bg").value;
    s.fillRect(0, 0, a, a);
  }
  if (n) {
    grid();
  }
}
function save(e, t) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(e);
  a.download = t;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
$("dlPng").onclick = () => {
  if (qr) {
    $("cv").toBlob(e => save(e, "qrcode.png"));
  }
};
$("dlSvg").onclick = () => {
  if (qr) {
    save(new Blob([svgOf(qr, +$("size").value)], {
      type: "image/svg+xml"
    }), "qrcode.svg");
  }
};
$("copy").onclick = () => {
  if (qr) {
    $("cv").toBlob(async t => {
      try {
        await navigator.clipboard.write([new ClipboardItem({
          "image/png": t
        })]);
        $("msg").textContent = "Image copied.";
      } catch (e) {
        $("msg").textContent = "Copy is blocked here. Use Download PNG.";
      }
    });
  }
};
const CT = new Uint32Array(256).map((e, t) => {
  let s = t;
  for (let e = 0; e < 8; e++) {
    s = s & 1 ? s >>> 1 ^ -306674912 : s >>> 1;
  }
  return s >>> 0;
});
const crc = e => {
  let t = -1;
  for (let s = 0; s < e.length; s++) {
    t = CT[(t ^ e[s]) & 255] ^ t >>> 8;
  }
  return (t ^ -1) >>> 0;
};
function zip(e) {
  const s = new TextEncoder();
  const a = [];
  const n = [];
  let _ = 0;
  let r = 0;
  for (const p of e) {
    const e = s.encode(p.name);
    const o = crc(p.data);
    const i = p.data.length;
    const c = new DataView(new ArrayBuffer(30));
    c.setUint32(0, 67324752, true);
    c.setUint16(4, 20, true);
    c.setUint16(6, 2048, true);
    c.setUint16(12, 33, true);
    c.setUint32(14, o, true);
    c.setUint32(18, i, true);
    c.setUint32(22, i, true);
    c.setUint16(26, e.length, true);
    a.push(c.buffer, e, p.data);
    const l = new DataView(new ArrayBuffer(46));
    l.setUint32(0, 33639248, true);
    l.setUint16(4, 20, true);
    l.setUint16(6, 20, true);
    l.setUint16(8, 2048, true);
    l.setUint16(14, 33, true);
    l.setUint32(16, o, true);
    l.setUint32(20, i, true);
    l.setUint32(24, i, true);
    l.setUint16(28, e.length, true);
    l.setUint32(42, _, true);
    n.push(l.buffer, e);
    r += 46 + e.length;
    _ += 30 + e.length + i;
  }
  const p = new DataView(new ArrayBuffer(22));
  p.setUint32(0, 101010256, true);
  p.setUint16(8, e.length, true);
  p.setUint16(10, e.length, true);
  p.setUint32(12, r, true);
  p.setUint32(16, _, true);
  return new Blob([...a, ...n, p.buffer], {
    type: "application/zip"
  });
}
function setLogo(e) {
  logo = e;
  $("rmLogo").hidden = !e;
  const s = $("ecl");
  if (e) {
    prevEcl = s.value;
    s.value = "H";
    s.disabled = true;
  } else {
    s.value = prevEcl;
    s.disabled = false;
    $("logo").value = "";
  }
  draw();
}
$("dlZip").onclick = async () => {
  const t = items();
  if (!t.length) {
    return $("msg").textContent = "Add at least one line first.";
  }
  const s = +$("size").value;
  const a = $("bfmt").value;
  const n = [];
  const _ = new Set();
  const r = document.createElement("canvas");
  let p = 0;
  for (let o = 0; o < t.length; o++) {
    let i;
    $("msg").textContent = "Making " + (o + 1) + " of " + t.length + "...";
    try {
      i = makeQR(t[o].text);
    } catch (e) {
      p++;
      continue;
    }
    const c = t[o].text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "qr";
    let l;
    let b = t[o].name ? t[o].name.replace(/[\\/:*?"<>|]+/g, "_") : String(o + 1).padStart(3, "0") + "-" + c;
    let d = b;
    let g = 2;
    while (_.has(d)) {
      d = b + "-" + g++;
    }
    _.add(d);
    if (a === "svg") {
      l = new TextEncoder().encode(svgOf(i, s));
    } else {
      render(i, r, s);
      l = new Uint8Array(await (await new Promise(t => r.toBlob(t))).arrayBuffer());
    }
    n.push({
      name: d + "." + a,
      data: l
    });
    if (o % 10 == 9) {
      await new Promise(e => setTimeout(e));
    }
  }
  if (!n.length) {
    return $("msg").textContent = "Nothing could be made. The lines are too long.";
  }
  save(zip(n), "qrcodes.zip");
  $("msg").textContent = "Downloaded " + n.length + " code" + (n.length > 1 ? "s" : "") + (p ? ", skipped " + p + " that were too long." : ".");
};
$("prSheet").onclick = async () => {
  const t = items();
  if (!t.length) {
    return $("msg").textContent = "Add at least one line first.";
  }
  const s = $("sheet");
  const a = document.createElement("canvas");
  const n = [];
  let _;
  let r = 0;
  s.innerHTML = "";
  for (const p of t) {
    let t;
    try {
      t = makeQR(p.text);
    } catch (e) {
      continue;
    }
    if (r++ % 12 == 0) {
      _ = document.createElement("div");
      _.className = "pg";
      s.appendChild(_);
    }
    render(t, a, 400);
    const o = document.createElement("figure");
    const i = new Image();
    const c = document.createElement("figcaption");
    i.src = a.toDataURL();
    c.textContent = p.name || p.text;
    n.push(i);
    o.append(i, c);
    _.appendChild(o);
  }
  await Promise.all(n.map(e => e.decode().catch(() => {})));
  document.body.classList.add("printing");
  window.print();
  document.body.classList.remove("printing");
  $("msg").textContent = "In the print window choose \"Save as PDF\". A4 pages, 12 codes each.";
};
$("logo").onchange = e => {
  const s = e.target.files[0];
  if (!s) {
    return;
  }
  const a = new FileReader();
  a.onload = () => {
    const e = new Image();
    e.onload = () => setLogo({
      img: e,
      data: a.result
    });
    e.onerror = () => {
      $("msg").textContent = "That file is not a readable image.";
    };
    e.src = a.result;
  };
  a.readAsDataURL(s);
};
$("rmLogo").onclick = () => setLogo(null);
$("csv").onchange = async e => {
  const s = e.target.files[0];
  if (s) {
    $("batch").value = (await s.text()).trim();
    $("bnamed").checked = true;
    e.target.value = "";
    draw();
  }
};
$("type").addEventListener("change", () => {
  fields();
  draw();
});
document.addEventListener("input", e => {
  if (e.target.id.startsWith("f_")) {
    V[e.target.id.slice(2)] = e.target.value;
  }
  $("sizeV").textContent = $("size").value;
  $("marV").textContent = $("mar").value;
  $("lsV").textContent = $("ls").value;
  draw();
});
fields();
draw();
